export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ad_views: {
        Row: {
          id: string
          user_id: string
          viewed_at: string
        }
        Insert: {
          id?: string
          user_id: string
          viewed_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          viewed_at?: string
        }
        Relationships: []
      }
      daily_logins: {
        Row: {
          created_at: string
          last_claim_date: string | null
          streak_day: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          last_claim_date?: string | null
          streak_day?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          last_claim_date?: string | null
          streak_day?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          balance: number
          boost_multiplier: number
          boost_remaining_ms: number
          created_at: string
          hkd_spent_cents: number
          is_in_transit: boolean
          skin_tokens: number
          starrboxes: number
          total_earned: number
          transit_ends_at: string | null
          transit_from: string | null
          transit_started_at: string | null
          transit_to: string | null
          unlocked_lines: string[]
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          boost_multiplier?: number
          boost_remaining_ms?: number
          created_at?: string
          hkd_spent_cents?: number
          is_in_transit?: boolean
          skin_tokens?: number
          starrboxes?: number
          total_earned?: number
          transit_ends_at?: string | null
          transit_from?: string | null
          transit_started_at?: string | null
          transit_to?: string | null
          unlocked_lines?: string[]
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          boost_multiplier?: number
          boost_remaining_ms?: number
          created_at?: string
          hkd_spent_cents?: number
          is_in_transit?: boolean
          skin_tokens?: number
          starrboxes?: number
          total_earned?: number
          transit_ends_at?: string | null
          transit_from?: string | null
          transit_started_at?: string | null
          transit_to?: string | null
          unlocked_lines?: string[]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      purchases: {
        Row: {
          amount_hkd_cents: number
          created_at: string
          environment: string
          granted: boolean
          id: string
          paddle_transaction_id: string
          price_id: string
          product_id: string | null
          reversed: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          amount_hkd_cents?: number
          created_at?: string
          environment?: string
          granted?: boolean
          id?: string
          paddle_transaction_id: string
          price_id: string
          product_id?: string | null
          reversed?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          amount_hkd_cents?: number
          created_at?: string
          environment?: string
          granted?: boolean
          id?: string
          paddle_transaction_id?: string
          price_id?: string
          product_id?: string | null
          reversed?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      special_rushes: {
        Row: {
          created_at: string
          created_by: string | null
          ends_at: string
          id: string
          multiplier: number
          starts_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          ends_at: string
          id?: string
          multiplier: number
          starts_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          ends_at?: string
          id?: string
          multiplier?: number
          starts_at?: string
        }
        Relationships: []
      }
      starr_gifts: {
        Row: {
          amount_net: number
          amount_sent: number
          claimed_at: string | null
          created_at: string
          from_admin: boolean
          id: string
          recipient_id: string
          sender_id: string
          sender_name: string
        }
        Insert: {
          amount_net: number
          amount_sent: number
          claimed_at?: string | null
          created_at?: string
          from_admin?: boolean
          id?: string
          recipient_id: string
          sender_id: string
          sender_name: string
        }
        Update: {
          amount_net?: number
          amount_sent?: number
          claimed_at?: string | null
          created_at?: string
          from_admin?: boolean
          id?: string
          recipient_id?: string
          sender_id?: string
          sender_name?: string
        }
        Relationships: []
      }
      tickets: {
        Row: {
          created_at: string
          fare: number
          from_station: string
          id: string
          seat: string
          seat_class: string
          to_station: string
          user_id: string
        }
        Insert: {
          created_at?: string
          fare: number
          from_station: string
          id?: string
          seat: string
          seat_class: string
          to_station: string
          user_id: string
        }
        Update: {
          created_at?: string
          fare?: number
          from_station?: string
          id?: string
          seat?: string
          seat_class?: string
          to_station?: string
          user_id?: string
        }
        Relationships: []
      }
      user_bans: {
        Row: {
          banned_until: string | null
          created_at: string
          permanent: boolean
          reason: string | null
          user_id: string
        }
        Insert: {
          banned_until?: string | null
          created_at?: string
          permanent?: boolean
          reason?: string | null
          user_id: string
        }
        Update: {
          banned_until?: string | null
          created_at?: string
          permanent?: boolean
          reason?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_ban_user: {
        Args: { p_permanent: boolean; p_until: string; p_user: string }
        Returns: undefined
      }
      admin_list_users: {
        Args: never
        Returns: {
          balance: number
          banned_permanent: boolean
          banned_until: string
          created_at: string
          email: string
          is_in_transit: boolean
          user_id: string
        }[]
      }
      admin_start_rush: {
        Args: { p_duration_minutes: number; p_multiplier: number }
        Returns: {
          ends_at: string
          id: string
          multiplier: number
        }[]
      }
      admin_stats: {
        Args: never
        Returns: {
          in_transit: number
          total_users: number
        }[]
      }
      admin_unban_user: { Args: { p_user: string }; Returns: undefined }
      apply_trip_ad_bonus: { Args: { p_amount: number }; Returns: number }
      auto_unlock_lines: { Args: never; Returns: string[] }
      claim_ad_reward: {
        Args: never
        Returns: {
          new_balance: number
          views_today: number
        }[]
      }
      claim_daily_login: {
        Args: never
        Returns: {
          claimed: boolean
          day: number
          new_balance: number
          reward: number
        }[]
      }
      claim_starr_gifts: {
        Args: never
        Returns: {
          new_balance: number
          total_claimed: number
        }[]
      }
      consume_boost: {
        Args: { p_elapsed_ms: number }
        Returns: {
          boost_multiplier: number
          boost_remaining_ms: number
        }[]
      }
      current_rush: {
        Args: never
        Returns: {
          ends_at: string
          id: string
          multiplier: number
        }[]
      }
      end_journey: {
        Args: { p_earned: number }
        Returns: {
          new_balance: number
        }[]
      }
      get_daily_login_status: {
        Args: never
        Returns: {
          can_claim: boolean
          last_claim_date: string
          next_day: number
          streak_day: number
        }[]
      }
      grant_purchase: {
        Args: {
          p_amount_hkd_cents: number
          p_environment: string
          p_price_id: string
          p_product_id: string
          p_transaction_id: string
          p_user: string
        }
        Returns: undefined
      }
      is_admin: { Args: never; Returns: boolean }
      leaderboard_earned: {
        Args: never
        Returns: {
          display_name: string
          total: number
          user_id: string
        }[]
      }
      leaderboard_first_class: {
        Args: never
        Returns: {
          count: number
          display_name: string
          user_id: string
        }[]
      }
      leaderboard_spent: {
        Args: never
        Returns: {
          display_name: string
          total: number
          user_id: string
        }[]
      }
      leaderboard_trips: {
        Args: never
        Returns: {
          count: number
          display_name: string
          user_id: string
        }[]
      }
      list_pending_gifts: {
        Args: never
        Returns: {
          amount_net: number
          created_at: string
          from_admin: boolean
          id: string
          sender_name: string
        }[]
      }
      my_ban: {
        Args: never
        Returns: {
          banned_until: string
          permanent: boolean
        }[]
      }
      open_starrbox: {
        Args: { p_use_credit: boolean }
        Returns: {
          kind: string
          new_balance: number
          new_boost_multiplier: number
          new_boost_remaining_ms: number
          new_skin_tokens: number
          new_starrboxes: number
          starrs_awarded: number
          tokens_awarded: number
        }[]
      }
      purchase_ticket: {
        Args: {
          p_fare: number
          p_from: string
          p_seat: string
          p_seat_class: string
          p_to: string
        }
        Returns: {
          new_balance: number
          ticket_id: string
        }[]
      }
      redeem_skin_tokens: {
        Args: { p_count: number }
        Returns: {
          new_balance: number
          new_skin_tokens: number
        }[]
      }
      reverse_purchase: {
        Args: { p_transaction_id: string }
        Returns: undefined
      }
      send_starr_gift: {
        Args: { p_amount: number; p_recipient_email: string }
        Returns: {
          net_delivered: number
          new_balance: number
        }[]
      }
      start_journey: {
        Args: { p_from: string; p_minutes: number; p_to: string }
        Returns: undefined
      }
      unlock_line: {
        Args: { p_cost: number; p_line: string }
        Returns: {
          new_balance: number
          unlocked_lines: string[]
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
