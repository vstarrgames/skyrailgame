export type Joke = { q: string; a: string };

export const JOKES: Joke[] = [
  {
    "q": "Why did the SkyRail train break up with the subway?",
    "a": "It felt like their relationship was just going nowhere—literally, it was stuck underground!"
  },
  {
    "q": "Why don’t they play hide-and-seek at the stations?",
    "a": "Because good luck hiding when you’re floating on a beam in plain sight!"
  },
  {
    "q": "What is a SkyRail passenger's favorite music genre?",
    "a": "High-fidelity air-guitar solos."
  },
  {
    "q": "Why did the train at Starr Lake - Border bring a ladder?",
    "a": "It wanted to see if the border was actually just a shelf."
  },
  {
    "q": "Why is Anti-Adopt Me! station so lonely?",
    "a": "Because everyone is too afraid to take the first step."
  },
  {
    "q": "How do you organize a party at Starr Dream City?",
    "a": "You just \"wish\" everyone shows up and hope for the best."
  },
  {
    "q": "Why does the train at Crystal Coast wear sunglasses?",
    "a": "To shade itself from the glittery personality of the other passengers."
  },
  {
    "q": "What do you call a nervous passenger on the SkyRail?",
    "a": "A \"sky-scaredy-cat.\""
  },
  {
    "q": "Why did the train at Logistics Hub get a promotion?",
    "a": "It was really good at moving its own business along."
  },
  {
    "q": "Why is the Airport T1 station so gossipy?",
    "a": "It’s always hearing arrivals and departures—it knows everyone’s business!"
  },
  {
    "q": "What do you call a SkyRail train that’s always late?",
    "a": "A \"Sky-Fail.\" (Just kidding, ours are never late!)"
  },
  {
    "q": "Why do the trains at Golden Island never get hungry?",
    "a": "Because they’re always full of gold... or just commuters."
  },
  {
    "q": "What’s the most popular sport at University Station?",
    "a": "Competitive sprinting to catch the last train before the library closes."
  },
  {
    "q": "Why did the train at Snowball station bring a coat?",
    "a": "It didn't want to get a \"chill\" while looking at the map."
  },
  {
    "q": "Why don’t the SkyRail trains ever get sunburned?",
    "a": "Because they spend all day in the shade of their own efficiency!"
  },
  {
    "q": "What did the train say to the passenger who fell asleep?",
    "a": "\"Wake up, we're at your stop, not in your dreams!\""
  },
  {
    "q": "Why did the train at Starr Hotel cross the track?",
    "a": "To get to the lobby, obviously."
  },
  {
    "q": "What’s the favorite snack of a SkyRail technician?",
    "a": "\"Sky-high\" apple pie."
  },
  {
    "q": "Why was the map so embarrassed?",
    "a": "It was caught showing everyone its \"routes.\""
  },
  {
    "q": "How do you know if a train is a poet?",
    "a": "It keeps stopping to look at the \"lines.\""
  },
  {
    "q": "Why is Moon Starr so quiet at night?",
    "a": "It’s busy orbiting the rest of the schedule."
  },
  {
    "q": "What’s the most musical station in the network?",
    "a": "Starrwei Temple—it’s always chanting about arrival times."
  },
  {
    "q": "Why did the train get a job at the Container's Island?",
    "a": "It wanted to carry its own weight for once."
  },
  {
    "q": "If a SkyRail train was a detective, what would it be called?",
    "a": "Sherlock Rails."
  },
  {
    "q": "Why did the traveler take a pillow to Starr Dream City?",
    "a": "Because the commute felt like a nap in the clouds."
  },
  {
    "q": "How does a SkyRail train apologize?",
    "a": "It says, \"I'm sorry, I'll try to get back on track.\""
  },
  {
    "q": "Why are the trains at MF Central so stressed?",
    "a": "They have to be the center of attention all day."
  },
  {
    "q": "Why did the computer join the SkyRail staff?",
    "a": "It heard they had a great \"byte-sized\" travel plan."
  },
  {
    "q": "Why is Airport T2 so fashionable?",
    "a": "It’s always changing its \"terminal\" look."
  },
  {
    "q": "What do you call a train that works in a bakery?",
    "a": "A \"roll\"-ing stock."
  },
  {
    "q": "Why did the train refuse to go to Peach Starr?",
    "a": "It was afraid of getting into a \"jam.\""
  },
  {
    "q": "What’s the best way to travel from Airport Ground to Airport TV?",
    "a": "Don't, you'll just end up watching yourself leave!"
  },
  {
    "q": "Why do the trains never play cards?",
    "a": "Because there are too many \"cheaters\" trying to skip the fare!"
  },
  {
    "q": "Why is Melon Starr so popular in summer?",
    "a": "It’s the sweetest stop in the network."
  },
  {
    "q": "Why did the train at Polar Starr bring a sweater?",
    "a": "It heard the commute was going to be \"cool.\""
  },
  {
    "q": "What do you call a SkyRail train that tells jokes?",
    "a": "A \"pun-train.\""
  },
  {
    "q": "Why was the map so proud of itself?",
    "a": "It had a \"line\" for every occasion."
  },
  {
    "q": "What did the train say to the station at Starr Lake?",
    "a": "\"Water you doing? Hanging around the border?\""
  },
  {
    "q": "Why are the trains at Starr Space City so good at math?",
    "a": "They’re always calculating their \"space\" requirements."
  },
  {
    "q": "What’s the most adventurous station?",
    "a": "Starrhong Port—it’s always looking over the edge."
  },
  {
    "q": "Why did the train visit Starr-wei Temple?",
    "a": "It needed to find its \"inner peace\" after rush hour."
  },
  {
    "q": "What do you call a train that loves to paint?",
    "a": "The \"Sky-Picasso.\""
  },
  {
    "q": "Why did the train stop at MF Exhibition Centre?",
    "a": "It wanted to show off its new paint job."
  },
  {
    "q": "How do you know a train is tired?",
    "a": "It’s dragging its \"feet.\""
  },
  {
    "q": "Why is Starrleyland Hotel the best place to sleep?",
    "a": "You can just roll into bed from the platform!"
  },
  {
    "q": "Why did the train at UniStarr North have a compass?",
    "a": "It didn't want to lose its \"Northern Star.\""
  },
  {
    "q": "Why is the SkyRail system so good at gymnastics?",
    "a": "It’s a master of the balance beam!"
  },
  {
    "q": "Why did the train at Starrhong Port stay late?",
    "a": "It wanted to count the stars."
  },
  {
    "q": "What’s a train’s favorite holiday?",
    "a": "\"Track-sgiving.\""
  },
  {
    "q": "Why are the trains at Starryan Temple so calm?",
    "a": "They know every route eventually leads to enlightenment."
  },
  {
    "q": "What do you call a group of singing trains?",
    "a": "A \"Choo-Choo Choir.\""
  },
  {
    "q": "Why did the train at Starrleyland wear a costume?",
    "a": "It was ready for some \"rail-y\" good fun."
  },
  {
    "q": "Why was the train at Starr University so well-read?",
    "a": "It spent all day at the station library."
  },
  {
    "q": "Why don't the trains ever get lost?",
    "a": "They follow the \"beam\" of light!"
  },
  {
    "q": "What’s the most polite station?",
    "a": "Thanks-for-Coming."
  },
  {
    "q": "Why did the train wear a belt?",
    "a": "To hold up its \"pants\" of steel!"
  },
  {
    "q": "What’s the favorite food at Starrhong Port?",
    "a": "\"Star-fruit,\" obviously."
  },
  {
    "q": "Why is Starr Dream City the best place for a nap?",
    "a": "Because the trains there are so \"dreamy.\""
  },
  {
    "q": "What did the train say to the traffic jam?",
    "a": "\"Sorry, can't relate, I'm too high up for that!\""
  },
  {
    "q": "Why did the train at Starr University get a library card?",
    "a": "It wanted to check out some \"travel\" books."
  },
  {
    "q": "Why are the trains so tall?",
    "a": "Because they’re \"high-minded\" commuters."
  },
  {
    "q": "What do you call a SkyRail train that works in a zoo?",
    "a": "A \"Zoo-rail.\""
  },
  {
    "q": "Why did the train at Starr Lake bring an umbrella?",
    "a": "It heard the \"border\" was a bit damp."
  },
  {
    "q": "What’s a SkyRail train’s favorite exercise?",
    "a": "\"Sky-lates.\""
  },
  {
    "q": "Why is the Airport T1 train so busy?",
    "a": "It has to keep up with all the fancy \"flights\"."
  },
  {
    "q": "What did the train say when it reached MF Tail?",
    "a": "\"Well, that's the end of the line for me!\""
  },
  {
    "q": "Why was the train at Starr Dream City so happy?",
    "a": "It was living the dream."
  },
  {
    "q": "What’s the most mysterious station?",
    "a": "The One Starr—there can be only one!"
  },
  {
    "q": "Why did the train at UniStarr South take a vacation?",
    "a": "It wanted to go somewhere \"sunny.\""
  },
  {
    "q": "Why did the train at Starrleyland bring a camera?",
    "a": "It wanted to take \"Starr-pictures.\""
  },
  {
    "q": "Why are the trains on the SkyRail so fast?",
    "a": "They don't have any road-blocks!"
  },
  {
    "q": "What do you call a train that loves to gossip?",
    "a": "A \"Chatter-train.\""
  },
  {
    "q": "Why did the train at Starr Space City take a rocket?",
    "a": "It wanted to reach for the stars."
  },
  {
    "q": "Why did the train at Starr Lake start a business?",
    "a": "It wanted to \"border\" on success."
  },
  {
    "q": "Why is the train at Golden Island so shiny?",
    "a": "It’s polished by the ego of the passengers."
  },
  {
    "q": "Why did the train at Starrhong Port watch the clock?",
    "a": "It didn't want to miss the midnight train."
  },
  {
    "q": "Why did the train at Starr Dream City bring a telescope?",
    "a": "To see if its dreams were actually coming true."
  },
  {
    "q": "Why is the train at Airport T2 so noisy?",
    "a": "It’s always making announcements."
  },
  {
    "q": "What do you call a train that works in a construction site?",
    "a": "A \"Hard-Hat-Rail.\""
  },
  {
    "q": "Why did the train at Starr Lake wear a hat?",
    "a": "It didn't want to get sun-burned by the \"starr.\""
  },
  {
    "q": "What’s the favorite movie of a SkyRail train?",
    "a": "\"The Fast and the Furriest.\""
  },
  {
    "q": "Why did the train at Starr-li take a dance class?",
    "a": "It wanted to \"step\" in time with the schedule."
  },
  {
    "q": "Why is the Airport T1 station so good at puzzles?",
    "a": "It’s always putting pieces (passengers) in the right place."
  },
  {
    "q": "What did the train say to the station at MF Tail?",
    "a": "\"You're really at the tail end of my journey!\""
  },
  {
    "q": "Why did the train at Starr Space City take a nap?",
    "a": "It was tired of all the \"out-of-this-world\" travel."
  },
  {
    "q": "What do you call a train that loves to read?",
    "a": "A \"Book-Rail.\""
  },
  {
    "q": "Why did the train at Starrtin bring a map?",
    "a": "It didn't want to get lost in its own tracks."
  },
  {
    "q": "Why is the SkyRail the best mode of transport?",
    "a": "Because even when you're stuck, you're at least looking down on everyone else!"
  }
];
