import { useState } from "react";
import { StarrIcon, Price } from "./Starr";

export type FareOption = { key: string; label: string; labelZh: string; amount: number };

export function PurchaseModal({
  from,
  to,
  options,
  balance,
  onCancel,
  onConfirm,
}: {
  from: { zh: string; en: string; id: string };
  to: { zh: string; en: string; id: string };
  options: FareOption[];
  balance: number;
  onCancel: () => void;
  onConfirm: (opt: FareOption) => void | Promise<void>;
}) {
  const [selected, setSelected] = useState<FareOption>(options[0]);
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const insufficient = balance < selected.amount;

  async function commit() {
    setBusy(true);
    try {
      await onConfirm(selected);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[75] bg-black/60 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-5 space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-xl">🛒</span>
          <h2 className="text-lg font-bold">購買車票 Buy Ticket</h2>
        </div>
        <div className="text-sm">
          <div>
            <span className="font-bold">{from.zh}</span> {from.en} ({from.id})
          </div>
          <div className="text-slate-400 text-xs">↓</div>
          <div>
            <span className="font-bold">{to.zh}</span> {to.en} ({to.id})
          </div>
        </div>
        <div className="text-xs text-slate-600 flex items-center gap-1">
          目前結餘 Balance: <Price amount={balance} />
        </div>
        <div className="space-y-2">
          {options.map((o) => (
            <button
              key={o.key}
              onClick={() => setSelected(o)}
              className={`w-full flex items-center justify-between rounded-md border px-3 py-2 text-left ${
                selected.key === o.key
                  ? "border-[#0a2540] bg-slate-50"
                  : "border-slate-200 hover:border-slate-400"
              }`}
            >
              <div>
                <div className="font-bold text-sm">{o.labelZh}</div>
                <div className="text-xs text-slate-500">{o.label}</div>
              </div>
              <div className="flex items-center gap-1 font-bold">
                <StarrIcon size={14} />
                {o.amount}
              </div>
            </button>
          ))}
        </div>

        {!confirming ? (
          <div className="flex gap-2">
            <button
              onClick={onCancel}
              className="flex-1 rounded-md bg-slate-100 py-2 text-sm font-medium hover:bg-slate-200"
            >
              取消 Cancel
            </button>
            <button
              onClick={() => setConfirming(true)}
              className="flex-1 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white py-2 text-sm font-bold"
            >
              🛒 BUY TICKET 購票
            </button>
          </div>
        ) : insufficient ? (
          <div className="space-y-2">
            <div className="rounded-md bg-red-50 border border-red-200 text-red-800 text-sm p-3 font-semibold">
              星幣不足 Insufficient Starrs
              <div className="text-xs font-normal mt-1">
                需要 Need <Price amount={selected.amount} /> · 目前 Have{" "}
                <Price amount={balance} />
              </div>
            </div>
            <button
              onClick={() => setConfirming(false)}
              className="w-full rounded-md bg-slate-900 text-white py-2 text-sm font-medium"
            >
              返回 Back
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="rounded-md bg-amber-50 border border-amber-200 text-amber-900 text-sm p-3">
              確認扣除 <b>{selected.amount}</b> Starrs 購買 <b>{selected.labelZh}</b>{" "}
              車票？
              <br />
              Confirm deducting <b>{selected.amount}</b> Starrs for a{" "}
              <b>{selected.label}</b> ticket?
            </div>
            <div className="flex gap-2">
              <button
                disabled={busy}
                onClick={() => setConfirming(false)}
                className="flex-1 rounded-md bg-slate-100 py-2 text-sm font-medium hover:bg-slate-200 disabled:opacity-50"
              >
                取消 Cancel
              </button>
              <button
                disabled={busy}
                onClick={commit}
                className="flex-1 rounded-md bg-[#0a2540] text-white py-2 text-sm font-bold disabled:opacity-50"
              >
                {busy ? "…" : "確認 Confirm"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}