import { useState } from "react";

type Tab = "credits" | "privacy" | "terms" | "refund";

const TABS: { key: Tab; label: string }[] = [
  { key: "credits", label: "Credits · 工作人員" },
  { key: "privacy", label: "Privacy · 私隱政策" },
  { key: "terms", label: "Terms · 服務條款" },
  { key: "refund", label: "Refund · 退款政策" },
];

export function InfoDialog({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Tab>("credits");
  return (
    <div className="fixed inset-0 z-[96] bg-black/70 flex items-start md:items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl my-4 flex flex-col max-h-[95vh]">
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 sticky top-0 bg-white rounded-t-xl">
          <h2 className="text-lg font-black text-slate-900">
            ℹ️ Information · 資訊
          </h2>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 text-xl font-bold flex items-center justify-center"
          >
            ×
          </button>
        </div>
        <div className="flex overflow-x-auto border-b border-slate-200 bg-slate-50 shrink-0">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`px-3 py-2 text-xs md:text-sm font-semibold whitespace-nowrap ${
                tab === t.key
                  ? "text-fuchsia-700 border-b-2 border-fuchsia-500 bg-white"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="p-4 md:p-6 overflow-y-auto text-sm text-slate-800 leading-relaxed">
          {tab === "credits" && <Credits />}
          {tab === "privacy" && <Privacy />}
          {tab === "terms" && <Terms />}
          {tab === "refund" && <Refund />}
        </div>
      </div>
    </div>
  );
}

function Credits() {
  return (
    <div className="space-y-3">
      <h3 className="text-xl font-black text-slate-900">SkyRail.Game</h3>
      <p className="text-slate-600">
        Everything — concept, design, art, operation, and financial — by
        <b> VStarr Game Productions</b>.
      </p>
      <ul className="list-disc pl-5 space-y-1">
        <li><b>Concept & Design:</b> VStarr Game Productions</li>
        <li><b>Art & UI:</b> VStarr Game Productions</li>
        <li><b>Music & Sound:</b> VStarr Game Productions</li>
        <li><b>Operation & Live Service:</b> VStarr Game Productions</li>
        <li><b>Financial & Publishing:</b> VStarr Game Productions</li>
        <li><b>Payment Processing:</b> Paddle</li>
      </ul>
      <p className="text-xs text-slate-500 pt-2">
        © {new Date().getFullYear()} VStarr Game Productions. All rights
        reserved. "SkyRail" is a fictional transit network — any resemblance to
        real systems is coincidental.
      </p>
    </div>
  );
}

function Privacy() {
  return (
    <div className="space-y-3">
      <h3 className="text-xl font-black text-slate-900">Privacy Policy</h3>
      <p className="text-xs text-slate-500">Last Updated: July 8, 2026</p>
      <Section title="1. Data Controller">
        VStarr Game Productions ("we," "us," or "our") is the operator of the
        SkyRail.Game Service.
      </Section>
      <Section title="2. Information Collected">
        <ul className="list-disc pl-5 space-y-1">
          <li>
            <b>Account Data:</b> We collect your username and password hash upon
            registration to manage your account and track game progress.
          </li>
          <li>
            <b>Gameplay Metrics:</b> We collect data regarding your performance,
            such as "Starr" totals and route completion, to maintain
            leaderboards and provide the service.
          </li>
          <li>
            <b>Transaction Data:</b> We do not collect or store full credit card
            numbers. Payment processing is handled by third-party secure payment
            gateways (e.g., Paddle). We receive confirmation of successful
            transactions and associated metadata to fulfill digital product
            delivery.
          </li>
        </ul>
      </Section>
      <Section title="3. Data Usage">
        Collected data is used exclusively to facilitate account
        authentication, provide the game experience, support leaderboard
        functionality, and process payments.
      </Section>
      <Section title="4. Data Security">
        We implement industry-standard security measures to protect your
        information.
      </Section>
      <Section title="5. Third-Party Disclosure">
        We do not sell, trade, or rent personal data to third parties. Data is
        shared with service providers only as necessary to perform essential
        functions (such as payment processing and hosting).
      </Section>
      <Section title="6. Your Rights">
        You may request access to, correction of, or deletion of your personal
        data by contacting us at{" "}
        <a
          className="text-fuchsia-700 underline"
          href="mailto:sewingstarpersonal@gmail.com"
        >
          sewingstarpersonal@gmail.com
        </a>
        .
      </Section>
    </div>
  );
}

function Terms() {
  return (
    <div className="space-y-3">
      <h3 className="text-xl font-black text-slate-900">Terms of Service</h3>
      <p className="text-xs text-slate-500">Last Updated: July 8, 2026</p>
      <Section title="1. Acceptance of Terms">
        By creating an account or accessing the Service, you signify your full
        agreement to these Terms of Service.
      </Section>
      <Section title="2. Eligibility">
        Use of the Service is limited to individuals aged 10 years or older.
      </Section>
      <Section title="3. Anti-Cheat and Fair Play">
        The integrity of the competitive environment is essential. The
        following actions are strictly prohibited:
        <ul className="list-disc pl-5 space-y-1 mt-1">
          <li>
            The use of unauthorized automation, including bots, macros,
            autoclickers, and scripting tools.
          </li>
          <li>
            Modification of game files, reverse-engineering, or bypassing
            security protocols.
          </li>
          <li>
            Exploiting game mechanics to gain an unfair advantage on the
            leaderboards.
          </li>
        </ul>
        <p className="mt-2">
          <b>Consequences:</b> Any violation of these terms will result in
          immediate, permanent account termination by VStarr Game Productions
          without prior notice or right of appeal.
        </p>
      </Section>
      <Section title="4. Virtual Currency (Starrs)">
        "Starrs" are virtual items with no monetary value outside of the
        SkyRail.Game ecosystem. They cannot be transferred, exchanged, sold, or
        redeemed for legal tender. Skin Tokens, Starrboxes, and any other
        in-game items are likewise virtual and non-refundable in monetary form.
      </Section>
      <Section title="5. Payment and Merchant of Record">
        All transactions are processed by <b>Paddle.com Market Ltd</b>, our
        authorized reseller and Merchant of Record. By making a purchase, you
        agree to Paddle's{" "}
        <a
          className="text-fuchsia-700 underline"
          href="https://www.paddle.com/legal/checkout-buyer-terms"
          target="_blank"
          rel="noopener noreferrer"
        >
          Buyer Terms
        </a>
        . Paddle is responsible for billing, tax, invoicing, refunds, and
        customer payment support. VStarr Game Productions receives net
        proceeds after Paddle's fees and applicable taxes.
      </Section>
      <Section title="6. Account Responsibility">
        You are solely responsible for all activities occurring under your
        account and for maintaining the confidentiality of your login
        credentials.
      </Section>
      <Section title="7. Modification of Terms">
        We reserve the right to amend these terms at our discretion. Continued
        use of the Service following such changes constitutes your acceptance
        of the updated terms.
      </Section>
    </div>
  );
}




function Refund() {
  return (
    <div className="space-y-3">
      <h3 className="text-xl font-black text-slate-900">Refund Policy</h3>
      <p className="text-xs text-slate-500">Last Updated: July 10, 2026</p>
      <Section title="1. Merchant of Record">
        As the Merchant of Record, <b>Paddle.com Market Ltd</b> handles all
        payment inquiries, billing questions, and refund requests for
        SkyRail.Game purchases. To request a refund or inquire about a
        transaction, please use the{" "}
        <a
          className="text-fuchsia-700 underline"
          href="https://paddle.net"
          target="_blank"
          rel="noopener noreferrer"
        >
          Paddle Support Center (paddle.net)
        </a>{" "}
        or the link provided in your purchase confirmation email. We do not
        process manual refunds for virtual currency or digital items directly.
      </Section>
      <Section title="2. General Principle">
        Because purchased items (Starrs, Starrboxes, Skin Tokens, Starter
        Packs, boosters) are delivered instantly and can be consumed
        immediately, all sales are considered final once delivered. Paddle
        may, at its discretion and in line with its own refund policy,
        approve refunds for unused purchases within a reasonable window.
      </Section>
      <Section title="3. Eligibility">
        Refunds are typically considered where:
        <ul className="list-disc pl-5 space-y-1 mt-1">
          <li>
            <b>Technical Failure:</b> A verified failure of the Service to
            credit purchased items to your account.
          </li>
          <li>
            <b>Unauthorized Transactions:</b> Evidence that an account was
            accessed without the owner's permission to make the purchase.
          </li>
        </ul>
      </Section>
      <Section title="4. Reversal Consequences">
        When a refund or reversal is approved, we will reverse the associated
        entitlements from your account: deducting Starrs granted by the
        purchase, cancelling active boosters, removing Starrbox credits, and
        re-locking any purchased line unlocks. If the reversal would result
        in a negative balance, your balance is clamped to zero.
      </Section>
      <Section title="5. Exclusions">
        Neither we nor Paddle typically provide refunds for:
        <ul className="list-[lower-alpha] pl-6 space-y-1 mt-1">
          <li>"Buyer's remorse" or change of mind after consuming items.</li>
          <li>Accidental purchases where items have already been used.</li>
          <li>Dissatisfaction with game mechanics, difficulty, or randomised
              rewards (including Starrbox outcomes).</li>
        </ul>
      </Section>
      <Section title="6. Chargeback Notice">
        Initiating a chargeback or payment dispute through your financial
        institution <b>without first contacting Paddle's support system</b> is
        a violation of these terms and may lead to immediate account review,
        suspension, or permanent termination.
      </Section>
      <Section title="7. Final Decision">
        Refund decisions are made by Paddle in accordance with its policies.
        Any goodwill in-game adjustments made by VStarr Game Productions are
        reviewed on a case-by-case basis and remain at our sole discretion.
      </Section>
    </div>
  );
}


function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="font-bold text-slate-900 mt-3">{title}</h4>
      <div className="mt-1 text-slate-700">{children}</div>
    </div>
  );
}
