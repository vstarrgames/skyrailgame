import { useEffect, useState } from "react";
import { fetchLeaderboards, formatHkd, type LbRow } from "@/lib/wallet";
import { StarrIcon } from "./Starr";

export function Leaderboard({ onClose }: { onClose: () => void }) {
  const [data, setData] = useState<{
    trips: LbRow[];
    firstClass: LbRow[];
    earned: LbRow[];
    spent: LbRow[];
  } | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    void fetchLeaderboards()
      .then(setData)
      .catch((e) => setErr((e as Error).message));
  }, []);

  return (
    <div className="fixed inset-0 z-[95] bg-black/70 flex items-center justify-center p-3 overflow-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-5xl w-full p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-black">🏆 排行榜 · Leaderboards</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 font-bold"
          >
            ✕
          </button>
        </div>
        {err && <div className="text-red-600 text-sm mt-2">{err}</div>}
        {!data && !err && <div className="text-sm text-slate-500 mt-3">Loading…</div>}
        {data && (
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
            <Panel
              title="旅程次數 · Most Trips"
              rows={data.trips}
              valueLabel="trips"
              icon="🚄"
            />
            <Panel
              title="頭等旅程 · Most First Class"
              rows={data.firstClass}
              valueLabel="first-class"
              icon="🥇"
            />
            <Panel
              title="累計星幣 · Most Starrs Earned"
              rows={data.earned}
              valueLabel="starrs"
              icon="✨"
              starr
            />
            <Panel
              title="頂級支持者 · Top HK$ Spenders"
              rows={data.spent}
              valueLabel=""
              icon="💎"
              money
            />
          </div>
        )}
        <div className="text-[10px] text-slate-500 mt-3 text-center">
          Top 5 players · Admin accounts excluded
        </div>
      </div>
    </div>
  );
}

function Panel({
  title,
  rows,
  icon,
  valueLabel,
  starr,
  money,
}: {
  title: string;
  rows: LbRow[];
  icon: string;
  valueLabel: string;
  starr?: boolean;
  money?: boolean;
}) {
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
      <div className="text-xs font-extrabold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
        <span>{icon}</span>
        {title}
      </div>
      <ol className="mt-2 space-y-1.5">
        {rows.length === 0 && (
          <li className="text-xs text-slate-400">No data yet · 暫無資料</li>
        )}
        {rows.map((r, i) => {
          const val = (r.total ?? r.count ?? 0) as number;
          return (
            <li
              key={r.user_id}
              className={`flex items-center justify-between rounded px-2 py-1.5 ${
                i === 0 ? "bg-amber-100" : i === 1 ? "bg-slate-200" : i === 2 ? "bg-orange-100" : "bg-white"
              }`}
            >
              <span className="flex items-center gap-2 min-w-0">
                <span className="w-6 text-sm font-black text-slate-500">
                  {i + 1}.
                </span>
                <span className="truncate font-semibold text-sm">
                  {r.display_name || "player"}
                </span>
              </span>
              <span className="tabular-nums font-bold text-sm inline-flex items-center gap-1">
                {starr && <StarrIcon size={12} />}
                {money ? formatHkd(val) : val.toLocaleString()}
                {!starr && !money && valueLabel && (
                  <span className="text-[10px] text-slate-400 ml-1">{valueLabel}</span>
                )}
              </span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

