import { useState } from "react";
import { redeemSkinTokens, type Profile } from "@/lib/wallet";
import { StarrIcon } from "./Starr";

export function TokenWalletDialog({
  onClose,
  profile,
  onProfileUpdate,
}: {
  onClose: () => void;
  profile: Profile | null;
  onProfileUpdate: (patch: Partial<Profile>) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const tokens = profile?.skin_tokens ?? 0;

  async function redeemAll() {
    if (tokens < 1 || busy) return;
    setBusy(true);
    setErr(null);
    try {
      const r = await redeemSkinTokens(tokens);
      onProfileUpdate({ balance: r.new_balance, skin_tokens: r.new_skin_tokens });
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[96] bg-black/70 flex items-start sm:items-center justify-center p-3 overflow-y-auto">
      <div className="relative w-full max-w-sm bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-2xl border border-emerald-400/40 shadow-2xl my-4">
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute top-2 right-2 w-9 h-9 rounded-full bg-black/60 hover:bg-black/80 text-white text-xl font-bold flex items-center justify-center"
        >
          ✕
        </button>
        <div className="p-5 text-center">
          <h2 className="text-xl font-black">🎫 Token Wallet · 代幣錢包</h2>
          <p className="text-xs opacity-70 mt-1">
            Skin Tokens from Starrboxes. 1 Token = 200 Starrs.
          </p>
          <div className="my-6">
            <div className="text-6xl">🎫</div>
            <div className="mt-2 text-4xl font-black">{tokens}</div>
            <div className="text-xs opacity-70">Skin Tokens · 外觀代幣</div>
          </div>
          <div className="rounded-md bg-white/10 p-3 text-xs mb-3 inline-flex items-center gap-2">
            Convert value: <StarrIcon size={12} />
            <b>{tokens * 200}</b> Starrs
          </div>
          {err && (
            <div className="mb-3 text-xs bg-red-500/20 border border-red-400/40 text-red-100 rounded p-2">
              {err}
            </div>
          )}
          <button
            onClick={redeemAll}
            disabled={tokens < 1 || busy}
            className="w-full rounded-md bg-emerald-500 hover:bg-emerald-600 py-2.5 text-sm font-black disabled:opacity-40"
          >
            {busy ? "…" : `Redeem All · 全部兌換 (+${tokens * 200} Starrs)`}
          </button>
          <p className="mt-3 text-[10px] opacity-60">
            Cosmetic skins are not yet available. Redeem tokens for Starrs anytime.
          </p>
        </div>
      </div>
    </div>
  );
}
