import { useEffect, useState } from "react";
import {
  adminBanUser,
  adminListUsers,
  adminStats,
  adminUnbanUser,
  adminStartRush,
  getCurrentRush,
  type AdminUserRow,
  type RushRow,
} from "@/lib/wallet";
import { adminDeleteUser } from "@/lib/admin.functions";
import { useServerFn } from "@tanstack/react-start";

function fmt(dt: string | null) {
  if (!dt) return "—";
  return new Date(dt).toLocaleString("en-GB", { timeZone: "Asia/Hong_Kong" });
}

export function AdminPanel({ onClose }: { onClose: () => void }) {
  const [users, setUsers] = useState<AdminUserRow[]>([]);
  const [stats, setStats] = useState<{ total_users: number; in_transit: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [modUser, setModUser] = useState<AdminUserRow | null>(null);
  const [showRush, setShowRush] = useState(false);
  const [activeRush, setActiveRush] = useState<RushRow | null>(null);
  const del = useServerFn(adminDeleteUser);

  useEffect(() => { getCurrentRush().then(setActiveRush).catch(() => {}); }, []);

  async function refresh() {
    setLoading(true);
    try {
      const [u, s] = await Promise.all([adminListUsers(), adminStats()]);
      setUsers(u);
      setStats(s);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void refresh();
  }, []);

  async function handleDelete(row: AdminUserRow) {
    if (!confirm(`Delete ${row.email}? 確定刪除？`)) return;
    try {
      await del({ data: { userId: row.user_id } });
      await refresh();
    } catch (e) {
      alert((e as Error).message);
    }
  }

  const activePct = stats && stats.total_users > 0
    ? Math.round((stats.in_transit / stats.total_users) * 100)
    : 0;
  const bannedCount = users.filter(
    (u) => u.banned_permanent || (u.banned_until && new Date(u.banned_until).getTime() > Date.now()),
  ).length;
  const totalBalance = users.reduce((n, u) => n + (u.balance || 0), 0);

  return (
    <div className="fixed inset-0 z-[95] bg-slate-950/90 backdrop-blur overflow-auto">
      <div className="mx-auto max-w-6xl bg-slate-900 text-slate-100 border border-slate-800 shadow-2xl">
        {/* Top bar */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-emerald-500 text-slate-950 grid place-items-center font-black text-sm">
              ADM
            </div>
            <div>
              <div className="text-sm font-bold tracking-wider">SkyRail.Game — Admin Console</div>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">
                Restricted · 僅限管理員 · Live
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowRush(true)}
              className="text-xs px-2 py-1 rounded bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold border border-amber-300"
              title="Start Special Rush · 開始限時倍數活動"
            >
              🚀 Start Rush 限時活動
            </button>
            <button
              onClick={() => void refresh()}
              className="text-xs px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700"
            >
              ↻ Refresh
            </button>
            <button
              onClick={onClose}
              className="text-xs px-3 py-1 rounded bg-slate-100 text-slate-900 font-bold"
            >
              Close ✕
            </button>
          </div>
        </div>

        {activeRush && new Date(activeRush.ends_at).getTime() > Date.now() && (
          <div className="px-5 py-2 text-xs bg-amber-500/15 border-b border-amber-500/40 text-amber-200">
            🚀 Active Rush · 進行中: <b>{activeRush.multiplier}×</b> until {new Date(activeRush.ends_at).toLocaleString("en-GB", { timeZone: "Asia/Hong_Kong" })}
          </div>
        )}

        {/* KPI strip */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-px bg-slate-800">
          <Kpi label="Users" value={stats?.total_users ?? "—"} />
          <Kpi label="Active Profiles" value={users.length} />
          <Kpi label="In-Transit" value={stats?.in_transit ?? "—"} accent="emerald" />
          <Kpi label="Banned" value={bannedCount} accent={bannedCount ? "red" : undefined} />
          <Kpi label="Σ Starrs" value={totalBalance.toLocaleString()} accent="amber" />
        </div>

        {/* Activity bar chart */}
        <div className="px-5 py-3 border-b border-slate-800">
          <div className="flex items-center justify-between text-[10px] uppercase tracking-widest text-slate-500 mb-1.5">
            <span>Transit Load</span>
            <span>{activePct}%</span>
          </div>
          <div className="h-2 rounded bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400"
              style={{ width: `${activePct}%` }}
            />
          </div>
        </div>

        {err && <div className="text-red-400 text-xs px-5 py-2">{err}</div>}

        {/* Table */}
        <div className="p-3">
          {loading ? (
            <div className="text-xs text-slate-400 p-4">Loading…</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-[11px] font-mono">
                <thead className="bg-slate-800/60 text-slate-300">
                  <tr className="text-left">
                    <th className="px-2 py-1.5">Email</th>
                    <th className="text-right px-2 py-1.5">Balance</th>
                    <th className="px-2 py-1.5">Created</th>
                    <th className="px-2 py-1.5">Status</th>
                    <th className="text-right px-2 py-1.5">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => {
                    const banned =
                      u.banned_permanent ||
                      (u.banned_until && new Date(u.banned_until).getTime() > Date.now());
                    return (
                      <tr key={u.user_id} className="border-t border-slate-800 hover:bg-slate-800/40">
                        <td className="px-2 py-1.5">{u.email}</td>
                        <td className="px-2 py-1.5 text-right tabular-nums text-amber-300">
                          {u.balance}
                        </td>
                        <td className="px-2 py-1.5 text-slate-400">{fmt(u.created_at)}</td>
                        <td className="px-2 py-1.5">
                          <div className="flex flex-wrap gap-1">
                            {u.is_in_transit && <Pill color="amber">TRANSIT</Pill>}
                            {banned ? (
                              <Pill color="red">
                                {u.banned_permanent ? "PERM BAN" : `BAN → ${fmt(u.banned_until)}`}
                              </Pill>
                            ) : (
                              !u.is_in_transit && <span className="text-slate-500">idle</span>
                            )}
                          </div>
                        </td>
                        <td className="px-2 py-1.5 text-right space-x-1 whitespace-nowrap">
                          {banned && (
                            <button
                              onClick={async () => {
                                await adminUnbanUser(u.user_id);
                                await refresh();
                              }}
                              className="rounded bg-emerald-600 hover:bg-emerald-500 text-white px-1.5 py-0.5"
                            >
                              Unban
                            </button>
                          )}
                          <button
                            onClick={() => setModUser(u)}
                            className="rounded bg-amber-500 hover:bg-amber-400 text-slate-900 px-1.5 py-0.5"
                          >
                            Ban
                          </button>
                          <button
                            onClick={() => handleDelete(u)}
                            className="rounded bg-red-600 hover:bg-red-500 text-white px-1.5 py-0.5"
                          >
                            Del
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {modUser && (
        <ModerateDialog
          user={modUser}
          onClose={() => setModUser(null)}
          onDone={async () => {
            setModUser(null);
            await refresh();
          }}
        />
      )}
      {showRush && (
        <RushDialog
          onClose={() => setShowRush(false)}
          onStarted={(r) => { setActiveRush(r); setShowRush(false); }}
        />
      )}
    </div>
  );
}

function RushDialog({
  onClose,
  onStarted,
}: {
  onClose: () => void;
  onStarted: (r: RushRow) => void;
}) {
  const [hours, setHours] = useState(1);
  const [mult, setMult] = useState<2 | 3 | 4>(2);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const opts: number[] = [1, 2, 3, 4, 6, 8, 12, 24];
  async function submit() {
    setBusy(true); setErr(null);
    try {
      const r = await adminStartRush(hours * 60, mult);
      onStarted(r);
    } catch (e) { setErr((e as Error).message); }
    finally { setBusy(false); }
  }
  return (
    <div className="fixed inset-0 z-[97] bg-black/70 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-sm w-full p-5">
        <h3 className="text-lg font-bold">🚀 Start Special Rush · 開始限時活動</h3>
        <p className="text-xs text-slate-500 mt-1">
          All players get bonus Starrs for a limited time. Stacks with weekend / monthly events.
          所有玩家在指定時段獲得額外星幣，可與週末/每月1號活動疊加。
        </p>
        <div className="mt-4">
          <div className="text-xs font-semibold text-slate-700">Multiplier · 倍數</div>
          <div className="grid grid-cols-3 gap-2 mt-1.5">
            {[2, 3, 4].map((n) => (
              <button
                key={n}
                onClick={() => setMult(n as 2 | 3 | 4)}
                className={`py-2 rounded font-black text-sm border ${
                  mult === n ? "bg-fuchsia-600 text-white border-fuchsia-700" : "bg-slate-100 border-slate-200"
                }`}
              >
                {n}×
              </button>
            ))}
          </div>
        </div>
        <div className="mt-4">
          <div className="text-xs font-semibold text-slate-700">Duration · 時長</div>
          <div className="grid grid-cols-4 gap-1.5 mt-1.5">
            {opts.map((h) => (
              <button
                key={h}
                onClick={() => setHours(h)}
                className={`py-1.5 rounded text-xs font-bold border ${
                  hours === h ? "bg-slate-900 text-white border-slate-900" : "bg-slate-100 border-slate-200"
                }`}
              >
                {h === 24 ? "1d" : `${h}h`}
              </button>
            ))}
          </div>
        </div>
        {err && <div className="text-red-600 text-xs mt-3">{err}</div>}
        <div className="flex gap-2 mt-5">
          <button onClick={onClose} className="flex-1 rounded bg-slate-100 py-2 text-sm">Cancel 取消</button>
          <button
            disabled={busy}
            onClick={submit}
            className="flex-1 rounded bg-fuchsia-600 text-white py-2 text-sm font-bold disabled:opacity-50"
          >
            {busy ? "…" : `Start ${mult}× · ${hours}h`}
          </button>
        </div>
      </div>
    </div>
  );
}

function Kpi({
  label,
  value,
  accent,
}: {
  label: string;
  value: number | string;
  accent?: "emerald" | "amber" | "red";
}) {
  const c =
    accent === "emerald"
      ? "text-emerald-300"
      : accent === "amber"
        ? "text-amber-300"
        : accent === "red"
          ? "text-red-300"
          : "text-slate-100";
  return (
    <div className="bg-slate-900 px-4 py-3">
      <div className="text-[9px] uppercase tracking-widest text-slate-500">{label}</div>
      <div className={`text-xl font-black tabular-nums ${c}`}>{value}</div>
    </div>
  );
}

function Pill({ color, children }: { color: "amber" | "red"; children: React.ReactNode }) {
  const c =
    color === "amber"
      ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
      : "bg-red-500/20 text-red-300 border-red-500/40";
  return (
    <span className={`inline-block px-1.5 py-0.5 rounded border text-[9px] font-bold ${c}`}>
      {children}
    </span>
  );
}

function ModerateDialog({
  user,
  onClose,
  onDone,
}: {
  user: AdminUserRow;
  onClose: () => void;
  onDone: () => void;
}) {
  const [preset, setPreset] = useState<"1m" | "1h" | "1d" | "7d" | "perm">("1h");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit() {
    setBusy(true);
    setErr(null);
    try {
      let until: Date | null = null;
      let permanent = false;
      const now = Date.now();
      if (preset === "1m") until = new Date(now + 60 * 1000);
      else if (preset === "1h") until = new Date(now + 60 * 60 * 1000);
      else if (preset === "1d") until = new Date(now + 24 * 60 * 60 * 1000);
      else if (preset === "7d") until = new Date(now + 7 * 24 * 60 * 60 * 1000);
      else permanent = true;
      await adminBanUser(user.user_id, until, permanent);
      onDone();
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  const opts: [typeof preset, string][] = [
    ["1m", "1 minute · 1 分鐘"],
    ["1h", "1 hour · 1 小時"],
    ["1d", "1 day · 1 天"],
    ["7d", "7 days · 7 天"],
    ["perm", "Permanent · 永久"],
  ];

  return (
    <div className="fixed inset-0 z-[96] bg-black/70 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-sm w-full p-5">
        <h3 className="text-lg font-bold">Ban user 封禁用戶</h3>
        <p className="text-xs text-slate-500 break-all">{user.email}</p>
        <div className="mt-3 space-y-2">
          {opts.map(([k, l]) => (
            <label key={k} className="flex items-center gap-2 text-sm">
              <input
                type="radio"
                checked={preset === k}
                onChange={() => setPreset(k)}
              />
              {l}
            </label>
          ))}
        </div>
        {err && <div className="text-red-600 text-xs mt-2">{err}</div>}
        <div className="flex gap-2 mt-4">
          <button onClick={onClose} className="flex-1 rounded bg-slate-100 py-2 text-sm">
            Cancel 取消
          </button>
          <button
            disabled={busy}
            onClick={submit}
            className="flex-1 rounded bg-red-600 text-white py-2 text-sm font-semibold disabled:opacity-50"
          >
            {busy ? "…" : "Ban 封禁"}
          </button>
        </div>
      </div>
    </div>
  );
}

export function BanScreen({ until, permanent }: { until: string | null; permanent: boolean }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const remaining = until ? Math.max(0, new Date(until).getTime() - now) : 0;
  const s = Math.floor(remaining / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return (
    <div className="fixed inset-0 z-[97] bg-slate-950 text-white flex items-center justify-center p-6">
      <div className="max-w-md text-center">
        <div className="text-6xl">🚫</div>
        <h1 className="text-2xl font-extrabold mt-3">帳戶已被封禁 Account Banned</h1>
        <p className="text-sm text-slate-300 mt-2">
          您的帳戶目前無法使用系統。Your account cannot access the system at this time.
        </p>
        {permanent ? (
          <div className="mt-4 rounded bg-red-800/40 border border-red-500 p-3 font-bold">
            永久封禁 Permanent Ban
          </div>
        ) : (
          <div className="mt-4 rounded bg-red-800/40 border border-red-500 p-3">
            <div className="text-xs uppercase tracking-wider opacity-80">
              Remaining · 剩餘時間
            </div>
            <div className="text-2xl font-bold tabular-nums">
              {d}d {String(h).padStart(2, "0")}:{String(m).padStart(2, "0")}:
              {String(sec).padStart(2, "0")}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
