import starrIcon from "@/assets/starr-icon.webp.asset.json";

export function StarrIcon({ size = 14, className }: { size?: number; className?: string }) {
  return (
    <img
      src={starrIcon.url}
      alt=""
      width={size}
      height={size}
      className={"inline-block align-[-2px] " + (className ?? "")}
      draggable={false}
    />
  );
}

export function Price({
  amount,
  size = 14,
  className,
}: {
  amount: number | string;
  size?: number;
  className?: string;
}) {
  return (
    <span className={"inline-flex items-center gap-1 " + (className ?? "")}>
      <StarrIcon size={size} />
      <span className="tabular-nums">{amount}</span>
    </span>
  );
}