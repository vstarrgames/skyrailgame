import { useEffect, useRef, useState } from "react";
import menuMusic from "@/assets/menu_music.mp3.asset.json";
import gameMusic from "@/assets/game_music.mp3.asset.json";

/**
 * Background music controller.
 * - Plays menu music on loop unless `inGame` is true.
 * - When `inGame` (Starr Catcher / travel active), plays game music on loop.
 * Audio autoplay is unlocked on the first user interaction.
 */
export function MusicPlayer({ inGame, muted }: { inGame: boolean; muted: boolean }) {
  const menuRef = useRef<HTMLAudioElement | null>(null);
  const gameRef = useRef<HTMLAudioElement | null>(null);
  const [unlocked, setUnlocked] = useState(false);

  // Unlock playback on first user interaction (mobile autoplay policy).
  useEffect(() => {
    if (unlocked) return;
    const unlock = () => setUnlocked(true);
    window.addEventListener("pointerdown", unlock, { once: true });
    window.addEventListener("keydown", unlock, { once: true });
    window.addEventListener("touchstart", unlock, { once: true });
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
      window.removeEventListener("touchstart", unlock);
    };
  }, [unlocked]);

  useEffect(() => {
    const menu = menuRef.current;
    const game = gameRef.current;
    if (!menu || !game) return;
    menu.volume = 0.35;
    game.volume = 0.45;
    if (muted || !unlocked) {
      menu.pause();
      game.pause();
      return;
    }
    if (inGame) {
      menu.pause();
      void game.play().catch(() => {});
    } else {
      game.pause();
      void menu.play().catch(() => {});
    }
  }, [inGame, muted, unlocked]);

  return (
    <>
      <audio ref={menuRef} src={menuMusic.url} loop preload="auto" />
      <audio ref={gameRef} src={gameMusic.url} loop preload="auto" />
    </>
  );
}
