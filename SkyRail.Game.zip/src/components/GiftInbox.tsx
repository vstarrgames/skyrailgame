import { useEffect, useState } from "react";
import { listPendingGifts, claimStarrGifts, type PendingGift, type Profile } from "@/lib/wallet";
import { StarrIcon } from "./Starr";
import type { Session } from "@supabase/supabase-js";

export function GiftInbox({
  session,
  onProfileUpdate,
}: {
  session: Session | null;
  onProfileUpdate: (patch: Partial<Profile>) => void;
}) {
  const [gifts, setGifts] = useState<PendingGift[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (!session) return;
    setDismissed(false);
    listPendingGifts().then(setGifts).catch(() => setGifts([]));
  }, [session]);

  if (!session || !gifts || gifts.length === 0 || dismissed) return null;
  const total = gifts.reduce((n, g) => n + g.amount_net, 0);

  async function claim() {
    setBusy(true);
    setErr(null);
    try {
      const r = await claimStarrGifts();
      onProfileUpdate({ balance: r.new_balance });
      setGifts([]);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[98] bg-black/80 flex items-center justify-center p-3 overflow-y-auto">
      <div className="w-full max-w-md bg-gradient-to-br from-emerald-900 via-teal-900 to-cyan-900 rounded-2xl border border-emerald-300/50 shadow-2xl p-5 text-white my-4">
        <div className="text-center">
          <div className="text-5xl">🎁</div>
          <h2 className="text-2xl font-black mt-1">你收到禮物! · You Received Gifts!</h2>
          <p className="text-xs opacity-80 mt-1">
            以下玩家送了星幣給你 · Other players sent you Starrs
          </p>
        </div>
        <div className="mt-4 max-h-56 overflow-y-auto space-y-2">
          {gifts.map((g) => (
            <div
              key={g.id}
              className="flex items-center justify-between bg-white/10 rounded-lg px-3 py-2 border border-white/15"
            >
              <div className="min-w-0">
                <div className="font-bold truncate flex items-center gap-1">
                  {g.from_admin && (
                    <span className="text-[9px] font-black bg-amber-300 text-amber-950 px-1 rounded">
                      ADMIN
                    </span>
                  )}
                  {g.sender_name}
                </div>
                <div className="text-[10px] opacity-70">
                  {new Date(g.created_at).toLocaleString()}
                </div>
              </div>
              <div className="inline-flex items-center gap-1 font-black tabular-nums text-amber-300">
                +{g.amount_net} <StarrIcon size={14} />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 rounded-lg bg-black/30 border border-emerald-300/40 p-3 flex items-center justify-between">
          <span className="text-xs opacity-80 uppercase tracking-widest">Total · 總計</span>
          <span className="inline-flex items-center gap-1 text-2xl font-black text-amber-300 tabular-nums">
            {total} <StarrIcon size={20} />
          </span>
        </div>

        {err && <div className="text-xs bg-red-500/20 border border-red-400 rounded p-2 mt-2">{err}</div>}

        <div className="flex gap-2 mt-4">
          <button
            onClick={() => setDismissed(true)}
            className="flex-1 rounded-md bg-white/10 hover:bg-white/20 py-2.5 text-sm font-bold"
          >
            稍後 · Later
          </button>
          <button
            onClick={claim}
            disabled={busy}
            className="flex-1 rounded-md bg-gradient-to-r from-amber-400 to-orange-500 hover:brightness-110 text-slate-900 py-2.5 text-sm font-black disabled:opacity-50"
          >
            {busy ? "…" : `💫 領取 · Claim +${total}`}
          </button>
        </div>
      </div>
    </div>
  );
}
