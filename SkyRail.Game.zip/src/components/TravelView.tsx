import { useEffect, useMemo, useRef, useState } from "react";
import { StarrIcon } from "./Starr";
import {
  endJourney,
  isDoubleStarrEvent,
  isMonthlyStarrEvent,
  computeEventMultiplier,
  getCurrentRush,
  LINE_UNLOCKS,
  consumeBoost,
  useSession,
  useProfile,
  type RushRow,
} from "@/lib/wallet";

import standardBg from "@/assets/standard-class.png.asset.json";
import firstBg from "@/assets/first-class.png.asset.json";

export type StationStop = {
  id: string;
  en: string;
  zh: string;
  arriveAt: number;
  lineFromPrev?: string | null;
  transferHere?: boolean;
};

export type TravelData = {
  from: { id: string; en: string; zh: string };
  to: { id: string; en: string; zh: string };
  travelMinutes: number;
  seatClass: string;
  seatClassZh: string;
  isFirst: boolean;
  stops?: StationStop[];
  lineSequence?: string[];
  isDaily?: boolean;
};

type FloatingStarr = {
  id: number;
  x: number;
  y: number;
  speed: number; // px/s downward
  value: number;
};

type FeedbackKind = "miss" | "fair" | "good" | "mythic" | "legendary";
type Feedback = { id: number; x: number; y: number; kind: FeedbackKind };

const FEEDBACK_CFG: Record<
  FeedbackKind,
  { label: string; color: string; textShadow: string }
> = {
  miss:      { label: "MISS",      color: "#d1d5db", textShadow: "0 0 8px rgba(148,163,184,0.9)" },
  fair:      { label: "FAIR",      color: "#38bdf8", textShadow: "0 0 10px rgba(56,189,248,0.9)" },
  good:      { label: "GOOD",      color: "#34d399", textShadow: "0 0 10px rgba(52,211,153,0.9)" },
  mythic:    { label: "MYTHIC",    color: "#f43f5e", textShadow: "0 0 12px rgba(244,63,94,1)" },
  legendary: { label: "LEGENDARY", color: "#facc15", textShadow: "0 0 14px rgba(250,204,21,1)" },
};

const DIFFICULTY: Record<string, number> = Object.fromEntries(
  LINE_UNLOCKS.map((l) => [l.key, l.difficulty]),
);

export function TravelView({
  data,
  onFinished,
}: {
  data: TravelData;
  onFinished: (
    earned: number,
    newBalance: number | null,
    meta: { missCount: number; isDaily: boolean },
  ) => void;
}) {
  const totalMs = data.travelMinutes * 6 * 1000;
  const [elapsed, setElapsed] = useState(0);
  const [earned, setEarned] = useState(0);
  const earnedRef = useRef(0);
  const missCountRef = useRef(0);
  const [floats, setFloats] = useState<FloatingStarr[]>([]);
  const floatsRef = useRef<FloatingStarr[]>([]);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [missFlash, setMissFlash] = useState(false);
  const [interchange, setInterchange] = useState<{ ends: number; nextLine: string; nextStation: string } | null>(null);
  const startedRef = useRef(Date.now());
  const idSeqRef = useRef(1);
  const fbSeqRef = useRef(1);
  const containerRef = useRef<HTMLDivElement>(null);
  const finishingRef = useRef(false);
  const handledTransfersRef = useRef<Set<number>>(new Set());

  // Purchased Starr booster (gameplay-active timer). Snapshot at mount so
  // the multiplier is locked in for the trip; we bill the elapsed
  // gameplay time back to the server at the end of the round.
  const { session } = useSession();
  const { profile } = useProfile(session);
  const boostSnapshotRef = useRef<{ mult: number; remainingMs: number }>({ mult: 1, remainingMs: 0 });
  const boostAppliedRef = useRef(false);
  useEffect(() => {
    if (boostAppliedRef.current) return;
    if (profile && (profile.boost_multiplier ?? 1) > 1 && (profile.boost_remaining_ms ?? 0) > 0) {
      boostSnapshotRef.current = {
        mult: profile.boost_multiplier ?? 1,
        remainingMs: profile.boost_remaining_ms ?? 0,
      };
      boostAppliedRef.current = true;
    }
  }, [profile]);

  // Snapshot the admin special rush at journey start so mid-round changes don't shift multiplier.
  const rushSnapshotRef = useRef<RushRow | null>(null);
  useEffect(() => {
    getCurrentRush().then((r) => { rushSnapshotRef.current = r; }).catch(() => {});
  }, []);


  const LINE_BONUS: Record<string, number> = {
    L2: 4, L3: 6, L4: 8, L5: 10, L7: 13, L6: 16, AEX: 20,
  };
  const lineBonus = useMemo(() => {
    const seen = new Set<string>();
    (data.lineSequence ?? []).forEach((l) => seen.add(l));
    (data.stops ?? []).forEach((s) => { if (s.lineFromPrev) seen.add(s.lineFromPrev); });
    let sum = 0;
    seen.forEach((l) => { sum += LINE_BONUS[l] ?? 0; });
    return sum;
  }, [data.lineSequence, data.stops]);

  const stopsRt = useMemo(() => {
    if (!data.stops || data.stops.length === 0) return [];
    return data.stops.map((s) => ({ ...s, atMs: s.arriveAt * 6 * 1000 }));
  }, [data.stops]);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);

  useEffect(() => { floatsRef.current = floats; }, [floats]);

  // Master timer
  useEffect(() => {
    const id = setInterval(() => {
      const el = Date.now() - startedRef.current;
      setElapsed(el);
      if (el >= totalMs && !finishingRef.current) {
        finishingRef.current = true;
        clearInterval(id);
        void finish();
      }
      if (stopsRt.length > 0 && !interchange) {
        for (let i = 0; i < stopsRt.length; i++) {
          if (handledTransfersRef.current.has(i)) continue;
          const s = stopsRt[i];
          if (s.transferHere && el >= s.atMs && i < stopsRt.length - 1) {
            handledTransfersRef.current.add(i);
            const next = stopsRt[i + 1];
            const line = next.lineFromPrev ?? "";
            setInterchange({ ends: Date.now() + 15000, nextLine: line, nextStation: `${s.zh} ${s.en}` });
            startedRef.current += 15000;
            break;
          }
        }
      }
    }, 100);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [totalMs, stopsRt, interchange]);

  useEffect(() => {
    if (!interchange) return;
    const id = setTimeout(() => setInterchange(null), Math.max(0, interchange.ends - Date.now()));
    return () => clearTimeout(id);
  }, [interchange]);

  const currentLine = useMemo(() => {
    if (stopsRt.length === 0) return data.lineSequence?.[0] ?? "L1";
    let cur = stopsRt[1]?.lineFromPrev ?? "L1";
    for (let i = 1; i < stopsRt.length; i++) {
      if (elapsed >= stopsRt[i - 1].atMs) {
        cur = stopsRt[i].lineFromPrev ?? cur;
      }
    }
    return cur;
  }, [elapsed, stopsRt, data.lineSequence]);

  const nextStop = useMemo(() => {
    if (stopsRt.length === 0) return null;
    return stopsRt.find((s) => s.atMs > elapsed) ?? stopsRt[stopsRt.length - 1];
  }, [stopsRt, elapsed]);

  const lineDifficulty = DIFFICULTY[currentLine] ?? 5;
  const catcherMultFirst = data.isFirst ? 2 : 1;
  // First class: slower fall (advantage). Higher difficulty: faster fall.
  const speedMult = data.isFirst ? 0.7 : 1;
  const baseFall = 180 + lineDifficulty * 70; // px/s at random baseline
  const spawnIntervalMs = Math.max(180, 1100 - lineDifficulty * 100);

  // Spawn Starrs at TOP
  useEffect(() => {
    if (interchange) return;
    const id = setInterval(() => {
      setFloats((prev) => {
        if (prev.length > 10) return prev;
        const rect = containerRef.current?.getBoundingClientRect();
        const w = rect?.width ?? 800;
        return [
          ...prev,
          {
            id: idSeqRef.current++,
            x: 30 + Math.random() * Math.max(60, w - 60),
            y: -40,
            speed: (baseFall + Math.random() * 120) * speedMult,
            value: Math.random() < 0.5 ? 1 : 2,
          },
        ];
      });
    }, spawnIntervalMs);
    return () => clearInterval(id);
  }, [interchange, speedMult, spawnIntervalMs, baseFall]);

  // Animate downward
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const step = (t: number) => {
      const dt = (t - last) / 1000;
      last = t;
      const rect = containerRef.current?.getBoundingClientRect();
      const h = rect?.height ?? 600;
      setFloats((prev) =>
        prev
          .map((f) => ({ ...f, y: f.y + f.speed * dt }))
          .filter((f) => f.y < h + 60),
      );
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, []);

  async function finish() {
    // Daily challenges reward 1.5x on the catch total + line bonus.
    const raw = earnedRef.current + lineBonus;
    const total = data.isDaily ? Math.round(raw * 1.5) : raw;
    // Bill gameplay time against the purchased booster (only while playing).
    const boostSnap = boostSnapshotRef.current;
    if (boostSnap.mult > 1 && boostSnap.remainingMs > 0) {
      const played = Math.min(elapsed, boostSnap.remainingMs);
      if (played > 0) {
        try { await consumeBoost(played); } catch { /* non-fatal */ }
      }
    }
    const meta = { missCount: missCountRef.current, isDaily: !!data.isDaily };
    try {
      const r = await endJourney(total);
      onFinished(total, r.new_balance, meta);
    } catch {
      onFinished(total, null, meta);
    }
  }


  function pushFeedback(x: number, y: number, kind: FeedbackKind) {
    const id = fbSeqRef.current++;
    setFeedbacks((prev) => [...prev, { id, x, y, kind }]);
    setTimeout(() => {
      setFeedbacks((prev) => prev.filter((f) => f.id !== id));
    }, 700);
    if (kind === "miss") {
      missCountRef.current += 1;
      setMissFlash(true);
      setTimeout(() => setMissFlash(false), 160);
    }
  }

  function rankFromY(y: number, h: number): Exclude<FeedbackKind, "miss"> {
    // y is inside bottom 25% (y >= 0.75h). Bands:
    // >=0.9375h Legendary, >=0.875h Mythic, >=0.8125h Good, else Fair
    if (y >= h * 0.9375) return "legendary";
    if (y >= h * 0.875)  return "mythic";
    if (y >= h * 0.8125) return "good";
    return "fair";
  }

  function onScenePointerDown(e: React.PointerEvent<HTMLDivElement>) {
    if (interchange) return;
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;
    const zoneTop = rect.height * 0.75;
    if (py < zoneTop) return; // Clicks outside catch zone are ignored entirely.

    // Hit-test: find the closest Starr under the pointer (radius 34px).
    const HIT = 34;
    const current = floatsRef.current;
    let hit: FloatingStarr | null = null;
    let bestDist = Infinity;
    for (const f of current) {
      const dx = f.x - px;
      const dy = f.y - py;
      const d = Math.hypot(dx, dy);
      if (d <= HIT && d < bestDist) {
        bestDist = d;
        hit = f;
      }
    }

    if (!hit) {
      pushFeedback(px, py, "miss");
      return;
    }

    const kind = rankFromY(hit.y, rect.height);
    setFloats((prev) => prev.filter((x) => x.id !== hit!.id));

    const boostMult = (() => {
      const snap = boostSnapshotRef.current;
      // Only apply if the purchased time isn't exhausted mid-round.
      if (snap.mult > 1 && elapsed < snap.remainingMs) return snap.mult;
      return 1;
    })();
    const eventMult = computeEventMultiplier(new Date(), rushSnapshotRef.current);
    const mult = eventMult * catcherMultFirst * boostMult;
    const add = hit.value * mult;
    earnedRef.current += add;
    setEarned((v) => v + add);
    pushFeedback(px, py, kind);
  }

  const remaining = Math.max(0, totalMs - elapsed);
  const remSec = Math.ceil(remaining / 1000);
  const progress = Math.min(100, (elapsed / totalMs) * 100);
  const bg = data.isFirst ? firstBg.url : standardBg.url;
  const dbl = isDoubleStarrEvent();
  const monthly = isMonthlyStarrEvent();
  const rushMult =
    rushSnapshotRef.current && new Date(rushSnapshotRef.current.ends_at).getTime() > Date.now()
      ? rushSnapshotRef.current.multiplier
      : 1;
  const activeBoost = (() => {
    const s = boostSnapshotRef.current;
    if (s.mult > 1 && elapsed < s.remainingMs) return s.mult;
    return 1;
  })();


  return (
    <div className="fixed inset-0 z-[92] bg-black flex flex-col select-none">
      {/* HUD */}
      <div className="flex items-center justify-between px-4 py-2 bg-black/70 text-white text-xs md:text-sm border-b border-white/10 z-10 gap-2 flex-wrap">
        <div className="font-bold">
          🚄 {data.from.zh} {data.from.en}
          <span className="opacity-60"> → </span>
          {data.to.zh} {data.to.en}
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          {data.isDaily && (
            <span className="inline-flex items-center gap-1 bg-fuchsia-500/30 border border-fuchsia-300 px-2 py-0.5 rounded font-extrabold text-fuchsia-100">
              🌟 DAILY 1.5× · Misses <b>{missCountRef.current}</b>
            </span>
          )}
          {dbl && (
            <span className="inline-flex items-center gap-1 bg-pink-500/30 border border-pink-300 px-2 py-0.5 rounded font-extrabold text-pink-100">
              ✦ 2× WEEKEND 週末
            </span>
          )}
          {monthly && (
            <span className="inline-flex items-center gap-1 bg-purple-500/30 border border-purple-300 px-2 py-0.5 rounded font-extrabold text-purple-100">
              🌙 4× 每月1號 · Monthly 1st
            </span>
          )}
          {rushMult > 1 && (
            <span className="inline-flex items-center gap-1 bg-amber-500/30 border border-amber-300 px-2 py-0.5 rounded font-extrabold text-amber-100">
              🚀 RUSH {rushMult}× · 限時
            </span>
          )}
          {data.isFirst && (
            <span className="inline-flex items-center gap-1 bg-amber-500/30 border border-amber-300 px-2 py-0.5 rounded font-extrabold text-amber-100">
              1 · FIRST CLASS 2×
            </span>
          )}
          <span className="opacity-80">車廂 Class: <b>{data.seatClassZh} {data.seatClass}</b></span>
          <span>線路 Line: <b>{currentLine}</b> · 難度 Diff <b>{lineDifficulty}</b></span>
          <span className="tabular-nums">
            剩餘 Remaining: <b>{Math.floor(remSec / 60)}:{String(remSec % 60).padStart(2, "0")}</b>
          </span>
          <span className="inline-flex items-center gap-1 bg-emerald-500/20 border border-emerald-400/60 px-2 py-0.5 rounded">
            <StarrIcon size={12} /> 已收集 Caught: <b>{earned}</b>
          </span>
          {lineBonus > 0 && (
            <span className="inline-flex items-center gap-1 bg-sky-500/20 border border-sky-400/60 px-2 py-0.5 rounded">
              <StarrIcon size={12} /> 線路獎勵 Line Bonus: <b>+{lineBonus}</b>
            </span>
          )}
        </div>
      </div>

      {/* How-to-play strip */}
      <div className="bg-gradient-to-r from-cyan-600/80 via-sky-700/80 to-indigo-700/80 text-white px-4 py-1.5 text-[11px] md:text-xs text-center border-b border-white/10 z-10 font-semibold">
        🎯 <span className="opacity-90">How to Play</span> ·
        Starrs fall from the top — tap them <b>only inside the bottom zone</b>.
        The lower you catch, the higher your grade!
        <span className="opacity-80"> 星幣由上而下，於底部區域點擊；越低評級越高。</span>
      </div>

      {/* Progress bar */}
      <div className="bg-black/70 px-4 py-2 border-b border-white/10 z-10 text-white">
        <div className="flex items-center justify-between text-[11px] mb-1">
          <span className="opacity-80">
            進度 Progress: <b className="tabular-nums">{progress.toFixed(0)}%</b>
          </span>
          {nextStop && (
            <span className="opacity-90">
              下一站 Next: <b>{nextStop.zh}</b>{" "}
              <span className="opacity-70">{nextStop.en}</span>
            </span>
          )}
        </div>
        <div className="h-2 rounded-full bg-white/10 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-cyan-400 via-emerald-400 to-yellow-300 transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Scene */}
      <div
        ref={containerRef}
        onPointerDown={onScenePointerDown}
        className="relative flex-1 overflow-hidden cursor-crosshair"
        style={{
          backgroundImage: `url(${bg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* motion streaks (vertical, matching downward fall) */}
        <div
          className="pointer-events-none absolute inset-0 mix-blend-screen opacity-30 animate-[travelStreaksV_0.6s_linear_infinite]"
          style={{
            backgroundImage:
              "repeating-linear-gradient(0deg, transparent 0 40px, rgba(255,255,255,0.25) 40px 42px, transparent 42px 120px)",
          }}
        />
        <style>{`
          @keyframes travelStreaksV { from { transform: translateY(0);} to { transform: translateY(120px);} }
          @keyframes fbPop {
            0%   { transform: translate(-50%, -50%) scale(0.6); opacity: 0; }
            25%  { transform: translate(-50%, -60%) scale(1.15); opacity: 1; }
            100% { transform: translate(-50%, -110%) scale(1); opacity: 0; }
          }
        `}</style>

        {/* CATCH ZONE highlight — bottom 25% */}
        {!interchange && (
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1/4">
            <div
              className="absolute inset-0"
              style={{
                background:
                  "linear-gradient(to top, rgba(16,185,129,0.28) 0%, rgba(16,185,129,0.14) 60%, rgba(16,185,129,0) 100%)",
              }}
            />
            <div className="absolute inset-x-0 top-0 h-[2px] bg-emerald-300/90 shadow-[0_0_18px_rgba(16,185,129,0.9)]" />
            <div className="absolute inset-x-0 top-1 flex items-center justify-center gap-2 text-emerald-100 text-[10px] md:text-xs font-black tracking-widest uppercase">
              <span>◤ Catch Zone ◥</span>
              <span className="opacity-70">點擊區域</span>
            </div>
          </div>
        )}

        {/* Miss flash overlay */}
        {missFlash && (
          <div className="pointer-events-none absolute inset-0 bg-white/40 mix-blend-luminosity animate-pulse" />
        )}

        {/* Starrs */}
        {!interchange && floats.map((f) => {
          const shown = f.value * (dbl ? 2 : 1) * catcherMultFirst * activeBoost;
          return (
            <div
              key={f.id}
              className="pointer-events-none absolute"
              style={{ left: f.x - 22, top: f.y - 22 }}
            >
              <span
                className="relative inline-flex items-center justify-center"
                style={{ animation: "starr-idle 1.4s ease-in-out infinite" }}
              >
                <span className="absolute inset-0 -m-3 rounded-full bg-yellow-300/60 blur-md" />
                {(dbl || data.isFirst || activeBoost > 1) && (
                  <span className="absolute -top-3 -right-3 text-[10px] font-black bg-pink-500 text-white px-1 rounded-full shadow">
                    {shown / f.value}×
                  </span>
                )}
                <StarrIcon size={44} />
                <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[11px] font-extrabold text-yellow-200 drop-shadow">
                  +{shown}
                </span>
              </span>
            </div>
          );
        })}

        {/* Accuracy feedbacks */}
        {feedbacks.map((fb) => {
          const cfg = FEEDBACK_CFG[fb.kind];
          return (
            <div
              key={fb.id}
              className="pointer-events-none absolute font-black text-lg md:text-2xl tracking-widest"
              style={{
                left: fb.x,
                top: fb.y,
                color: cfg.color,
                textShadow: cfg.textShadow,
                filter: fb.kind === "miss" ? "grayscale(1)" : undefined,
                animation: "fbPop 700ms ease-out forwards",
              }}
            >
              {cfg.label}
            </div>
          );
        })}

        {interchange && (
          <InterchangeOverlay
            ends={interchange.ends}
            nextLine={interchange.nextLine}
            atStation={interchange.nextStation}
          />
        )}
      </div>
    </div>
  );
}

function InterchangeOverlay({ ends, nextLine, atStation }: { ends: number; nextLine: string; atStation: string }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 200);
    return () => clearInterval(id);
  }, []);
  const remaining = Math.max(0, Math.ceil((ends - now) / 1000));
  return (
    <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center text-white text-center p-6">
      <div className="text-4xl">🔁</div>
      <div className="text-2xl md:text-3xl font-black mt-2">
        轉乘中 · Interchange
      </div>
      <div className="text-sm opacity-80 mt-1">於 · at {atStation}</div>
      <div className="mt-2 text-sm">
        下一段線路 Next line:{" "}
        <span className="font-black text-cyan-300">{nextLine}</span>
      </div>
      <div className="mt-4 text-5xl font-black tabular-nums">{remaining}s</div>
      <div className="text-xs opacity-70 mt-2">
        Starr Catcher paused during transfer · 轉乘期間暫停接星
      </div>
    </div>
  );
}

export function JourneyCompleteModal({
  earned,
  travelMinutes,
  onClose,
  onWatchDoubleAd,
  adUsed,
  dailyBonus,
  missCount,
  isDaily,
}: {
  earned: number;
  travelMinutes: number;
  onClose: () => void;
  onWatchDoubleAd?: () => void;
  adUsed?: boolean;
  dailyBonus?: number;
  missCount?: number;
  isDaily?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-[93] bg-black/70 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-6 text-center my-6">
        <div className="text-3xl">🏁</div>
        <h2 className="text-xl font-extrabold mt-2">旅程完成 Journey Complete</h2>
        <p className="text-sm text-slate-600 mt-1">
          您已抵達目的地。You have arrived at your destination.
        </p>
        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="rounded-lg bg-slate-100 p-3">
            <div className="text-[10px] uppercase tracking-wider text-slate-500">
              行程時間 Travel Time
            </div>
            <div className="text-xl font-bold">{travelMinutes} 分 min</div>
          </div>
          <div className="rounded-lg bg-emerald-100 p-3">
            <div className="text-[10px] uppercase tracking-wider text-emerald-700">
              收集星幣 Starrs Earned
            </div>
            <div className="text-xl font-bold inline-flex items-center gap-1 justify-center">
              <StarrIcon size={16} /> {earned}
            </div>
          </div>
        </div>
        {isDaily && (
          <div
            className={`mt-3 rounded-lg p-3 text-sm font-bold ${
              dailyBonus && dailyBonus > 0
                ? "bg-fuchsia-100 text-fuchsia-900 border border-fuchsia-300"
                : "bg-slate-100 text-slate-700 border border-slate-200"
            }`}
          >
            {dailyBonus && dailyBonus > 0 ? (
              <>
                🌟 每日挑戰 完美通關 · Daily Challenge PERFECT!<br />
                <span className="inline-flex items-center gap-1 justify-center">
                  <StarrIcon size={14} /> +{dailyBonus} Starrs bonus
                </span>
              </>
            ) : (
              <>
                🌟 每日挑戰 · Daily Challenge complete ({missCount ?? 0} misses){"  "}
                <div className="text-xs opacity-70 font-normal mt-0.5">
                  0 misses next time → +100 Starrs
                </div>
              </>
            )}
          </div>
        )}
        {onWatchDoubleAd && !adUsed && earned > 0 && (
          <button
            onClick={onWatchDoubleAd}
            className="mt-4 w-full rounded-md bg-gradient-to-r from-fuchsia-500 to-pink-500 text-white py-2.5 text-sm font-bold shadow hover:brightness-110"
          >
            ▶ 觀看廣告 雙倍獎勵 · Watch Ad to DOUBLE Earnings (+{earned})
          </button>
        )}
        {adUsed && (
          <div className="mt-3 text-xs font-bold text-emerald-700">
            ✓ 已雙倍 · Doubled via ad
          </div>
        )}
        <button
          onClick={onClose}
          className="mt-3 w-full rounded-md bg-[#0a2540] text-white py-2.5 text-sm font-semibold"
        >
          完成 Done
        </button>
      </div>
    </div>
  );
}
