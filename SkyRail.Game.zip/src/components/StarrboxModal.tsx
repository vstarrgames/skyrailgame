import { useState } from "react";
import { openStarrbox, redeemSkinTokens, type StarrboxResult, type Profile } from "@/lib/wallet";
import { StarrIcon } from "./Starr";
import starrboxAsset from "@/assets/starrbox.png.asset.json";

type Phase = "idle" | "shaking" | "revealed";

const REWARD_LABELS: Record<string, { emoji: string; en: string; zh: string; rarity: string; color: string }> = {
  starrs_50:    { emoji: "⭐", en: "50 Starrs",                 zh: "50 星幣",             rarity: "Common",   color: "from-slate-500 to-slate-700" },
  boost_2x_10:  { emoji: "⚡", en: "2× Starr Booster · 10 min", zh: "2倍星幣加成 10 分鐘", rarity: "Common",   color: "from-sky-500 to-blue-700" },
  boost_2x_15:  { emoji: "⚡", en: "2× Starr Booster · 15 min", zh: "2倍星幣加成 15 分鐘", rarity: "Uncommon", color: "from-cyan-500 to-teal-700" },
  starrs_150:   { emoji: "🌟", en: "150 Starrs",                zh: "150 星幣",            rarity: "Uncommon", color: "from-amber-400 to-orange-600" },
  boost_3x_15:  { emoji: "🚀", en: "3× Starr Booster · 15 min", zh: "3倍星幣加成 15 分鐘", rarity: "Rare",     color: "from-fuchsia-500 to-pink-600" },
  skin_token_1: { emoji: "🎫", en: "1 Skin Token",              zh: "1 個外觀代幣",        rarity: "Epic",     color: "from-emerald-400 to-green-600" },
  skin_token_2: { emoji: "🎫", en: "2 Skin Tokens",             zh: "2 個外觀代幣",        rarity: "Legendary",color: "from-yellow-300 to-amber-500" },
  skin_token_4: { emoji: "🎟️", en: "4 Skin Tokens",             zh: "4 個外觀代幣",        rarity: "Mythic",   color: "from-rose-400 to-red-600" },
  skin_token_8: { emoji: "👑", en: "8 Skin Tokens",             zh: "8 個外觀代幣",        rarity: "Divine",   color: "from-indigo-400 via-fuchsia-500 to-amber-400" },
};

export function StarrboxModal({
  onClose,
  profile,
  onProfileUpdate,
}: {
  onClose: () => void;
  profile: Profile | null;
  onProfileUpdate: (patch: Partial<Profile>) => void;
}) {
  const [phase, setPhase] = useState<Phase>("idle");
  const [result, setResult] = useState<StarrboxResult | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [redeeming, setRedeeming] = useState(false);

  const credits = profile?.starrboxes ?? 0;
  const balance = profile?.balance ?? 0;

  async function open(useCredit: boolean) {
    setErr(null);
    if (busy) return;
    setBusy(true);
    setPhase("shaking");
    try {
      // Let shake animation play visually for ~1s while server rolls.
      const [r] = await Promise.all([
        openStarrbox(useCredit),
        new Promise((res) => setTimeout(res, 1000)),
      ]);
      setResult(r);
      onProfileUpdate({
        balance: r.new_balance,
        boost_multiplier: r.new_boost_multiplier,
        boost_remaining_ms: r.new_boost_remaining_ms,
        skin_tokens: r.new_skin_tokens,
        starrboxes: r.new_starrboxes,
      });
      setPhase("revealed");
    } catch (e) {
      const msg = (e as Error).message || "Error";
      setErr(
        msg.includes("insufficient_starrs")
          ? "星幣不足 · Insufficient Starrs (需要 100 · needs 100)"
          : msg,
      );
      setPhase("idle");
    } finally {
      setBusy(false);
    }
  }

  async function redeemNow() {
    if (!result || result.tokens_awarded < 1 || redeeming) return;
    setRedeeming(true);
    try {
      const r = await redeemSkinTokens(result.tokens_awarded);
      onProfileUpdate({ balance: r.new_balance, skin_tokens: r.new_skin_tokens });
      setResult((prev) =>
        prev ? { ...prev, new_balance: r.new_balance, new_skin_tokens: r.new_skin_tokens, tokens_awarded: 0 } : prev,
      );
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setRedeeming(false);
    }
  }

  const reward = result ? REWARD_LABELS[result.kind] : null;

  return (
    <div className="fixed inset-0 z-[97] bg-black/85 flex items-start sm:items-center justify-center p-3 overflow-y-auto">
      <div className="relative w-full max-w-md bg-gradient-to-br from-indigo-950 via-slate-900 to-fuchsia-950 rounded-2xl border border-amber-300/40 shadow-[0_0_60px_rgba(251,191,36,0.35)] my-4">
        <button
          onClick={onClose}
          disabled={phase === "shaking"}
          aria-label="Close"
          className="absolute top-2 right-2 w-10 h-10 rounded-full bg-black/60 hover:bg-black/80 disabled:opacity-40 text-white text-xl font-bold z-10 flex items-center justify-center"
        >
          ✕
        </button>

        <div className="p-5 text-white text-center">
          <h2 className="text-2xl font-black tracking-wide">🎁 Starrbox · 星幣寶箱</h2>
          <p className="text-xs opacity-70 mt-1">
            Random reward: Starrs · Boosters · rare Skin Tokens
          </p>

          <div className="mt-2 flex items-center justify-center gap-3 text-[11px]">
            <span className="rounded bg-white/10 px-2 py-1">
              🎟️ Credits: <b>{credits}</b>
            </span>
            <span className="rounded bg-white/10 px-2 py-1 inline-flex items-center gap-1">
              <StarrIcon size={12} /> <b>{balance}</b>
            </span>
          </div>

          <div className="my-6 flex justify-center items-center h-48">
            {phase === "revealed" && reward ? (
              <div className="animate-scale-in">
                <div className="text-7xl">{reward.emoji}</div>
                <div
                  className={`mt-2 inline-block px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-gradient-to-r ${reward.color} text-white shadow-lg`}
                >
                  {reward.rarity}
                </div>
              </div>
            ) : (
              <img
                src={starrboxAsset.url}
                alt="Starrbox 星幣寶箱"
                className={`h-44 w-44 object-contain select-none pointer-events-none ${
                  phase === "shaking"
                    ? "animate-[wiggle_0.15s_ease-in-out_infinite]"
                    : "hover:scale-110 transition"
                }`}
                style={{ filter: "drop-shadow(0 0 22px rgba(56,189,248,0.55))" }}
                draggable={false}
              />
            )}
          </div>

          {phase === "revealed" && reward && result ? (
            <>
              <div className="text-xl font-black">{reward.zh}</div>
              <div className="text-sm opacity-80">{reward.en}</div>
              {result.tokens_awarded > 0 ? (
                <div className="mt-4 space-y-2">
                  <p className="text-xs opacity-70">
                    立即兌換為 {result.tokens_awarded * 200} 星幣, 或存入代幣錢包 ·
                    Redeem now for {result.tokens_awarded * 200} Starrs, or keep in your Token Wallet.
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={redeemNow}
                      disabled={redeeming}
                      className="flex-1 rounded-md bg-emerald-500 hover:bg-emerald-600 text-white py-2 text-sm font-bold disabled:opacity-60"
                    >
                      {redeeming ? "…" : `💫 Redeem · +${result.tokens_awarded * 200}`}
                    </button>
                    <button
                      onClick={() => setPhase("idle")}
                      className="flex-1 rounded-md bg-white/10 hover:bg-white/20 py-2 text-sm font-bold"
                    >
                      🔒 Keep · 保留
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setPhase("idle")}
                  className="mt-4 w-full rounded-md bg-white/10 hover:bg-white/20 py-2 text-sm font-bold"
                >
                  再開一次 · Open Another
                </button>
              )}
            </>
          ) : (
            <>
              {err && (
                <div className="mb-3 text-xs bg-red-500/20 border border-red-400/40 text-red-100 rounded p-2">
                  {err}
                </div>
              )}
              <div className="flex flex-col gap-2">
                <button
                  onClick={() => open(true)}
                  disabled={busy || credits < 1}
                  className="w-full rounded-md bg-gradient-to-r from-amber-400 to-orange-500 hover:brightness-110 text-slate-900 py-3 text-sm font-black disabled:opacity-40"
                >
                  {credits > 0
                    ? `🎟️ Use Credit · 使用寶箱券 (${credits})`
                    : "🎟️ No Credits · 無寶箱券"}
                </button>
                <button
                  onClick={() => open(false)}
                  disabled={busy || balance < 100}
                  className="w-full rounded-md bg-fuchsia-600 hover:bg-fuchsia-500 py-3 text-sm font-black disabled:opacity-40 inline-flex items-center justify-center gap-1"
                >
                  Open for <StarrIcon size={14} /> 100
                </button>
              </div>

              <div className="mt-5 text-left text-[10px] opacity-70 space-y-0.5">
                <div className="font-bold uppercase tracking-widest opacity-80 mb-1">Odds · 機率</div>
                <div>⭐ 50 Starrs — 30%</div>
                <div>⚡ 2× Booster 10m — 25%</div>
                <div>⚡ 2× Booster 15m — 20%</div>
                <div>🌟 150 Starrs — 14%</div>
                <div>🚀 3× Booster 15m — 8%</div>
                <div>🎫 1 Skin Token — 2%</div>
                <div>🎫 2 Skin Tokens — 0.9%</div>
                <div>🎟️ 4 Skin Tokens — 0.09%</div>
                <div>👑 8 Skin Tokens — 0.01%</div>
              </div>
            </>
          )}
        </div>
      </div>

      <style>{`
        @keyframes wiggle {
          0%, 100% { transform: rotate(-8deg) scale(1.05); }
          25% { transform: rotate(8deg) scale(1.1); }
          50% { transform: rotate(-6deg) scale(1.15); }
          75% { transform: rotate(6deg) scale(1.1); }
        }
      `}</style>
    </div>
  );
}
