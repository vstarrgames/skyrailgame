import { useEffect, useState } from "react";
import {
  isDoubleStarrEvent,
  isMonthlyStarrEvent,
  baseEventMultiplier,
  msUntilNextEvent,
  getCurrentRush,
  type RushRow,
} from "@/lib/wallet";
import { StarrIcon } from "./Starr";

export function WeekendEvent() {
  const [now, setNow] = useState<Date | null>(null);
  const [rush, setRush] = useState<RushRow | null>(null);

  useEffect(() => {
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => {
    let alive = true;
    const load = () => getCurrentRush().then((r) => alive && setRush(r)).catch(() => {});
    load();
    const id = setInterval(load, 30_000);
    return () => { alive = false; clearInterval(id); };
  }, []);

  if (!now) return null;
  const weekend = isDoubleStarrEvent(now);
  const monthly = isMonthlyStarrEvent(now);
  const base = baseEventMultiplier(now);
  const ms = msUntilNextEvent(now);
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const pad = (n: number) => String(n).padStart(2, "0");

  const active = base > 1;
  const rushActive = !!rush && new Date(rush.ends_at).getTime() > now.getTime();
  const rushRemMs = rushActive ? new Date(rush!.ends_at).getTime() - now.getTime() : 0;
  const rushS = Math.floor(rushRemMs / 1000);
  const rushH = Math.floor(rushS / 3600);
  const rushM = Math.floor((rushS % 3600) / 60);
  const rushSec = rushS % 60;

  const label =
    weekend && monthly
      ? "6× STARR · 週末 + 每月1號"
      : monthly
        ? "4× STARR · 每月1號 Monthly 1st"
        : weekend
          ? "2× STARR · 週末 Weekend"
          : "2× STARR · Weekend Event · 週末活動";

  return (
    <div className="bg-gradient-to-r from-fuchsia-900 via-purple-900 to-indigo-900 border-y border-fuchsia-500/40 text-white">
      <div className="flex items-center justify-center gap-3 py-2 px-3 flex-wrap">
        <div className="inline-flex items-center gap-2 rounded-md bg-white/10 px-3 py-1.5 border border-white/15">
          <StarrIcon size={16} />
          <span className="font-extrabold tracking-wide text-sm">{label}</span>
        </div>
        {active ? (
          <span className="inline-flex items-center gap-1.5 text-[11px] font-black text-emerald-950 bg-emerald-300 px-2.5 py-1 rounded-full uppercase tracking-wider">
            <span className="w-1.5 h-1.5 bg-emerald-700 rounded-full" />
            Active · 進行中 · {base}×
          </span>
        ) : (
          <span className="text-[11px] font-semibold tabular-nums opacity-90">
            Next weekend in · 距離週末 {d}d {pad(h)}:{pad(m)}:{pad(sec)}
          </span>
        )}
      </div>
      {rushActive && (
        <div className="flex items-center justify-center gap-2 px-3 pb-1.5 text-[10px] font-semibold text-amber-100">
          <span className="inline-flex items-center gap-1 bg-amber-500/25 border border-amber-300/60 rounded-full px-2 py-0.5">
            🚀 Admin Rush · 限時 {rush!.multiplier}× — {pad(rushH)}:{pad(rushM)}:{pad(rushSec)}
          </span>
          {active && (
            <span className="opacity-80">
              Stacked total · 總倍數 {base * rush!.multiplier}×
            </span>
          )}
        </div>
      )}
    </div>
  );
}
