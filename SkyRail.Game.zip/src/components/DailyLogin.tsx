import { useEffect, useState } from "react";
import { claimDailyLogin, getDailyLoginStatus } from "@/lib/wallet";
import { StarrIcon } from "./Starr";
import type { Session } from "@supabase/supabase-js";

const REWARDS = [20, 30, 40, 50, 100];

export function DailyLogin({
  session,
  isAdmin,
  onClaimed,
}: {
  session: Session | null;
  isAdmin: boolean;
  onClaimed: (newBalance: number) => void;
}) {
  const [status, setStatus] = useState<{
    streak_day: number;
    can_claim: boolean;
    next_day: number;
  } | null>(null);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [claimed, setClaimed] = useState<{ day: number; reward: number } | null>(null);

  useEffect(() => {
    if (!session || isAdmin) return;
    void getDailyLoginStatus()
      .then((s) => {
        setStatus({ streak_day: s.streak_day, can_claim: s.can_claim, next_day: s.next_day });
        if (s.can_claim) setOpen(true);
      })
      .catch(() => {});
  }, [session, isAdmin]);

  if (!session || isAdmin || !status) return null;

  async function claim() {
    setBusy(true);
    try {
      const r = await claimDailyLogin();
      if (r.claimed) {
        setClaimed({ day: r.day, reward: r.reward });
        onClaimed(r.new_balance);
        setStatus({ streak_day: r.day, can_claim: false, next_day: (r.day % 5) + 1 });
      }
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      {/* small persistent badge in header context — rendered inline */}
      {!open && status.can_claim && (
        <button
          onClick={() => setOpen(true)}
          className="rounded bg-fuchsia-500 hover:bg-fuchsia-600 px-2 py-1 font-semibold text-white text-xs animate-pulse"
        >
          🎁 每日獎勵 Daily Reward
        </button>
      )}
      {open && (
        <div className="fixed inset-0 z-[97] bg-black/70 flex items-center justify-center p-4">
          <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-fuchsia-950 rounded-xl border border-fuchsia-500/40 shadow-2xl max-w-md w-full p-6 text-white">
            <h2 className="text-xl font-black tracking-wide text-center">
              每日登入獎勵 · Daily Login Reward
            </h2>
            <p className="text-xs opacity-70 text-center mt-1">
              5-day cycle · GMT+8 · Miss a day and streak resets to Day 1.
            </p>

            <div className="grid grid-cols-5 gap-2 mt-4">
              {REWARDS.map((r, i) => {
                const day = i + 1;
                const isCurrent = status.next_day === day && status.can_claim && !claimed;
                const isDone =
                  (claimed && day <= claimed.day) ||
                  (!status.can_claim && day <= status.streak_day);
                return (
                  <div
                    key={day}
                    className={`rounded-lg p-2 text-center border ${
                      isCurrent
                        ? "bg-fuchsia-500/30 border-fuchsia-300 ring-2 ring-fuchsia-300 animate-pulse"
                        : isDone
                          ? "bg-emerald-600/30 border-emerald-400"
                          : "bg-white/5 border-white/10"
                    }`}
                  >
                    <div className="text-[10px] opacity-80">Day {day}</div>
                    <div className="text-lg font-black inline-flex items-center gap-1 justify-center">
                      <StarrIcon size={14} />
                      {r}
                    </div>
                    {isDone && <div className="text-[10px] text-emerald-300">✓</div>}
                  </div>
                );
              })}
            </div>

            {claimed ? (
              <div className="mt-5 text-center">
                <div className="text-4xl">🎉</div>
                <div className="text-lg font-bold mt-1">
                  +{claimed.reward} Starrs claimed!
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="mt-4 w-full rounded-md bg-white text-slate-900 py-2 text-sm font-bold"
                >
                  太好了 Awesome
                </button>
              </div>
            ) : (
              <div className="mt-5 flex gap-2">
                <button
                  onClick={() => setOpen(false)}
                  className="flex-1 rounded-md bg-white/10 py-2 text-sm"
                >
                  稍後 Later
                </button>
                <button
                  disabled={busy || !status.can_claim}
                  onClick={claim}
                  className="flex-1 rounded-md bg-fuchsia-500 hover:bg-fuchsia-600 disabled:opacity-50 py-2 text-sm font-bold"
                >
                  {busy ? "…" : `領取 Day ${status.next_day} · +${REWARDS[status.next_day - 1]}`}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
