import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ADMIN_EMAIL, ADMIN_USERNAME, ADMIN_PASSWORD } from "@/lib/wallet";

const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;
const MIN_PW = 6;


function toEmail(username: string) {
  const v = username.trim().toLowerCase();
  if (v === ADMIN_USERNAME) return ADMIN_EMAIL;
  return `${v}@skyrail.user`;
}

export function AuthDialog({ onClose }: { onClose: () => void }) {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);

    const uname = name.trim().toLowerCase();
    if (uname !== ADMIN_USERNAME && !USERNAME_RE.test(uname)) {
      setErr("用戶名只能包含字母、數字、底線，長度 3-20 · Username: letters, numbers, underscore, 3-20 chars.");
      return;
    }
    if (uname !== ADMIN_USERNAME && pw.length < MIN_PW) {
      setErr(`密碼至少 ${MIN_PW} 個字元 · Password must be at least ${MIN_PW} characters.`);
      return;
    }

    setBusy(true);

    try {
      const email = toEmail(uname);
      if (email === ADMIN_EMAIL) {
        if (pw !== ADMIN_PASSWORD) throw new Error("管理員密碼錯誤 · Invalid admin password");
        let r = await supabase.auth.signInWithPassword({ email, password: ADMIN_PASSWORD });
        if (r.error) {
          const { error: sErr } = await supabase.auth.signUp({
            email,
            password: ADMIN_PASSWORD,
            options: { emailRedirectTo: window.location.origin },
          });
          if (sErr) throw sErr;
          r = await supabase.auth.signInWithPassword({ email, password: ADMIN_PASSWORD });
          if (r.error) throw r.error;
        }
        onClose();
        return;
      }

      if (mode === "up") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password: pw,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) {
          const m = error.message.toLowerCase();
          if (m.includes("registered") || m.includes("exists") || m.includes("already")) {
            throw new Error("此用戶名已被使用 · Username already taken");
          }
          if (m.includes("password")) {
            throw new Error(`密碼至少 ${MIN_PW} 個字元 · Password must be at least ${MIN_PW} characters.`);
          }
          throw error;
        }

        // Supabase returns an existing user with an empty identities array
        // when the email is already registered.
        if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
          throw new Error("此用戶名已被使用 · Username already taken");
        }
        // Auto sign-in for the just-created account
        await supabase.auth.signInWithPassword({ email, password: pw });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password: pw });
        if (error) {
          const m = error.message.toLowerCase();
          if (m.includes("invalid") || m.includes("credentials")) {
            throw new Error("用戶名或密碼錯誤 · Invalid username or password");
          }
          throw error;
        }
      }
      onClose();
    } catch (e2) {
      setErr((e2 as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[80] bg-black/60 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-sm w-full p-5">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-bold">
            {mode === "in" ? "登入 Sign in" : "註冊 Sign up"}
          </h2>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-900">✕</button>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <input
            required
            type="text"
            autoComplete="username"
            placeholder="用戶名 Username"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full border rounded px-3 py-2 text-sm"
          />
          <input
            required
            type="password"
            minLength={6}
            autoComplete={mode === "up" ? "new-password" : "current-password"}
            placeholder="密碼 Password (min 6)"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            className="w-full border rounded px-3 py-2 text-sm"
          />
          {err && <div className="text-xs text-red-600">{err}</div>}
          <button
            disabled={busy}
            className="w-full rounded-md bg-[#0a2540] text-white py-2 text-sm font-semibold disabled:opacity-50"
          >
            {busy ? "…" : mode === "in" ? "登入 Sign in" : "註冊 Sign up"}
          </button>
        </form>
        <button
          type="button"
          onClick={() => setMode(mode === "in" ? "up" : "in")}
          className="text-xs text-slate-500 hover:text-slate-900 mt-3 w-full text-center"
        >
          {mode === "in"
            ? "沒有帳戶？ 註冊 · No account? Sign up"
            : "已有帳戶？ 登入 · Have an account? Sign in"}
        </button>
      </div>
    </div>
  );
}
