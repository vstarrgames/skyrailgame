import { useEffect, useRef, useState } from "react";
import adAsset from "@/assets/advertisment.mp4.asset.json";
import { claimAdReward, applyTripAdBonus } from "@/lib/wallet";
import { StarrIcon } from "./Starr";

type AdMode =
  | { kind: "reward" } // regular +20 Starr daily ad
  | { kind: "double"; amount: number; label?: string }; // double a trip's earnings (adds amount)

export function AdWatch({
  onComplete,
  onError,
  onClose,
  mode = { kind: "reward" },
}: {
  onComplete: (newBalance: number) => void;
  onError: (msg: string) => void;
  onClose: () => void;
  mode?: AdMode;
}) {
  const ref = useRef<HTMLVideoElement>(null);
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);
  const [claiming, setClaiming] = useState(false);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  useEffect(() => {
    const v = ref.current;
    if (!v) return;
    v.play().catch(() => {});
  }, []);

  async function claim() {
    setClaiming(true);
    try {
      if (mode.kind === "reward") {
        const r = await claimAdReward();
        onComplete(r.new_balance);
      } else {
        const bal = await applyTripAdBonus(mode.amount);
        onComplete(bal);
      }
    } catch (e) {
      const msg = (e as Error).message.includes("ad_limit_reached")
        ? "每日上限已達 · Daily limit (3) reached."
        : (e as Error).message;
      onError(msg);
    } finally {
      setClaiming(false);
    }
  }

  const rewardLabel =
    mode.kind === "reward"
      ? `20 Starrs · Claim`
      : `+${mode.amount} Starrs · Double Earnings`;

  const rewardBlurb =
    mode.kind === "reward" ? (
      <>
        完整觀看廣告以獲得 <StarrIcon size={14} /> 20 · Watch to the end for 20 Starrs
      </>
    ) : (
      <>
        完整觀看廣告可獲雙倍旅程獎勵 · Watch the full ad to double your trip earnings (+
        {mode.amount} Starrs)
      </>
    );

  return (
    <div className="fixed inset-0 z-[90] bg-black flex flex-col items-center justify-center p-2">
      <div className="absolute top-2 left-2 right-2 flex items-center justify-between text-white text-xs font-mono">
        <span>廣告播放中 · Advertisement</span>
        <span>
          {done
            ? "已完成 Completed"
            : `${Math.floor(progress)}% · 請勿離開 Do NOT leave`}
        </span>
      </div>
      <video
        ref={ref}
        src={adAsset.url}
        playsInline
        autoPlay
        controls={false}
        onTimeUpdate={(e) => {
          const el = e.currentTarget;
          if (el.duration > 0) setProgress((el.currentTime / el.duration) * 100);
        }}
        onEnded={() => setDone(true)}
        className="max-w-full max-h-[75vh]"
      />
      <div className="mt-4 flex flex-col items-center gap-2">
        {!done ? (
          <div className="text-white/80 text-sm text-center px-2 flex items-center gap-1 flex-wrap justify-center">
            {rewardBlurb}
            {mode.kind === "double" && (
              <span className="block w-full mt-1 text-[10px] text-amber-300/90">
                廣告播放中無法跳過或關閉 · Ad cannot be skipped or closed while playing
              </span>
            )}
          </div>
        ) : (
          <>
            <button
              onClick={claim}
              disabled={claiming}
              className="rounded-md bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2 font-bold disabled:opacity-50"
            >
              {claiming ? "…" : `領取 · ${rewardLabel}`}
            </button>
            {mode.kind === "reward" && (
              <button onClick={onClose} className="text-white/70 text-xs underline">
                關閉 · Close
              </button>
            )}
          </>
        )}
      </div>

    </div>
  );
}
