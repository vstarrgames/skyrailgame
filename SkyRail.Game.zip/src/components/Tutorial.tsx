import { useState } from "react";
import { StarrIcon } from "./Starr";

const STEPS = [
  {
    emoji: "🎵",
    titleZh: "跟著節奏拍！",
    titleEn: "Tap to the Beat",
    bodyZh: "旅程開始後，Starr 會從頂部落下。點擊它們以收集星幣。點擊愈快、愈準，賺得愈多！",
    bodyEn: "Once your journey begins, Starrs fall from the top. Tap them to collect. Faster, sharper taps = more Starrs.",
  },
  {
    emoji: "🎯",
    titleZh: "精準命中區",
    titleEn: "Catch Zone Precision",
    bodyZh: "只有畫面底部 25% 的高亮區域才計分。太早或太遲都會 Miss。時機就是一切。",
    bodyEn: "Only the highlighted bottom 25% of the screen counts. Too early or too late = Miss. Timing is everything.",
  },
  {
    emoji: "⭐",
    titleZh: "評級系統",
    titleEn: "Rating System",
    bodyZh: "Fair → Good → Mythic → Legendary。愈接近完美時機，等級愈高，星幣獎勵愈豐厚！",

    bodyEn: "Fair → Good → Mythic → Legendary. The closer to the perfect line, the higher the rank — and the bigger the payout.",
  },
  {
    emoji: "🚄",
    titleZh: "解鎖，升級，稱霸",
    titleEn: "Progress & Dominate",
    bodyZh: "完成旅程解鎖新線路，儲星幣買車票、加成、Starter Pack。挑戰排行榜前 5 名！",
    bodyEn: "Finish trips to unlock new lines. Spend Starrs on tickets, boosts, and the Starter Pack. Climb the top 5 leaderboards!",
  },
];

export function Tutorial({ onClose }: { onClose: () => void }) {
  const [i, setI] = useState(-1); // -1 = welcome screen
  const isWelcome = i === -1;
  const step = STEPS[i];

  function next() {
    if (isWelcome) setI(0);
    else if (i < STEPS.length - 1) setI(i + 1);
    else finish();
  }
  function finish() {
    try { localStorage.setItem("sr_tutorial_done", "1"); } catch { /* ignore */ }
    onClose();
  }

  return (
    <div className="fixed inset-0 z-[97] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-auto">
      <div
        className="relative w-full max-w-md rounded-2xl overflow-hidden shadow-2xl border border-cyan-400/40 bg-gradient-to-br from-[#0a1230] via-[#0a2540] to-[#0a1230] text-white"
      >
        <button
          onClick={finish}
          className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-sm z-10"
        >
          ✕
        </button>

        {isWelcome ? (
          <div className="p-6 text-center">
            <div className="text-4xl">🚄✨</div>
            <h2 className="mt-3 text-2xl font-black tracking-tight">
              歡迎登上 SkyRail！
            </h2>
            <p className="text-cyan-300 font-bold text-lg">
              Welcome Aboard, Conductor.
            </p>
            <div className="mt-4 space-y-2 text-sm text-white/90 leading-relaxed">
              <p>
                這不是普通的列車 —— 這是一場高速、節奏、發光的星幣狩獵！
              </p>
              <p>
                This isn't your grandma's train ride. It's a high-speed, beat-slamming,{" "}
                <StarrIcon size={12} />-hunting joyride across the city.
              </p>
              <p className="text-amber-300 font-semibold">
                🎯 3 rules · 3 條規則:
              </p>
              <ul className="text-xs text-white/80 space-y-1 text-left inline-block">
                <li>1️⃣ Tap fast · 快</li>
                <li>2️⃣ Tap accurate · 準</li>
                <li>3️⃣ Don't panic when Legendary hits · 遇到 Legendary 別緊張</li>
              </ul>
            </div>
            <button
              onClick={next}
              className="mt-5 w-full rounded-lg bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-900 font-black py-3 text-base hover:brightness-110"
            >
              教我怎麼玩 · Show Me the Ropes →
            </button>
            <button
              onClick={finish}
              className="mt-2 text-[11px] text-white/50 hover:text-white/80"
            >
              我是老手，跳過 · Skip, I'm a pro

            </button>
          </div>
        ) : (
          <div className="p-6">
            <div className="flex items-center gap-2 text-xs text-cyan-300 font-bold uppercase tracking-widest">
              <span>Step {i + 1} / {STEPS.length}</span>
              <div className="flex-1 h-1 bg-white/10 rounded overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-400 to-cyan-400 transition-all"
                  style={{ width: `${((i + 1) / STEPS.length) * 100}%` }}
                />
              </div>
            </div>
            <div className="mt-4 text-5xl text-center">{step.emoji}</div>
            <h3 className="mt-2 text-xl font-black text-center">
              {step.titleZh}
            </h3>
            <p className="text-cyan-300 font-bold text-center text-sm">
              {step.titleEn}
            </p>
            <div className="mt-4 space-y-2 text-sm text-white/90 leading-relaxed">
              <p>{step.bodyZh}</p>
              <p className="text-white/70">{step.bodyEn}</p>
            </div>
            <div className="mt-5 flex gap-2">
              {i > 0 && (
                <button
                  onClick={() => setI(i - 1)}
                  className="flex-1 rounded-lg bg-white/10 hover:bg-white/20 py-2.5 text-sm font-bold"
                >
                  ← Back
                </button>
              )}
              <button
                onClick={next}
                className="flex-[2] rounded-lg bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-900 py-2.5 text-sm font-black hover:brightness-110"
              >
                {i === STEPS.length - 1 ? "出發！Let's Ride 🚄" : "下一步 Next →"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
