import { useState } from "react";
import { StarrIcon } from "./Starr";
import shopBg from "@/assets/shop-bg.png.asset.json";
import { usePaddleCheckout } from "@/hooks/usePaddleCheckout";
import { useSession, type Profile } from "@/lib/wallet";
import { StarrboxModal } from "./StarrboxModal";


type Pack = {
  key: string;
  priceId: string;
  starrs?: number;
  label: string;
  labelZh: string;
  price: number;
  originalPrice?: number;
  badge?: string;
  boost?: string;
  featured?: boolean;
  bullets?: string[];
  tagline?: string;
};

const STARTER_PACK: Pack = {
  key: "starter",
  priceId: "starter_pack_price",
  label: "STARTER PACK",
  labelZh: "新手大禮包",
  price: 20,
  originalPrice: 37.5,
  badge: "🔥 73% OFF · 限時",
  featured: true,
  tagline: "The launchpad every new conductor needs.",
  bullets: [
    "🚉 2號線 星利線 永久解鎖 · Line 2 permanently unlocked",
    "⭐ 100 Starrs 即時到手 · 100 Starrs, instantly",
    "⚡ 10 分鐘 2× Starr 加成（遊玩時才計時）· 10-min 2× multiplier (gameplay-active timer)",
  ],
};

const STARR_PACKS: Pack[] = [
  { key: "s100",  priceId: "starr_pack_100_price",  starrs: 100,  label: "Starter Pack", labelZh: "入門包", price: 15 },
  { key: "s220",  priceId: "starr_pack_220_price",  starrs: 220,  label: "Popular Pack", labelZh: "人氣包", price: 30, badge: "MOST POPULAR · 最受歡迎" },
  { key: "s450",  priceId: "starr_pack_450_price",  starrs: 450,  label: "Value Pack",   labelZh: "超值包", price: 50 },
  { key: "s1000", priceId: "starr_pack_1000_price", starrs: 1000, label: "Pro Pack",     labelZh: "專業包", price: 100 },
  { key: "s2500", priceId: "starr_pack_2500_price", starrs: 2500, label: "Ultimate Pack",labelZh: "終極包", price: 200, badge: "BEST VALUE · 最划算" },
];

const BOOST_PACKS: Pack[] = [
  { key: "b2x10", priceId: "boost_2x_10_price", boost: "2× · 10 min", label: "2× Starrs 10 min", labelZh: "2倍星幣 10 分鐘", price: 15 },
  { key: "b2x30", priceId: "boost_2x_30_price", boost: "2× · 30 min", label: "2× Starrs 30 min", labelZh: "2倍星幣 30 分鐘", price: 30 },
  { key: "b3x30", priceId: "boost_3x_30_price", boost: "3× · 30 min", label: "3× Starrs 30 min", labelZh: "3倍星幣 30 分鐘", price: 40 },
];

export function StarrShop({
  onClose,
  profile,
  onProfileUpdate,
}: {
  onClose: () => void;
  profile?: Profile | null;
  onProfileUpdate?: (patch: Partial<Profile>) => void;
}) {
  const [tab, setTab] = useState<"starrs" | "boost">("starrs");
  const { session } = useSession();
  const { openCheckout, loading } = usePaddleCheckout();
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [needLogin, setNeedLogin] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [showStarrbox, setShowStarrbox] = useState(false);

  const items = tab === "starrs" ? STARR_PACKS : BOOST_PACKS;


  async function buy(pack: Pack) {
    setErr(null);
    if (!session) {
      setNeedLogin(true);
      return;
    }
    setBusyKey(pack.key);
    try {
      await openCheckout({
        priceId: pack.priceId,
        quantity: 1,
        customerEmail: session.user.email ?? undefined,
        customData: { userId: session.user.id },
        successUrl: `${window.location.origin}/?checkout=success`,
      });
    } catch (e) {
      setErr((e as Error).message || "Could not open checkout");
    } finally {
      setBusyKey(null);
    }
  }

  return (
    <div className="fixed inset-0 z-[96] bg-black/80 flex items-start sm:items-center justify-center p-0 sm:p-3 overflow-y-auto overscroll-contain">
      <div
        className="relative w-full max-w-4xl sm:rounded-2xl overflow-hidden shadow-2xl border-0 sm:border sm:border-white/10 min-h-full sm:min-h-0 sm:my-4"
        style={{
          backgroundImage: `linear-gradient(180deg, rgba(5,10,30,0.85), rgba(5,10,30,0.92)), url(${shopBg.url})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <button
          onClick={onClose}
          aria-label="Close"
          className="fixed sm:absolute top-3 right-3 w-11 h-11 rounded-full bg-black/70 sm:bg-white/10 hover:bg-white/20 text-white text-xl font-bold z-20 flex items-center justify-center shadow-lg"
          style={{ top: "max(0.75rem, env(safe-area-inset-top))" }}
        >
          ✕
        </button>

        <div className="p-4 sm:p-6 pt-14 sm:pt-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] text-white">
          <h2 className="text-xl sm:text-2xl md:text-3xl font-black tracking-wide flex items-center gap-2 pr-12">
            <StarrIcon size={24} />
            Starr Shop · 星幣商店
          </h2>
          <p className="text-xs opacity-80 mt-1">
            Purchase Starrs and boosters. 購買星幣及加成道具。
          </p>

          {err && (
            <div className="mt-3 text-xs bg-red-500/20 border border-red-400/40 text-red-100 rounded p-2">
              {err}
            </div>
          )}

          {/* ⭐ Featured Starter Pack */}
          <div className="mt-6 relative rounded-2xl overflow-hidden border-2 border-amber-300/70 bg-gradient-to-br from-amber-500/20 via-rose-500/15 to-fuchsia-500/20 p-4 sm:p-5 shadow-[0_0_30px_rgba(251,191,36,0.35)]">
            <div className="absolute -top-3 left-3 sm:left-4 bg-amber-400 text-amber-950 text-[10px] sm:text-[11px] font-black tracking-widest px-2 sm:px-3 py-1 rounded-full uppercase shadow-lg max-w-[calc(100%-1.5rem)] truncate">
              {STARTER_PACK.badge}
            </div>
            <div className="grid md:grid-cols-[minmax(0,1fr)_auto] gap-4 items-center mt-2">
              <div className="min-w-0">
                <div className="text-xs uppercase tracking-widest text-amber-200 font-bold">
                  {STARTER_PACK.labelZh}
                </div>
                <div className="text-xl sm:text-2xl md:text-3xl font-black break-words">
                  {STARTER_PACK.label} — <span className="text-amber-300">HK${STARTER_PACK.price}</span>
                  <span className="ml-2 text-sm text-white/50 line-through font-bold">HK${STARTER_PACK.originalPrice}</span>
                </div>

                <p className="mt-1 text-sm text-white/90 italic">
                  &ldquo;{STARTER_PACK.tagline}&rdquo; 新手一次入場,立即起飛 🚀
                </p>
                <ul className="mt-3 space-y-1 text-sm text-white/95 font-medium">
                  {STARTER_PACK.bullets!.map((b) => (
                    <li key={b}>{b}</li>
                  ))}
                </ul>
                <p className="mt-3 text-[11px] text-amber-200/90 font-bold">
                  ⏱️ LIMITED OFFER · 限時優惠 · Save HK$17.50 today.
                </p>
              </div>
              <button
                onClick={() => buy(STARTER_PACK)}
                disabled={loading || busyKey === STARTER_PACK.key}
                className="w-full md:w-auto rounded-xl bg-gradient-to-r from-amber-400 to-rose-500 hover:brightness-110 disabled:opacity-60 text-slate-900 px-6 py-4 text-lg font-black shadow-xl whitespace-nowrap"
              >
                {busyKey === STARTER_PACK.key ? "Opening…" : "CLAIM · 立即入手"}
                <div className="text-[10px] font-bold opacity-80 tracking-widest">HK${STARTER_PACK.price} · 73% OFF</div>
              </button>
            </div>
          </div>

          {/* 🎁 Starrbox - featured mystery box */}
          <div className="mt-4 relative rounded-2xl overflow-hidden border-2 border-fuchsia-400/70 bg-gradient-to-br from-fuchsia-600/20 via-indigo-600/15 to-cyan-500/20 p-4 sm:p-5 shadow-[0_0_30px_rgba(217,70,239,0.35)]">
            <div className="absolute -top-3 left-3 sm:left-4 bg-fuchsia-400 text-fuchsia-950 text-[10px] sm:text-[11px] font-black tracking-widest px-2 sm:px-3 py-1 rounded-full uppercase shadow-lg">
              🎁 Mystery Box · 神秘寶箱
            </div>
            <div className="grid md:grid-cols-[minmax(0,1fr)_auto] gap-4 items-center mt-2">
              <div className="min-w-0">
                <div className="text-xs uppercase tracking-widest text-fuchsia-200 font-bold">星幣寶箱</div>
                <div className="text-xl sm:text-2xl md:text-3xl font-black break-words">
                  Starrbox — <span className="text-fuchsia-300">HK$10</span>
                  <span className="ml-2 text-sm text-white/50 line-through font-bold">HK$15</span>
                  <span className="ml-2 text-sm opacity-80">or</span>{" "}
                  <span className="inline-flex items-center gap-1 text-cyan-200">
                    <StarrIcon size={18} /> 100
                  </span>
                </div>
                <p className="mt-1 text-sm text-white/90 italic">
                  Random reward — Starrs, boosters, and rare <b>Skin Tokens</b> 🎫
                </p>
                <ul className="mt-2 text-[11px] text-white/80 space-y-0.5">
                  <li>⭐ 50 Starrs (30%) · 🌟 150 Starrs (14%)</li>
                  <li>⚡ 2× / 3× Booster (up to 15 min, 53%)</li>
                  <li>🎫 Skin Tokens up to 8× (rare · 3%)</li>
                </ul>
              </div>
              <div className="flex flex-col gap-2 w-full md:w-auto">
                <button
                  onClick={() => setShowStarrbox(true)}
                  className="rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-900 px-5 py-3 text-sm font-black shadow-xl whitespace-nowrap"
                >
                  Open with <StarrIcon size={14} /> 100
                </button>
                <button
                  onClick={() => buy({
                    key: "starrbox",
                    priceId: "starrbox_price",
                    label: "Starrbox",
                    labelZh: "星幣寶箱",
                    price: 10,
                  })}
                  disabled={loading || busyKey === "starrbox"}
                  className="rounded-xl bg-gradient-to-r from-fuchsia-500 to-pink-500 hover:brightness-110 disabled:opacity-60 text-white px-5 py-3 text-sm font-black shadow-xl whitespace-nowrap"
                >
                  {busyKey === "starrbox" ? "Opening…" : "Buy 1 · HK$10"}
                </button>
              </div>
            </div>
          </div>



          <div className="mt-6 inline-flex bg-white/10 rounded-full p-1 text-sm">
            <button
              onClick={() => setTab("starrs")}
              className={`px-4 py-1.5 rounded-full font-bold ${tab === "starrs" ? "bg-white text-slate-900" : "text-white/80"}`}
            >
              Starr Packs · 星幣包
            </button>
            <button
              onClick={() => setTab("boost")}
              className={`px-4 py-1.5 rounded-full font-bold ${tab === "boost" ? "bg-white text-slate-900" : "text-white/80"}`}
            >
              Boosters · 加成
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 mt-5">
            {items.map((p) => (
              <div
                key={p.key}
                className="relative rounded-xl bg-gradient-to-br from-white/15 to-white/5 border border-white/20 p-4 backdrop-blur-sm hover:border-cyan-300/60 transition"
              >
                {p.badge && (
                  <div className="absolute -top-2 left-3 text-[9px] font-black tracking-widest bg-amber-400 text-amber-950 px-2 py-0.5 rounded uppercase">
                    {p.badge}
                  </div>
                )}
                <div className="text-xs uppercase tracking-widest opacity-80">
                  {p.labelZh}
                </div>
                <div className="text-sm opacity-70">{p.label}</div>
                {p.starrs != null && (
                  <div className="mt-2 flex items-center gap-2 text-2xl font-black">
                    <StarrIcon size={22} />
                    {p.starrs.toLocaleString()}
                    <span className="text-xs opacity-70">Starrs</span>
                  </div>
                )}
                {p.boost && (
                  <div className="mt-2 text-2xl font-black text-cyan-200">{p.boost}</div>
                )}
                <div className="mt-3 flex items-end justify-between">
                  <div className="text-xl font-extrabold">
                    HK$<span className="tabular-nums">{p.price}</span>
                  </div>
                  <button
                    onClick={() => buy(p)}
                    disabled={loading || busyKey === p.key}
                    className="rounded-md bg-emerald-500 hover:bg-emerald-600 disabled:opacity-60 px-3 py-2 text-sm font-bold"
                  >
                    {busyKey === p.key ? "Opening…" : "Buy · 購買"}
                  </button>
                </div>
              </div>
            ))}
          </div>

          <p className="text-[10px] opacity-60 mt-4 text-center">
            Secure checkout via Paddle · Merchant of Record · 由 Paddle 安全處理付款
          </p>
        </div>
      </div>

      {needLogin && (
        <div className="fixed inset-0 z-[98] bg-black/70 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-sm w-full p-5 text-center">
            <div className="text-3xl">🔐</div>
            <h3 className="text-lg font-bold mt-2">
              請先登入 · Sign in to purchase
            </h3>
            <p className="text-sm text-slate-600 mt-1">
              Your Starrs and boosters are tied to your account, so we need you to sign in before checkout.
            </p>
            <button
              onClick={() => setNeedLogin(false)}
              className="mt-4 w-full rounded-md bg-slate-900 text-white py-2 text-sm font-medium"
            >
              OK · 知道了
            </button>
          </div>
        </div>
      )}

      {showStarrbox && (
        <StarrboxModal
          onClose={() => setShowStarrbox(false)}
          profile={profile ?? null}
          onProfileUpdate={(patch) => onProfileUpdate?.(patch)}
        />
      )}
    </div>

  );
}
