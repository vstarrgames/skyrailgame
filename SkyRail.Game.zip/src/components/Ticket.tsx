import { QRCodeSVG } from "qrcode.react";
import ticketFrame from "@/assets/ticket-frame.png.asset.json";
import { StarrIcon } from "./Starr";

export type TicketInfo = {
  from: { id: string; en: string; zh: string };
  to: { id: string; en: string; zh: string };
  seatClass: string;
  seatClassZh: string;
  seat: string;
  fare: number;
  dateTime: string;
};

export function TicketDisplay({
  ticket,
  onClose,
  onStartJourney,
}: {
  ticket: TicketInfo;
  onClose: () => void;
  onStartJourney?: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[85] bg-black/70 flex items-center justify-center p-3 overflow-auto">
      <div className="relative w-full max-w-[720px]">
        <img
          src={ticketFrame.url}
          alt=""
          className="w-full h-auto block select-none pointer-events-none"
          draggable={false}
        />
        <div className="absolute inset-0 flex flex-col p-[6%] text-[#1e3a5f]">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-[10px] uppercase tracking-widest opacity-70">SkyRail · 天空鐵路</div>
              <div className="text-xs font-bold">車票 Ticket</div>
            </div>
            <div className="text-right text-[10px] font-mono opacity-80">{ticket.dateTime}</div>
          </div>

          <div className="mt-auto grid grid-cols-[1fr_auto_1fr] gap-2 items-center">
            <div className="min-w-0">
              <div className="text-[9px] uppercase tracking-widest opacity-70">FROM 起</div>
              <div className="text-sm md:text-base font-extrabold truncate">{ticket.from.zh}</div>
              <div className="text-[10px] md:text-xs font-semibold truncate">{ticket.from.en}</div>
              <div className="text-[10px] font-mono opacity-70">{ticket.from.id}</div>
            </div>
            <div className="text-lg font-black">➜</div>
            <div className="min-w-0 text-right">
              <div className="text-[9px] uppercase tracking-widest opacity-70">TO 終</div>
              <div className="text-sm md:text-base font-extrabold truncate">{ticket.to.zh}</div>
              <div className="text-[10px] md:text-xs font-semibold truncate">{ticket.to.en}</div>
              <div className="text-[10px] font-mono opacity-70">{ticket.to.id}</div>
            </div>
          </div>

          <div className="mt-2 flex items-end justify-between gap-2">
            <div className="text-[10px] leading-tight">
              <div>
                <span className="opacity-70">Class 車廂：</span>
                <span className="font-bold">{ticket.seatClassZh} {ticket.seatClass}</span>
              </div>
              <div>
                <span className="opacity-70">Seat 座位：</span>
                <span className="font-bold font-mono">{ticket.seat}</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="opacity-70">Fare 車費：</span>
                <StarrIcon size={11} />
                <span className="font-bold">{ticket.fare}</span>
              </div>
            </div>
            <div className="bg-white p-1 rounded">
              <QRCodeSVG value="https://youtube.com/@vstarrofficial" size={72} />
            </div>
          </div>
        </div>
      </div>

      {onStartJourney && (
        <button
          onClick={onStartJourney}
          className="absolute left-1/2 -translate-x-1/2 -bottom-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 font-extrabold shadow-lg text-sm md:text-base"
        >
          🚄 開始旅程 · Start Journey
        </button>
      )}
    </div>
  );
}