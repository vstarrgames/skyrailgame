import { useState } from "react";
import { sendStarrGift, type Profile } from "@/lib/wallet";
import { StarrIcon } from "./Starr";

export function SendGiftDialog({
  onClose,
  profile,
  isAdmin,
  onProfileUpdate,
}: {
  onClose: () => void;
  profile: Profile | null;
  isAdmin: boolean;
  onProfileUpdate: (patch: Partial<Profile>) => void;
}) {
  const [email, setEmail] = useState("");
  const [amount, setAmount] = useState<number>(50);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<{ net: number } | null>(null);

  const feePct = isAdmin ? 0 : 20;
  const net = isAdmin ? amount : Math.max(1, Math.floor(amount * 0.8));

  async function submit() {
    setErr(null);
    setOk(null);
    if (!email.includes("@")) return setErr("請輸入有效電郵 · Please enter a valid email");
    if (amount < 10) return setErr("最少 10 星幣 · Minimum 10 Starrs");
    if (!isAdmin && (profile?.balance ?? 0) < amount)
      return setErr("星幣不足 · Insufficient Starrs");
    setBusy(true);
    try {
      const r = await sendStarrGift(email, amount);
      onProfileUpdate({ balance: r.new_balance });
      setOk({ net: r.net_delivered });
    } catch (e) {
      const m = (e as Error).message || "Error";
      setErr(
        m.includes("recipient_not_found")
          ? "找不到收件者 · Recipient not found"
          : m.includes("cannot_gift_self")
            ? "不能送給自己 · Cannot gift yourself"
            : m.includes("insufficient_starrs")
              ? "星幣不足 · Insufficient Starrs"
              : m,
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[97] bg-black/80 flex items-start sm:items-center justify-center p-3 overflow-y-auto">
      <div className="relative w-full max-w-sm bg-white rounded-2xl shadow-2xl p-5 my-4">
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute top-2 right-2 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-lg font-bold"
        >
          ✕
        </button>
        <h2 className="text-xl font-black text-slate-900">🎁 送禮 · Send Gift</h2>
        <p className="text-xs text-slate-500 mt-0.5">
          {isAdmin
            ? "管理員：無手續費 · Admin: no fee"
            : "使用者互贈手續費 20% · User-to-user gifts have a 20% fee"}
        </p>

        {ok ? (
          <div className="mt-5 rounded-lg bg-emerald-50 border border-emerald-300 p-4 text-center">
            <div className="text-4xl">✅</div>
            <div className="mt-1 font-bold text-emerald-800">送出成功 · Gift sent!</div>
            <div className="text-sm text-emerald-700 inline-flex items-center gap-1 mt-1">
              收件者到帳 · Recipient received <b>+{ok.net}</b> <StarrIcon size={12} />
            </div>
            <button
              onClick={onClose}
              className="mt-3 w-full rounded-md bg-slate-900 text-white py-2 text-sm font-bold"
            >
              關閉 · Close
            </button>
          </div>
        ) : (
          <div className="mt-4 space-y-3">
            <label className="block">
              <span className="text-xs font-semibold text-slate-600">
                收件者電郵 · Recipient Email
              </span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="friend@example.com"
                className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
              />
            </label>
            <label className="block">
              <span className="text-xs font-semibold text-slate-600">
                星幣數量 · Amount of Starrs
              </span>
              <input
                type="number"
                min={10}
                value={amount}
                onChange={(e) => setAmount(Math.max(0, Number(e.target.value) || 0))}
                className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm tabular-nums"
              />
              <div className="flex gap-1 mt-1.5">
                {[50, 100, 250, 500].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setAmount(n)}
                    className="flex-1 text-[11px] rounded bg-slate-100 hover:bg-slate-200 py-1 font-semibold"
                  >
                    {n}
                  </button>
                ))}
              </div>
            </label>

            <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs space-y-1">
              <Row label="您付出 · You pay" value={`${amount}`} />
              <Row label={`手續費 · Fee (${feePct}%)`} value={`-${amount - net}`} />
              <div className="border-t border-slate-200 my-1" />
              <Row label="對方收到 · They receive" value={`${net}`} strong />
              {!isAdmin && (
                <Row
                  label="您的結餘 · Your balance"
                  value={`${(profile?.balance ?? 0) - amount}`}
                />
              )}
            </div>

            {err && (
              <div className="text-xs bg-red-50 border border-red-300 text-red-700 rounded p-2">
                {err}
              </div>
            )}

            <div className="flex gap-2">
              <button
                onClick={onClose}
                className="flex-1 rounded-md bg-slate-100 py-2.5 text-sm font-bold text-slate-700"
              >
                取消 · Cancel
              </button>
              <button
                onClick={submit}
                disabled={busy}
                className="flex-1 rounded-md bg-fuchsia-600 hover:bg-fuchsia-500 text-white py-2.5 text-sm font-black disabled:opacity-50"
              >
                {busy ? "…" : "🎁 送出 · Send"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-slate-500">{label}</span>
      <span
        className={`tabular-nums inline-flex items-center gap-1 ${
          strong ? "font-black text-slate-900" : "text-slate-800"
        }`}
      >
        {value} <StarrIcon size={11} />
      </span>
    </div>
  );
}
