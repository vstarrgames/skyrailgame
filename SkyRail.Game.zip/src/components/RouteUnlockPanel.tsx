import { useState } from "react";
import { LINE_UNLOCKS, unlockLine, type LineKey } from "@/lib/wallet";
import { StarrIcon } from "./Starr";

export function RouteUnlockPanel({
  unlocked,
  tripCount,
  balance,
  onClose,
  onUnlocked,
}: {
  unlocked: string[];
  tripCount: number;
  balance: number;
  onClose: () => void;
  onUnlocked: (newBalance: number, unlockedLines: string[]) => void;
}) {
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function handleUnlock(key: LineKey, cost: number) {
    setBusy(key);
    setErr(null);
    try {
      const r = await unlockLine(key, cost);
      onUnlocked(r.new_balance, r.unlocked_lines);
    } catch (e) {
      const msg = (e as Error).message.includes("insufficient")
        ? "星幣不足 · Insufficient Starrs"
        : (e as Error).message;
      setErr(msg);
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="fixed inset-0 z-[95] bg-black/70 flex items-center justify-center p-3 overflow-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full p-5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black">🗺️ 路線解鎖 · Route Unlocks</h2>
            <p className="text-xs text-slate-500 mt-1">
              Complete trips OR spend Starrs to unlock more lines. 完成旅程或使用星幣解鎖線路。
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 font-bold"
          >
            ✕
          </button>
        </div>
        <div className="mt-3 flex items-center gap-3 text-xs">
          <span className="rounded bg-slate-100 px-2 py-1">
            旅程 Trips: <b>{tripCount}</b>
          </span>
          <span className="rounded bg-slate-100 px-2 py-1 inline-flex items-center gap-1">
            結餘 Balance: <StarrIcon size={12} /> <b>{balance}</b>
          </span>
        </div>
        {err && (
          <div className="mt-2 text-sm text-red-600 font-semibold">{err}</div>
        )}
        <ul className="mt-3 space-y-2 max-h-[60vh] overflow-y-auto">
          {LINE_UNLOCKS.map((l) => {
            const isUnlocked = unlocked.includes(l.key);
            const tripsLeft = Math.max(0, l.trips - tripCount);
            const canAffordCost = balance >= l.cost;
            const canFreeUnlock = tripCount >= l.trips && l.trips > 0;
            return (
              <li
                key={l.key}
                className={`rounded-lg border p-3 flex items-center gap-3 ${
                  isUnlocked
                    ? "bg-emerald-50 border-emerald-300"
                    : "bg-slate-50 border-slate-200"
                }`}
              >
                <div className="flex-1 min-w-0">
                  <div className="font-extrabold text-sm flex items-center gap-2 flex-wrap">
                    <span>{l.nameZh} · {l.nameEn}</span>
                    {l.originalCost && !isUnlocked && (
                      <span className="text-[9px] font-black uppercase tracking-wider bg-rose-600 text-white px-1.5 py-0.5 rounded animate-pulse">
                        限時優惠 LTO
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    難度 Difficulty:{" "}
                    <b className="text-slate-800">{l.difficulty}</b>
                    {l.trips === 0 ? (
                      <> · <span className="text-emerald-700 font-bold">預設解鎖 Default unlocked</span></>
                    ) : (
                      <>
                        {" · "}需要 Requires: <b>{l.trips} 旅程 trips</b> 或 or{" "}
                        {l.originalCost ? (
                          <>
                            <StarrIcon size={10} />{" "}
                            <s className="text-slate-400">{l.originalCost}</s>{" "}
                            <b className="text-rose-600">{l.cost}</b>
                          </>
                        ) : (
                          <>
                            <StarrIcon size={10} /> <b>{l.cost}</b>
                          </>
                        )}
                      </>
                    )}
                  </div>
                  {!isUnlocked && l.trips > 0 && (
                    <div className="text-[10px] mt-1 text-slate-500">
                      {tripsLeft > 0
                        ? `還需 ${tripsLeft} 次旅程 · ${tripsLeft} more trips`
                        : "已達旅程要求 · Trip requirement met"}
                    </div>
                  )}
                </div>
                {isUnlocked ? (
                  <span className="text-[11px] font-black text-emerald-700 bg-emerald-200 px-2 py-1 rounded uppercase">
                    ✓ Unlocked
                  </span>
                ) : (
                  <button
                    disabled={busy === l.key || (!canAffordCost && !canFreeUnlock)}
                    onClick={() => handleUnlock(l.key, canFreeUnlock ? 0 : l.cost)}
                    className="rounded-md bg-[#0a2540] hover:bg-[#173962] disabled:opacity-40 text-white px-3 py-2 text-xs font-bold whitespace-nowrap"
                  >
                    {busy === l.key
                      ? "…"
                      : canFreeUnlock
                        ? "免費解鎖 Unlock Free"
                        : `解鎖 Unlock · ${l.cost}`}
                  </button>
                )}
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
