import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ADMIN_EMAIL = "starradmin@skyrail.admin";

export const adminDeleteUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string }) => input)
  .handler(async ({ data, context }) => {
    const callerEmail = (context.claims as { email?: string } | undefined)?.email;
    if (callerEmail !== ADMIN_EMAIL) {
      throw new Error("forbidden");
    }
    if (data.userId === context.userId) {
      throw new Error("cannot_delete_self");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
