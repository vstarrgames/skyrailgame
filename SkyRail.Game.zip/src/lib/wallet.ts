import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session } from "@supabase/supabase-js";

export const ADMIN_USERNAME = "starradmin";
export const ADMIN_PASSWORD = "vstarrofficial";
export const ADMIN_EMAIL = "starradmin@skyrail.admin";

export function isAdminSession(session: Session | null): boolean {
  return !!session && session.user.email === ADMIN_EMAIL;
}

export function useSession() {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);
  return { session, ready };
}

export type Profile = {
  user_id: string;
  balance: number;
  total_earned?: number;
  unlocked_lines?: string[];
  hkd_spent_cents?: number;
  boost_multiplier?: number;
  boost_remaining_ms?: number;
  skin_tokens?: number;
  starrboxes?: number;
};

export const PRICE_ID_TO_STARRS: Record<string, number> = {
  starter_pack_price: 100,
  starr_pack_100_price: 100,
  starr_pack_220_price: 220,
  starr_pack_450_price: 450,
  starr_pack_1000_price: 1000,
  starr_pack_2500_price: 2500,
};

export type StarrboxResult = {
  kind: string;
  starrs_awarded: number;
  tokens_awarded: number;
  new_balance: number;
  new_boost_multiplier: number;
  new_boost_remaining_ms: number;
  new_skin_tokens: number;
  new_starrboxes: number;
};

export async function openStarrbox(useCredit: boolean): Promise<StarrboxResult> {
  const { data, error } = await (supabase as any).rpc("open_starrbox", {
    p_use_credit: useCredit,
  });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as StarrboxResult;
}

export async function redeemSkinTokens(count: number): Promise<{ new_balance: number; new_skin_tokens: number }> {
  const { data, error } = await (supabase as any).rpc("redeem_skin_tokens", {
    p_count: Math.max(1, Math.floor(count)),
  });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { new_balance: number; new_skin_tokens: number };
}


export function useProfile(session: Session | null) {
  const admin = isAdminSession(session);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [adCount, setAdCount] = useState(0);

  const refresh = useCallback(async () => {
    if (!session) {
      setProfile(null);
      setAdCount(0);
      return;
    }
    if (admin) {
      setProfile({
        user_id: session.user.id,
        balance: 10000,
        total_earned: 999999,
        unlocked_lines: ["L1", "L2", "L3", "L4", "L5", "L6", "L7", "AEX"],
        hkd_spent_cents: 0,
        boost_multiplier: 1,
        boost_remaining_ms: 0,
        skin_tokens: 0,
        starrboxes: 0,
      });
      setAdCount(0);
      return;
    }
    const { data } = await supabase
      .from("profiles")
      .select("user_id,balance,total_earned,unlocked_lines,hkd_spent_cents,boost_multiplier,boost_remaining_ms,skin_tokens,starrboxes" as any)
      .eq("user_id", session.user.id)
      .maybeSingle();
    if (data) setProfile(data as unknown as Profile);
    // Ad allowance resets at UTC midnight
    const startOfUtcDay = new Date();
    startOfUtcDay.setUTCHours(0, 0, 0, 0);
    const { count } = await supabase
      .from("ad_views")
      .select("*", { count: "exact", head: true })
      .eq("user_id", session.user.id)
      .gte("viewed_at", startOfUtcDay.toISOString());
    setAdCount(count ?? 0);
  }, [session, admin]);


  useEffect(() => {
    void refresh();
  }, [refresh]);

  return { profile, adCount, refresh, setProfile, isAdmin: admin };
}

export async function purchaseTicket(args: {
  from: string;
  to: string;
  seatClass: string;
  fare: number;
  seat: string;
}) {
  const { data, error } = await supabase.rpc("purchase_ticket", {
    p_from: args.from,
    p_to: args.to,
    p_seat_class: args.seatClass,
    p_fare: args.fare,
    p_seat: args.seat,
  });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { ticket_id: string; new_balance: number };
}

export async function claimAdReward() {
  const { data, error } = await supabase.rpc("claim_ad_reward");
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { new_balance: number; views_today: number };
}

export async function applyTripAdBonus(amount: number): Promise<number> {
  const { data, error } = await (supabase as any).rpc("apply_trip_ad_bonus", {
    p_amount: Math.max(0, Math.floor(amount)),
  });
  if (error) throw error;
  return typeof data === "number" ? data : Number(data) || 0;
}

export async function startJourney(from: string, to: string, minutes: number) {
  const { error } = await supabase.rpc("start_journey", {
    p_from: from,
    p_to: to,
    p_minutes: minutes,
  });
  if (error) throw error;
}

export async function endJourney(earned: number) {
  const { data, error } = await supabase.rpc("end_journey", { p_earned: earned });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { new_balance: number };
}

/* ── Starr Events (GMT+8) ──
   - Weekend (Sat/Sun): 2×
   - 1st of any month:  4×
   - Both stack:        6×
   - Admin special rush: multiplies further */
export function isDoubleStarrEvent(now: Date = new Date()): boolean {
  const g = new Date(now.getTime() + 8 * 3600 * 1000);
  const dow = g.getUTCDay();
  return dow === 6 || dow === 0;
}
export function isMonthlyStarrEvent(now: Date = new Date()): boolean {
  const g = new Date(now.getTime() + 8 * 3600 * 1000);
  return g.getUTCDate() === 1;
}
export function baseEventMultiplier(now: Date = new Date()): number {
  return (isDoubleStarrEvent(now) ? 2 : 1) * (isMonthlyStarrEvent(now) ? 4 : 1);
}
export function computeEventMultiplier(
  now: Date = new Date(),
  rush?: { multiplier: number; ends_at: string } | null,
): number {
  let m = baseEventMultiplier(now);
  if (rush && new Date(rush.ends_at).getTime() > now.getTime()) m *= rush.multiplier;
  return m;
}
export function msUntilNextEvent(now: Date = new Date()): number {
  const g = new Date(now.getTime() + 8 * 3600 * 1000);
  const dow = g.getUTCDay();
  if (dow === 6 || dow === 0) {
    const daysToMon = dow === 6 ? 2 : 1;
    const end = Date.UTC(g.getUTCFullYear(), g.getUTCMonth(), g.getUTCDate() + daysToMon, 0, 0, 0);
    return end - g.getTime();
  }
  const daysToSat = (6 - dow + 7) % 7;
  const start = Date.UTC(g.getUTCFullYear(), g.getUTCMonth(), g.getUTCDate() + daysToSat, 0, 0, 0);
  return start - g.getTime();
}

/* ── Gifts ── */
export type PendingGift = {
  id: string;
  sender_name: string;
  amount_net: number;
  from_admin: boolean;
  created_at: string;
};
export async function sendStarrGift(recipientEmail: string, amount: number) {
  const { data, error } = await (supabase as any).rpc("send_starr_gift", {
    p_recipient_email: recipientEmail.trim(),
    p_amount: Math.floor(amount),
  });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { new_balance: number; net_delivered: number };
}
export async function listPendingGifts(): Promise<PendingGift[]> {
  const { data, error } = await (supabase as any).rpc("list_pending_gifts");
  if (error) return [];
  return (data ?? []) as PendingGift[];
}
export async function claimStarrGifts() {
  const { data, error } = await (supabase as any).rpc("claim_starr_gifts");
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { total_claimed: number; new_balance: number };
}

/* ── Special admin rush ── */
export type RushRow = { id: string; multiplier: number; ends_at: string };
export async function getCurrentRush(): Promise<RushRow | null> {
  const { data, error } = await (supabase as any).rpc("current_rush");
  if (error) return null;
  const row = Array.isArray(data) ? data[0] : data;
  return (row ?? null) as RushRow | null;
}
export async function adminStartRush(durationMinutes: number, multiplier: number) {
  const { data, error } = await (supabase as any).rpc("admin_start_rush", {
    p_duration_minutes: Math.floor(durationMinutes),
    p_multiplier: Math.floor(multiplier),
  });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as RushRow;
}

/* ── Daily Login ── */
export async function getDailyLoginStatus() {
  const { data, error } = await supabase.rpc("get_daily_login_status");
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as {
    streak_day: number;
    last_claim_date: string | null;
    can_claim: boolean;
    next_day: number;
  };
}
export async function claimDailyLogin() {
  const { data, error } = await supabase.rpc("claim_daily_login");
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { day: number; reward: number; new_balance: number; claimed: boolean };
}

export async function fetchMyBan() {
  const { data, error } = await supabase.rpc("my_ban");
  if (error) return null;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { banned_until: string | null; permanent: boolean } | null;
}

export type AdminUserRow = {
  user_id: string;
  email: string;
  balance: number;
  created_at: string;
  is_in_transit: boolean;
  banned_until: string | null;
  banned_permanent: boolean;
};

export async function adminListUsers(): Promise<AdminUserRow[]> {
  const { data, error } = await supabase.rpc("admin_list_users");
  if (error) throw error;
  return (data as AdminUserRow[]) ?? [];
}

export async function adminStats() {
  const { data, error } = await supabase.rpc("admin_stats");
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { total_users: number; in_transit: number };
}

export async function adminBanUser(userId: string, until: Date | null, permanent: boolean) {
  const { error } = await supabase.rpc("admin_ban_user", {
    p_user: userId,
    p_until: (until ? until.toISOString() : null) as unknown as string,
    p_permanent: permanent,
  });
  if (error) throw error;
}

export async function adminUnbanUser(userId: string) {
  const { error } = await supabase.rpc("admin_unban_user", { p_user: userId });
  if (error) throw error;
}

export function generateSeat(): string {
  const car = 1 + Math.floor(Math.random() * 8);
  const row = 1 + Math.floor(Math.random() * 10);
  const letter = "ABCDEF"[Math.floor(Math.random() * 6)];
  return `${car}-${row}${letter}`;
}

export function fmtGmt8(d: Date): string {
  const g = new Date(d.getTime() + 8 * 3600 * 1000);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${g.getUTCFullYear()}-${p(g.getUTCMonth() + 1)}-${p(g.getUTCDate())} ${p(g.getUTCHours())}:${p(g.getUTCMinutes())} GMT+8`;
}

/* ── Route unlock system ── */
export type LineKey = "L1" | "L2" | "L3" | "L4" | "L5" | "L6" | "L7" | "AEX";

export const LINE_UNLOCKS: {
  key: LineKey;
  trips: number;
  cost: number;
  /** Original list price (for showing "Limited Time Offer" strikethrough) */
  originalCost?: number;
  difficulty: number;
  nameZh: string;
  nameEn: string;
}[] = [
  // Airport Rapid is now the easiest baseline (matches original Line 1 difficulty).
  // All other lines have been drastically re-scaled to be significantly harder.
  { key: "L1",  trips: 0,   cost: 0,    difficulty: 3,  nameZh: "1號線 主幹線",   nameEn: "Line 1 Main" },
  { key: "L2",  trips: 3,   cost: 50,   difficulty: 4,  nameZh: "2號線 星利線",   nameEn: "Line 2 Starrley" },
  { key: "L3",  trips: 8,   cost: 120,  originalCost: 150, difficulty: 5,  nameZh: "3號線 群島線", nameEn: "Line 3 Islands" },
  { key: "L4",  trips: 15,  cost: 300,  originalCost: 400, difficulty: 6,  nameZh: "4號線 機場線", nameEn: "Line 4 Airport" },
  { key: "L5",  trips: 40,  cost: 800,  difficulty: 7,  nameZh: "5號線 循環線",   nameEn: "Line 5 Loop" },
  { key: "L7",  trips: 80,  cost: 1500, difficulty: 8,  nameZh: "7號線 發財線",   nameEn: "Line 7 Fortune" },
  { key: "L6",  trips: 100, cost: 2000, difficulty: 10, nameZh: "6號線 口岸線",   nameEn: "Line 6 Port" },
  { key: "AEX", trips: 200, cost: 5000, difficulty: 1,  nameZh: "機場特急",       nameEn: "Airport Rapid" },
];

export async function unlockLine(line: string, cost: number) {
  const { data, error } = await supabase.rpc("unlock_line", { p_line: line, p_cost: cost });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { new_balance: number; unlocked_lines: string[] };
}

export async function autoUnlockLines() {
  const { data, error } = await supabase.rpc("auto_unlock_lines");
  if (error) throw error;
  return (data ?? []) as string[];
}

export async function countMyTickets(): Promise<number> {
  const { count } = await supabase
    .from("tickets")
    .select("*", { count: "exact", head: true });
  return count ?? 0;
}

/* ── Leaderboards ── */
export type LbRow = { user_id: string; display_name: string; count?: number; total?: number };
export async function fetchLeaderboards() {
  const [a, b, c, d] = await Promise.all([
    supabase.rpc("leaderboard_trips"),
    supabase.rpc("leaderboard_first_class"),
    supabase.rpc("leaderboard_earned"),
    (supabase as any).rpc("leaderboard_spent"),
  ]);
  return {
    trips: (a.data ?? []) as LbRow[],
    firstClass: (b.data ?? []) as LbRow[],
    earned: (c.data ?? []) as LbRow[],
    spent: (d.data ?? []) as LbRow[],
  };
}

/* ── Boost consumption (gameplay-active) ── */
export async function consumeBoost(elapsedMs: number) {
  const { data, error } = await (supabase as any).rpc("consume_boost", {
    p_elapsed_ms: Math.max(0, Math.round(elapsedMs)),
  });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return row as { boost_multiplier: number; boost_remaining_ms: number };
}

export function formatHkd(cents: number): string {
  return `HK$${(cents / 100).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

