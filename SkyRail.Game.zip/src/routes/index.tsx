import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import startAsset from "@/assets/skyrail-go.png.asset.json";
import { JOKES } from "@/data/jokes";
import { StarrIcon, Price } from "@/components/Starr";
import { AuthDialog } from "@/components/AuthDialog";
import { PurchaseModal, type FareOption } from "@/components/PurchaseModal";
import { TicketDisplay, type TicketInfo } from "@/components/Ticket";
import { AdWatch } from "@/components/AdWatch";
import { TravelView, JourneyCompleteModal, type TravelData } from "@/components/TravelView";
import { AdminPanel, BanScreen } from "@/components/AdminPanel";
import { WeekendEvent } from "@/components/WeekendEvent";
import { DailyLogin } from "@/components/DailyLogin";
import { supabase } from "@/integrations/supabase/client";
import {
  useSession,
  useProfile,
  purchaseTicket,
  generateSeat,
  fmtGmt8,
  startJourney,
  fetchMyBan,
  autoUnlockLines,
  countMyTickets,
  LINE_UNLOCKS,
  applyTripAdBonus,
} from "@/lib/wallet";
import { StarrShop } from "@/components/StarrShop";
import { Leaderboard } from "@/components/Leaderboard";
import { RouteUnlockPanel } from "@/components/RouteUnlockPanel";
import { Tutorial } from "@/components/Tutorial";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { MusicPlayer } from "@/components/MusicPlayer";
import { InfoDialog } from "@/components/InfoDialog";
import { TokenWalletDialog } from "@/components/TokenWalletDialog";
import { GiftInbox } from "@/components/GiftInbox";
import { SendGiftDialog } from "@/components/SendGiftDialog";


import type { StationStop } from "@/components/TravelView";

// Line 2 extension: stations that only open on 2026-09-01 00:00 GMT+8 (= 2026-08-31 16:00 UTC)
const L2_EXTENSION_STATIONS = new Set(["SLH", "USE", "STT", "SRZ", "DEP"]);
const L2_EXTENSION_UNLOCK_MS = Date.UTC(2026, 7, 31, 16, 0, 0);




export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SkyRail.Game" },
      {
        name: "description",
        content:
          "- An interactive web app for exploring railway routes, fares, and station information in Traditional Chinese and English, now with an active transit journey fea",
      },
      { property: "og:title", content: "SkyRail.Game" },
      {
        property: "og:description",
        content: "- An interactive web app for exploring railway routes, fares, and station information in Traditional Chinese and English, now with an active transit journey fea",
      },
    ],
  }),
  component: Index,
});

/* ───────────── Data ───────────── */

type LabelPos = "top" | "bottom" | "left" | "right";
type Station = {
  id: string;
  en: string;
  zh: string;
  x: number;
  y: number;
  zone: number;
  lp?: LabelPos;
};
type DrawPoint = string | [number, number];

const STATIONS: Station[] = [
  { id: "SHP", en: "Starrhong Port", zh: "星鴻口岸", x: 40, y: 380, zone: 1, lp: "top" },
  { id: "SHG", en: "Starrhong", zh: "星鴻", x: 150, y: 380, zone: 2, lp: "bottom" },
  { id: "SHN", en: "Starrhong North", zh: "星鴻北", x: 270, y: 380, zone: 2, lp: "top" },
  { id: "SYT", en: "Starryan Temple", zh: "星賢廟", x: 385, y: 380, zone: 3, lp: "top" },
  { id: "SWT", en: "Starrwei Temple", zh: "星衛廟", x: 500, y: 380, zone: 3, lp: "top" },
  { id: "SFA", en: "Starrfa", zh: "星發", x: 620, y: 380, zone: 3, lp: "left" },
  { id: "SLU", en: "Starrlu", zh: "星祿", x: 620, y: 285, zone: 3, lp: "right" },
  { id: "SFU", en: "Starrfu", zh: "星富", x: 620, y: 195, zone: 3, lp: "right" },
  { id: "STL", en: "Starr Lake-Border", zh: "星湖·邊境", x: 620, y: 105, zone: 3, lp: "right" },
  { id: "UNS", en: "UniStarr South", zh: "元星南", x: 40, y: 620, zone: 2, lp: "top" },
  { id: "UNN", en: "UniStarr North", zh: "元星北", x: 130, y: 620, zone: 2, lp: "top" },
  { id: "SSC", en: "Starr Space City", zh: "天星城", x: 225, y: 620, zone: 4, lp: "top" },
  { id: "SSE", en: "Starr Space Est.", zh: "天星邨", x: 325, y: 620, zone: 4, lp: "top" },
  { id: "DSH", en: "Dawn Starr Hill", zh: "星夕山", x: 420, y: 620, zone: 4, lp: "top" },
  { id: "CRC", en: "Crystal Coast", zh: "水晶海岸", x: 530, y: 620, zone: 5, lp: "top" },
  { id: "GIS", en: "Gold Island", zh: "黃金島", x: 620, y: 620, zone: 5, lp: "bottom" },
  { id: "MFT", en: "MF Tail", zh: "山田尾", x: 715, y: 620, zone: 6, lp: "top" },
  { id: "MFC", en: "MF Central", zh: "山田中", x: 815, y: 620, zone: 6, lp: "top" },
  { id: "SNL", en: "Snowland", zh: "雪地", x: 950, y: 620, zone: 6, lp: "top" },
  { id: "NTC", en: "Northern Chung", zh: "北涌", x: 1045, y: 620, zone: 7, lp: "top" },
  { id: "AAM", en: "Anti-Adopt Me!", zh: "反收養我", x: 1145, y: 620, zone: 7, lp: "top" },
  { id: "SDC", en: "Starr Dream City", zh: "星夢城", x: 1265, y: 620, zone: 7, lp: "bottom" },
  { id: "AT1", en: "Airport (Terminal 1)", zh: "機場T1", x: 1370, y: 620, zone: 8, lp: "top" },
  { id: "AT2", en: "Airport (Terminal 2)", zh: "機場T2", x: 1495, y: 620, zone: 8, lp: "top" },
  { id: "GBY", en: "Galactic Bay", zh: "碧灣", x: 1620, y: 620, zone: 10, lp: "bottom" },
  { id: "WTC", en: "Western C", zh: "西絲", x: 1720, y: 620, zone: 10, lp: "top" },
  { id: "ETC", en: "Eastern C", zh: "東絲", x: 1820, y: 620, zone: 10, lp: "top" },
  { id: "STU", en: "Starr University", zh: "元星大學", x: 40, y: 720, zone: 2, lp: "left" },
  { id: "UNE", en: "University East", zh: "大學東", x: 40, y: 800, zone: 2, lp: "left" },
  { id: "SRL", en: "Starrleyland", zh: "星利樂園", x: 40, y: 880, zone: 2, lp: "left" },
  { id: "SLH", en: "Starrleyland Hotel", zh: "星利酒店", x: 40, y: 965, zone: 2, lp: "left" },
  { id: "USE", en: "UniStarr East", zh: "元星東", x: 200, y: 1055, zone: 2, lp: "bottom" },
  { id: "STT", en: "Starrtin", zh: "星田", x: 345, y: 1055, zone: 2, lp: "bottom" },
  { id: "SRZ", en: "Starrizon", zh: "天際星田", x: 490, y: 1055, zone: 2, lp: "bottom" },
  { id: "DEP", en: "SkyRail Starrtin Depot", zh: "天鐵星田車廠", x: 640, y: 1055, zone: 2, lp: "bottom" },
  { id: "PEA", en: "Peach Starr", zh: "星桃", x: 370, y: 495, zone: 4, lp: "top" },
  { id: "MEL", en: "Melon Starr", zh: "星瓜", x: 540, y: 495, zone: 5, lp: "top" },
  { id: "GUG", en: "Gugu Resort", zh: "咕咕半島", x: 620, y: 790, zone: 5, lp: "left" },
  { id: "MIS", en: "Mo Island", zh: "毛島", x: 720, y: 790, zone: 5, lp: "bottom" },
  { id: "CEC", en: "MF Conv. & Expo Centre", zh: "山田會展", x: 815, y: 790, zone: 6, lp: "right" },
  { id: "MFW", en: "MF West", zh: "山田西", x: 815, y: 440, zone: 6, lp: "left" },
  { id: "RVS", en: "Riverside", zh: "河畔", x: 815, y: 365, zone: 6, lp: "right" },
  { id: "TOS", en: "The One Starr", zh: "這一星", x: 815, y: 285, zone: 6, lp: "left" },
  { id: "CUL", en: "Cultural District", zh: "文化區", x: 1330, y: 455, zone: 7, lp: "top" },
  { id: "APG", en: "Airport Ground", zh: "機場地勤", x: 1375, y: 840, zone: 7, lp: "bottom" },
  { id: "ATV", en: "Airport TV", zh: "電視臺", x: 1490, y: 840, zone: 7, lp: "bottom" },
  {
    id: "GBC",
    en: "Galactic Bay Cont. Pier",
    zh: "碧灣貨櫃碼頭",
    x: 1620,
    y: 510,
    zone: 9,
    lp: "right",
  },
  { id: "CTN", en: "Container's Island", zh: "貨櫃島", x: 1770, y: 350, zone: 9, lp: "top" },
  { id: "LUS", en: "Lunar Starr", zh: "月星", x: 925, y: 175, zone: 6, lp: "top" },
  { id: "SOS", en: "Solar Starr", zh: "日星", x: 1055, y: 175, zone: 6, lp: "top" },
  { id: "POS", en: "Polar Starr", zh: "極星", x: 1185, y: 175, zone: 6, lp: "top" },
  { id: "STP", en: "Starrport", zh: "星港", x: 1310, y: 175, zone: 9, lp: "top" },
  { id: "SFP", en: "Starrport Ferry Pier", zh: "星港碼頭", x: 1425, y: 175, zone: 9, lp: "top" },
  { id: "LOG", en: "Logistics Hub", zh: "物流中心", x: 1565, y: 175, zone: 9, lp: "top" },
  { id: "SNB", en: "Snowball", zh: "雪球", x: 1135, y: 510, zone: 6, lp: "top" },
  { id: "SLS", en: "Snowland West", zh: "雪地西", x: 995, y: 510, zone: 6, lp: "top" },
];

const STATION_MAP: Record<string, Station> = Object.fromEntries(STATIONS.map((s) => [s.id, s]));

/* ───────── Timetable (GMT+8) ───────── */
// [startMin, endMin) since 00:00, intervals per line [L1,L2,L3,L4,L5]
type Freq = number[];
const SCHEDULE: { start: number; end: number; freq: Freq }[] = [
  { start: 0,    end: 300,  freq: [15, 30, 20, 30, 20, 20, 30] },
  { start: 300,  end: 360,  freq: [10, 30, 10, 10, 20, 15, 10] },
  { start: 360,  end: 420,  freq: [10,  6, 10, 10, 10, 10, 10] },
  { start: 420,  end: 450,  freq: [ 5,  6,  6, 10, 10, 10,  6] },
  { start: 450,  end: 540,  freq: [ 3,  6,  4, 10,  8,  8,  6] },
  { start: 540,  end: 570,  freq: [ 3,  6,  4, 15,  8,  8, 10] },
  { start: 570,  end: 600,  freq: [ 5,  6,  6, 15,  8,  8, 10] },
  { start: 600,  end: 900,  freq: [ 5, 10,  6, 15,  8,  8, 10] },
  { start: 900,  end: 930,  freq: [ 4, 10,  4, 15,  8,  8, 10] },
  { start: 930,  end: 960,  freq: [ 4, 10,  4, 15,  6,  8, 10] },
  { start: 960,  end: 1040, freq: [ 4,  6,  4, 10,  6,  6,  6] },
  { start: 1040, end: 1160, freq: [ 3,  6,  3, 10,  6,  6,  6] },
  { start: 1160, end: 1170, freq: [ 5,  6, 10, 10,  6,  6, 10] },
  { start: 1170, end: 1200, freq: [ 5, 10, 10, 15,  6,  8, 10] },
  { start: 1200, end: 1380, freq: [ 5, 10, 10, 15, 10, 10, 10] },
  { start: 1380, end: 1440, freq: [10, 10, 20, 15, 10, 15, 20] },
];

function gmt8Now(date: Date): { h: number; m: number; s: number; minutes: number } {
  // Convert to GMT+8 regardless of viewer's timezone
  const utc = date.getTime() + date.getTimezoneOffset() * 60000;
  const d = new Date(utc + 8 * 3600 * 1000);
  return {
    h: d.getHours(),
    m: d.getMinutes(),
    s: d.getSeconds(),
    minutes: d.getHours() * 60 + d.getMinutes(),
  };
}

function activeFreq(minutes: number): Freq {
  const slot = SCHEDULE.find((s) => minutes >= s.start && minutes < s.end) ?? SCHEDULE[0];
  const freq: Freq = [...slot.freq];
  freq[5] = l6Freq(minutes, isWeekendGmt8(new Date()));
  freq[6] = l7Freq(minutes);
  return freq;
}

/* Line 6 (Port Line) has its own weekday/weekend schedule. */
const L6_WEEKDAY: [number, number, number][] = [
  [0, 300, 25],
  [300, 420, 10],
  [420, 540, 5],
  [540, 990, 10],
  [990, 1140, 5],
  [1140, 1320, 10],
  [1320, 1440, 15],
];
const L6_WEEKEND: [number, number, number][] = [
  [0, 300, 15],
  [300, 420, 6],
  [420, 540, 3],
  [540, 990, 6],
  [990, 1140, 3],
  [1140, 1320, 6],
  [1320, 1440, 10],
];
function l6Freq(minutes: number, weekend: boolean): number {
  const arr = weekend ? L6_WEEKEND : L6_WEEKDAY;
  const s = arr.find(([a, b]) => minutes >= a && minutes < b) ?? arr[0];
  return s[2];
}
function isWeekendGmt8(date: Date): boolean {
  const utc = date.getTime() + date.getTimezoneOffset() * 60000;
  const d = new Date(utc + 8 * 3600 * 1000);
  const dow = d.getDay();
  return dow === 0 || dow === 6;
}

/* Line 7 (Fortune Line) headway schedule. */
const L7_SCHEDULE: [number, number, number][] = [
  [0, 300, 30],
  [300, 420, 10],
  [420, 540, 6],
  [540, 990, 10],
  [990, 1140, 6],
  [1140, 1320, 10],
  [1320, 1440, 20],
];
function l7Freq(minutes: number): number {
  const s = L7_SCHEDULE.find(([a, b]) => minutes >= a && minutes < b) ?? L7_SCHEDULE[0];
  return s[2];
}

// Next departure offset (minutes from hour start). If next falls past hour end (60),
// it crosses into the next hour, which then uses whatever interval is active there.
function nextDepartureFromHour(currentMinuteInHour: number, currentSecond: number, interval: number) {
  // Departures at 0, interval, 2*interval, ... within the hour
  const passed = currentMinuteInHour + currentSecond / 60;
  const n = Math.ceil(passed / interval);
  const next = n * interval;
  const wait = next - passed;
  return { nextMinuteInHour: next, waitMinutes: wait };
}

type Line = {
  id: string;
  nameEn: string;
  nameZh: string;
  color: string;
  path: string[];
  draw?: DrawPoint[];
  dashDraw?: DrawPoint[];
  express?: boolean;
};

const LINES: Line[] = [
  {
    id: "L1",
    nameEn: "Line 1 Main",
    nameZh: "1號線 主幹線",
    color: "#1f4754",
    path: [
      "UNS",
      "UNN",
      "SSC",
      "SSE",
      "DSH",
      "CRC",
      "GIS",
      "MFT",
      "MFC",
      "SNL",
      "NTC",
      "AAM",
      "SDC",
      "AT1",
      "AT2",
      "GBY",
      "WTC",
      "ETC",
    ],
  },
  {
    id: "L2",
    nameEn: "Line 2 Starrley",
    nameZh: "2號線 星利線",
    color: "#2e7d3a",
    path: ["UNS", "STU", "UNE", "SRL", "SLH", "USE", "STT", "SRZ", "DEP"],
    draw: ["UNS", [40, 720], "STU", "UNE", "SRL"],
    dashDraw: ["SRL", "SLH", [40, 1055], "USE", "STT", "SRZ", "DEP"],
  },
  {
    id: "L3",
    nameEn: "Line 3 Islands",
    nameZh: "3號線 群島線",
    color: "#8b1a1a",
    path: ["SSC", "PEA", "MEL", "GIS", "GUG", "MIS", "CEC", "MFC", "MFW", "RVS"],
    draw: [
      "SSC",
      [225, 495],
      "PEA",
      "MEL",
      [620, 495],
      "GIS",
      "GUG",
      "MIS",
      "CEC",
      "MFC",
      "MFW",
      "RVS",
    ],
  },
  {
    id: "L4a",
    nameEn: "Line 4 Airport",
    nameZh: "4號線 機場線",
    color: "#b8860b",
    path: ["SDC", "CUL"],
    draw: ["SDC", [1265, 455], "CUL"],
  },
  {
    id: "L4b",
    nameEn: "Line 4 Airport",
    nameZh: "4號線 機場線",
    color: "#b8860b",
    path: ["SDC", "APG", "ATV", "GBY"],
    draw: ["SDC", [1265, 840], "APG", "ATV", [1620, 840], "GBY"],
  },
  {
    id: "L4c",
    nameEn: "Line 4 Airport",
    nameZh: "4號線 機場線",
    color: "#b8860b",
    path: ["GBY", "GBC", "CTN"],
    draw: ["GBY", "GBC", [1620, 350], "CTN"],
  },
  {
    id: "L5",
    nameEn: "Line 5 Loop",
    nameZh: "5號線 循環線",
    color: "#6a1b9a",
    path: [
      "TOS",
      "LUS",
      "SOS",
      "POS",
      "STP",
      "SFP",
      "LOG",
      "CTN",
      "GBC",
      "SNB",
      "SLS",
      "RVS",
      "TOS",
    ],
    draw: [
      "TOS",
      [815, 175],
      "LUS",
      "SOS",
      "POS",
      "STP",
      "SFP",
      "LOG",
      [1770, 175],
      "CTN",
      [1770, 510],
      "GBC",
      "SNB",
      "SLS",
      [835, 510],
      [835, 365],
      "RVS",
      "TOS",
    ],
  },
  {
    id: "AEX",
    nameEn: "Airport Rapid",
    nameZh: "機場特急",
    color: "#5eead4",
    express: true,
    path: ["UNS", "SSC", "MFC", "AT1", "AT2"],
    // Strictly parallel dedicated line below Line 1 (y=620). Never shares track.
    draw: [
      [40, 675],
      [1495, 675],
    ],
  },
  {
    id: "L6",
    nameEn: "Line 6 Port",
    nameZh: "6號線 口岸線",
    color: "#94a3b8",
    path: ["SHP", "SHG", "UNS"],
    draw: ["SHP", "SHG", [150, 620], "UNS"],
  },
  {
    id: "L7",
    nameEn: "Line 7 Fortune",
    nameZh: "7號線 發財線",
    color: "#e8672c",
    path: ["STL", "SFU", "SLU", "SFA", "SWT", "SYT", "SHN", "SHG"],
    draw: ["STL", "SFU", "SLU", "SFA", "SWT", "SYT", "SHN", "SHG"],
  },
];

/* Fare table indexed [boardZone-1][alightZone-1] per official SkyRail Fare Calculation Table.
   Zone 1=SHP, 2=UNS/L2 area+SHG/SHN, 3=Line 7 stations, 4=SSC..PEA, 5=MEL/CRC/GIS/GUG/MIS,
   6=MF area+Line 5 north+SNL, 7=NTC..ATV, 8=AT1/AT2 ("/"), 9=STP..GBC, 10=GBY/WTC/ETC. */
const FARE_TABLE: number[][] = [
  [ 0, 36, 38, 48, 62, 70, 82, 96, 88, 94],
  [36, 28, 24, 26, 32, 46, 60, 76, 72, 80],
  [38, 24, 20, 26, 32, 46, 60, 76, 72, 80],
  [48, 26, 26, 16, 28, 40, 52, 68, 64, 70],
  [62, 32, 32, 28, 18, 30, 38, 54, 50, 56],
  [70, 46, 46, 40, 30, 22, 36, 52, 46, 52],
  [82, 60, 60, 52, 38, 36, 20, 28, 26, 28],
  [96, 76, 76, 68, 54, 52, 28,  0, 30, 32],
  [88, 72, 72, 64, 50, 46, 26, 30, 18, 26],
  [94, 80, 80, 70, 56, 52, 28, 32, 26, 18],
];

/* Build adjacency from all line segments. */
const ADJ: Record<string, Set<string>> = {};
for (const s of STATIONS) ADJ[s.id] = new Set();
for (const line of LINES) {
  if (line.express) continue;
  for (let i = 0; i < line.path.length - 1; i++) {
    const a = line.path[i],
      b = line.path[i + 1];
    if (a === b) continue;
    ADJ[a].add(b);
    ADJ[b].add(a);
  }
}

/* edgeLines: undirected edge "A|B" (sorted) -> set of line group ids (L1, L2, L3, L4, L5). */
function lineGroup(id: string): string {
  return id.replace(/[a-z]$/, "");
}
const EDGE_LINES: Record<string, Set<string>> = {};
for (const line of LINES) {
  if (line.express) continue;
  for (let i = 0; i < line.path.length - 1; i++) {
    const a = line.path[i],
      b = line.path[i + 1];
    if (a === b) continue;
    const key = a < b ? `${a}|${b}` : `${b}|${a}`;
    (EDGE_LINES[key] ??= new Set()).add(lineGroup(line.id));
  }
}
function linesOfEdge(a: string, b: string): string[] {
  const key = a < b ? `${a}|${b}` : `${b}|${a}`;
  return Array.from(EDGE_LINES[key] ?? []);
}

/* Station -> ordered list of line groups (L1..L5) that serve it. */
const STATION_LINES: Record<string, string[]> = {};
for (const line of LINES) {
  if (line.express) continue;
  const g = lineGroup(line.id);
  for (const sid of line.path) {
    const arr = (STATION_LINES[sid] ??= []);
    if (!arr.includes(g)) arr.push(g);
  }
}

const LINE_META: Record<string, { c: string; n: string; idx: number }> = {
  L1: { c: "#1f4754", n: "1號線 主幹線 Line 1 Main", idx: 0 },
  L2: { c: "#2e7d3a", n: "2號線 星利線 Line 2 Starrley", idx: 1 },
  L3: { c: "#8b1a1a", n: "3號線 群島線 Line 3 Islands", idx: 2 },
  L4: { c: "#b8860b", n: "4號線 機場線 Line 4 Airport", idx: 3 },
  L5: { c: "#6a1b9a", n: "5號線 循環線 Line 5 Loop", idx: 4 },
  L6: { c: "#94a3b8", n: "6號線 口岸線 Line 6 Port", idx: 5 },
  L7: { c: "#e8672c", n: "7號線 發財線 Line 7 Fortune", idx: 6 },
  AEX: { c: "#5eead4", n: "機場特急 Airport Rapid", idx: -1 },
};

/* ───────── Airport Rapid ───────── */
const AEX_PATH: string[] = ["UNS", "SSC", "MFC", "AT1", "AT2"];
const AEX_STOPS = new Set<string>(AEX_PATH);
const AEX_EDGE_TIMES: Record<string, number> = {
  "UNS|SSC": 7,
  "MFC|SSC": 12,
  "AT1|MFC": 15,
  "AT1|AT2": 4,
};
function aexEdgeTime(a: string, b: string): number {
  const k = a < b ? `${a}|${b}` : `${b}|${a}`;
  return AEX_EDGE_TIMES[k] ?? 0;
}
function aexFreq(minutes: number): number {
  // 0000–0500 → 30 min; 0500–0000 → 15 min
  return minutes < 300 ? 30 : 15;
}
function aexFare(start: string | null, end: string | null): number | null {
  if (!start || !end) return null;
  if (!AEX_STOPS.has(start) || !AEX_STOPS.has(end)) return null;
  if (start === end) return null;
  const isAirport = (id: string) => id === "AT1" || id === "AT2";
  const a = isAirport(start), b = isAirport(end);
  // Airport-to-airport is forbidden elsewhere; AEX itself does not serve this either.
  if (a && b) return null;
  // Either both non-airport (no airport endpoint) → no AEX fare applicable
  if (!a && !b) return null;
  const nonAirport = a ? end : start;
  if (nonAirport === "MFC") return 128;
  if (nonAirport === "UNS" || nonAirport === "SSC") return 188;
  return null;
}

/* Travel time per edge in minutes. Default 3, with overrides. */
const EDGE_TIME_OVERRIDES: Record<string, number> = {
  "UNS|UNN": 4,
  "SSC|UNN": 5,
  "PEA|SSC": 5,
  "GIS|MEL": 5,
  "NTC|SNL": 6,
  "AT1|SDC": 4,
  "AT2|GBY": 5,
  "GBY|WTC": 5,
  "POS|STP": 5,
  "GBC|SNB": 9,
  "SHG|SHP": 6,
  "SHG|UNS": 4,
  "STT|USE": 4,
  "SRL|UNE": 4,
};
const TRANSFER_MINUTES = 3;
function edgeTime(a: string, b: string): number {
  const key = a < b ? `${a}|${b}` : `${b}|${a}`;
  return EDGE_TIME_OVERRIDES[key] ?? 3;
}
function pathTravelTime(path: string[]): number {
  if (path.length < 2) return 0;
  let t = 0;
  for (let i = 0; i < path.length - 1; i++) t += edgeTime(path[i], path[i + 1]);
  return t;
}

/* ───────── Daily Challenge ───────── */
function dailyDateKeyGmt8(now: Date = new Date()): string {
  const g = new Date(now.getTime() + 8 * 3600 * 1000);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${g.getUTCFullYear()}-${p(g.getUTCMonth() + 1)}-${p(g.getUTCDate())}`;
}
function seededRng(seed: string): () => number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return () => {
    h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 3266489909) >>> 0;
    h = (h ^ (h >>> 16)) >>> 0;
    return h / 4294967296;
  };
}
function generateDailyChallengePath(dateKey: string): string[] {
  const rng = seededRng(`skyrail-daily-${dateKey}`);
  const stationsList = Object.keys(ADJ).filter((id) => (ADJ[id]?.size ?? 0) > 0);
  const targetLen = 3 + Math.floor(rng() * 6); // 3..8 stations
  // Try up to 30 seeds to find a walk that hits targetLen without dead-ending too soon.
  for (let attempt = 0; attempt < 30; attempt++) {
    const start = stationsList[Math.floor(rng() * stationsList.length)];
    const path: string[] = [start];
    const seen = new Set<string>([start]);
    while (path.length < targetLen) {
      const cur = path[path.length - 1];
      const neighbours = Array.from(ADJ[cur] ?? []).filter((n) => !seen.has(n));
      if (neighbours.length === 0) break;
      const pick = neighbours[Math.floor(rng() * neighbours.length)];
      path.push(pick);
      seen.add(pick);
    }
    if (path.length >= 3) return path;
  }
  // Fallback: any two adjacent stations
  const s = stationsList[0];
  const n = Array.from(ADJ[s] ?? [])[0] ?? s;
  return [s, n];
}
function pickLineSequenceForPath(path: string[]): string[] {
  const seq: string[] = [];
  let prev: string | null = null;
  for (let i = 0; i < path.length - 1; i++) {
    const options = linesOfEdge(path[i], path[i + 1]);
    const pick: string =
      prev && options.includes(prev) ? prev : options[0] ?? "L1";
    seq.push(pick);
    prev = pick;
  }
  return seq;
}

function pointToCoord(point: DrawPoint) {
  if (typeof point === "string") {
    const station = STATION_MAP[point];
    return { x: station.x, y: station.y };
  }
  return { x: point[0], y: point[1] };
}

function pathToSvg(points: DrawPoint[]) {
  return points
    .map((point, index) => {
      const { x, y } = pointToCoord(point);
      return `${index === 0 ? "M" : "L"}${x},${y}`;
    })
    .join(" ");
}

/* BFS for fewest-stations route. */
function shortestPath(start: string, end: string): string[] | null {
  if (start === end) return [start];
  const prev: Record<string, string | null> = { [start]: null };
  const queue: string[] = [start];
  while (queue.length) {
    const cur = queue.shift()!;
    for (const nb of ADJ[cur] ?? []) {
      if (nb in prev) continue;
      prev[nb] = cur;
      if (nb === end) {
        const path: string[] = [];
        let n: string | null = nb;
        while (n) {
          path.unshift(n);
          n = prev[n];
        }
        return path;
      }
      queue.push(nb);
    }
  }
  return null;
}

/* Fastest path: Dijkstra on (station, line) minimizing travel time + transfer penalty. */
function fastestPath(
  start: string,
  end: string,
): { path: string[]; transfers: number; time: number } | null {
  if (start === end) return { path: [start], transfers: 0, time: 0 };
  type State = { station: string; line: string };
  const key = (s: State) => `${s.station}|${s.line}`;
  const dist: Record<string, number> = {};
  const prev: Record<string, { key: string } | null> = {};
  const pq: Array<{ cost: number; state: State }> = [];
  const startLines = new Set<string>();
  for (const nb of ADJ[start] ?? []) for (const l of linesOfEdge(start, nb)) startLines.add(l);
  if (startLines.size === 0) startLines.add("L1");
  for (const l of startLines) {
    const st = { station: start, line: l };
    dist[key(st)] = 0;
    prev[key(st)] = null;
    pq.push({ cost: 0, state: st });
  }
  let bestEndKey: string | null = null;
  let bestEndCost = Infinity;
  while (pq.length) {
    pq.sort((a, b) => a.cost - b.cost);
    const { cost, state } = pq.shift()!;
    if (cost > (dist[key(state)] ?? Infinity)) continue;
    if (state.station === end) {
      if (cost < bestEndCost) {
        bestEndCost = cost;
        bestEndKey = key(state);
      }
      continue;
    }
    for (const nb of ADJ[state.station] ?? []) {
      for (const l of linesOfEdge(state.station, nb)) {
        const transferCost = l === state.line ? 0 : TRANSFER_MINUTES;
        const nCost = cost + transferCost + edgeTime(state.station, nb);
        const nState = { station: nb, line: l };
        if (nCost < (dist[key(nState)] ?? Infinity)) {
          dist[key(nState)] = nCost;
          prev[key(nState)] = { key: key(state) };
          pq.push({ cost: nCost, state: nState });
        }
      }
    }
  }
  if (!bestEndKey) return null;
  const stationsRev: string[] = [];
  const linesRev: string[] = [];
  let curKey: string | null = bestEndKey;
  while (curKey) {
    const [station, line] = curKey.split("|");
    stationsRev.push(station);
    linesRev.push(line);
    const p: { key: string } | null = prev[curKey] ?? null;
    curKey = p ? p.key : null;
  }
  const path = stationsRev.reverse();
  const lines = linesRev.reverse();
  let transfers = 0;
  for (let i = 1; i < lines.length; i++) if (lines[i] !== lines[i - 1]) transfers++;
  const dedup: string[] = [];
  for (const s of path) if (dedup[dedup.length - 1] !== s) dedup.push(s);
  return { path: dedup, transfers, time: bestEndCost };
}

/* Least-transfers route: Dijkstra on (station, line) with cost = transfers*1000 + stations. */
function leastTransfersPath(
  start: string,
  end: string,
): { path: string[]; transfers: number } | null {
  if (start === end) return { path: [start], transfers: 0 };
  type State = { station: string; line: string };
  const key = (s: State) => `${s.station}|${s.line}`;
  const dist: Record<string, number> = {};
  const prev: Record<string, { state: State; via: string } | null> = {};
  // Priority queue (small graph — array-based)
  const pq: Array<{ cost: number; state: State }> = [];
  // Seed from start with any line available
  const startLines = new Set<string>();
  for (const nb of ADJ[start] ?? []) for (const l of linesOfEdge(start, nb)) startLines.add(l);
  if (startLines.size === 0) startLines.add("L1");
  for (const l of startLines) {
    const st = { station: start, line: l };
    dist[key(st)] = 0;
    prev[key(st)] = null;
    pq.push({ cost: 0, state: st });
  }
  let bestEndKey: string | null = null;
  let bestEndCost = Infinity;
  while (pq.length) {
    pq.sort((a, b) => a.cost - b.cost);
    const { cost, state } = pq.shift()!;
    if (cost > (dist[key(state)] ?? Infinity)) continue;
    if (state.station === end && cost < bestEndCost) {
      bestEndCost = cost;
      bestEndKey = key(state);
      continue;
    }
    for (const nb of ADJ[state.station] ?? []) {
      for (const l of linesOfEdge(state.station, nb)) {
        const transferCost = l === state.line ? 0 : 1000;
        const nCost = cost + transferCost + 1;
        const nState = { station: nb, line: l };
        if (nCost < (dist[key(nState)] ?? Infinity)) {
          dist[key(nState)] = nCost;
          prev[key(nState)] = { state, via: state.station };
          pq.push({ cost: nCost, state: nState });
        }
      }
    }
  }
  if (!bestEndKey) return null;
  // Reconstruct
  const path: string[] = [];
  let curKey: string | null = bestEndKey;
  let lastLine: string | null = null;
  let transfers = 0;
  while (curKey) {
    const [station, line] = curKey.split("|");
    path.unshift(station);
    if (lastLine && lastLine !== line) transfers++;
    lastLine = line;
    const p = prev[curKey];
    if (!p) break;
    curKey = key(p.state);
  }
  // transfers count from path-line changes
  transfers = Math.floor(bestEndCost / 1000);
  // Dedupe consecutive duplicates
  const dedup: string[] = [];
  for (const s of path) if (dedup[dedup.length - 1] !== s) dedup.push(s);
  return { path: dedup, transfers };
}

/* Count transfers along a path by picking line per edge to minimize switches. */
function countTransfers(path: string[]): number {
  if (path.length < 2) return 0;
  // DP over edges: for each edge choose a line; cost = switches between consecutive edges.
  let prevOptions: Record<string, number> = {};
  const firstLines = linesOfEdge(path[0], path[1]);
  for (const l of firstLines) prevOptions[l] = 0;
  for (let i = 1; i < path.length - 1; i++) {
    const lines = linesOfEdge(path[i], path[i + 1]);
    const next: Record<string, number> = {};
    for (const l of lines) {
      let best = Infinity;
      for (const [pl, c] of Object.entries(prevOptions)) {
        const nc = c + (pl === l ? 0 : 1);
        if (nc < best) best = nc;
      }
      next[l] = best;
    }
    prevOptions = next;
  }
  return Math.min(...Object.values(prevOptions));
}

function getFare(boardZone: number, alightZone: number): number {
  return FARE_TABLE[boardZone - 1][alightZone - 1];
}

/* ───────── Arrival-time / passenger-load helpers ───────── */

type Service = {
  key: string;
  group: string;
  color: string;
  label: string;
  offsetMin: number;
  firstClassOnly?: boolean;
  freqOverride?: (m: number) => number;
};

function servicesAtStation(stationId: string, _nowMinutes: number): Service[] {
  const out: Service[] = [];
  for (const line of LINES) {
    if (line.express) continue;
    const group = lineGroup(line.id);
    const meta = LINE_META[group];
    if (!meta) continue;
    const isLoop = line.path[0] === line.path[line.path.length - 1];
    // Forward
    {
      const idx = line.path.indexOf(stationId);
      if (idx !== -1 && idx !== line.path.length - 1) {
        let off = 0;
        for (let i = 0; i < idx; i++) off += edgeTime(line.path[i], line.path[i + 1]);
        const dest = STATION_MAP[line.path[line.path.length - 1]];
        out.push({
          key: `${line.id}-F`,
          group,
          color: line.color,
          label: isLoop ? `${meta.n.split(" ")[0]} · 順時針 CW` : `${meta.n.split(" ")[0]} · 往 ${dest.zh} ${dest.en}`,
          offsetMin: off,
        });
      }
    }
    // Reverse
    {
      const rpath = [...line.path].reverse();
      const idx = rpath.indexOf(stationId);
      if (idx !== -1 && idx !== rpath.length - 1) {
        let off = 0;
        for (let i = 0; i < idx; i++) off += edgeTime(rpath[i], rpath[i + 1]);
        const dest = STATION_MAP[rpath[rpath.length - 1]];
        out.push({
          key: `${line.id}-R`,
          group,
          color: line.color,
          label: isLoop ? `${meta.n.split(" ")[0]} · 逆時針 ACW` : `${meta.n.split(" ")[0]} · 往 ${dest.zh} ${dest.en}`,
          offsetMin: off,
        });
      }
    }
  }
  // Airport Rapid (separate sub-system, runs only between UNS, SSC, MFC, AT1, AT2).
  if (AEX_STOPS.has(stationId)) {
    const meta = LINE_META.AEX;
    // Forward: toward AT2
    {
      const idx = AEX_PATH.indexOf(stationId);
      if (idx !== -1 && idx !== AEX_PATH.length - 1) {
        let off = 0;
        for (let i = 0; i < idx; i++) off += aexEdgeTime(AEX_PATH[i], AEX_PATH[i + 1]);
        const dest = STATION_MAP[AEX_PATH[AEX_PATH.length - 1]];
        out.push({
          key: "AEX-F",
          group: "AEX",
          color: meta.c,
          label: `機場特急 · 往 ${dest.zh} ${dest.en}`,
          offsetMin: off,
          firstClassOnly: true,
          freqOverride: aexFreq,
        });
      }
    }
    // Reverse: toward UNS
    {
      const rpath = [...AEX_PATH].reverse();
      const idx = rpath.indexOf(stationId);
      if (idx !== -1 && idx !== rpath.length - 1) {
        let off = 0;
        for (let i = 0; i < idx; i++) off += aexEdgeTime(rpath[i], rpath[i + 1]);
        const dest = STATION_MAP[rpath[rpath.length - 1]];
        out.push({
          key: "AEX-R",
          group: "AEX",
          color: meta.c,
          label: `機場特急 · 往 ${dest.zh} ${dest.en}`,
          offsetMin: off,
          firstClassOnly: true,
          freqOverride: aexFreq,
        });
      }
    }
  }
  return out;
}

function nextThreeArrivals(svc: Service, nowFrac: number): { depAbs: number; arrAbs: number }[] {
  const out: { depAbs: number; arrAbs: number }[] = [];
  let cursor = nowFrac - svc.offsetMin;
  for (let i = 0; i < 3; i++) {
    const ref = ((Math.floor(cursor) % 1440) + 1440) % 1440;
    const interval = svc.freqOverride
      ? svc.freqOverride(ref)
      : activeFreq(ref)[LINE_META[svc.group].idx];
    const dep = Math.ceil(cursor / interval) * interval;
    out.push({ depAbs: dep, arrAbs: dep + svc.offsetMin });
    cursor = dep + 1e-6;
  }
  return out;
}

function weightsAt(absMin: number): [number, number, number] {
  const h = (((Math.floor(absMin) % 1440) + 1440) % 1440) / 60;
  if (h < 5) return [0.9, 0.1, 0];
  if (h < 7) return [0.75, 0.2, 0.05];
  if (h < 9) return [0.3, 0.4, 0.3];
  if (h < 15) return [0.75, 0.2, 0.05];
  if (h < 17) return [0.4, 0.4, 0.2];
  if (h < 19) return [0.3, 0.4, 0.3];
  if (h < 21) return [0.6, 0.3, 0.1];
  return [0.75, 0.2, 0.05];
}

function hashStr(s: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function carriageColors(serviceKey: string, arrAbs: number): ("g" | "y" | "r")[] {
  const w = weightsAt(arrAbs);
  const rand = mulberry32(hashStr(`${serviceKey}@${Math.round(arrAbs * 1000)}`));
  const out: ("g" | "y" | "r")[] = [];
  for (let i = 0; i < 8; i++) {
    const r = rand();
    if (i < 2) {
      // First Class carriages: 85% Green, 15% Yellow, never Red.
      out.push(r < 0.85 ? "g" : "y");
    } else {
      if (r < w[0]) out.push("g");
      else if (r < w[0] + w[1]) out.push("y");
      else out.push("r");
    }
  }
  // Adjacency rule (standard carriages 3-8): every Red must be flanked by Yellow.
  for (let i = 2; i < 8; i++) {
    if (out[i] !== "r") continue;
    if (i === 7) {
      out[i] = "y";
      continue;
    }
    out[i - 1] = "y";
    out[i + 1] = "y";
  }
  return out;
}

type DelayInfo = {
  minutes: number;
  label: string;
  color: string;
  note?: string;
} | null;

function getDelay(serviceKey: string, arrAbs: number): DelayInfo {
  const rand = mulberry32(hashStr(`delay:${serviceKey}@${Math.round(arrAbs * 1000)}`))();
  // 0.08% → 5min "Delayed"
  if (rand < 0.0008) {
    return {
      minutes: 5,
      label: "Delayed 延誤",
      color: "#dc2626",
      note: "Sorry for the inconvenience caused. 造成不便，敬請原諒。",
    };
  }
  // 0.25% → 2min "Slow"
  if (rand < 0.0008 + 0.0025) {
    return { minutes: 2, label: "Slow 較慢", color: "#dc2626" };
  }
  // 1.25% → 1min "Slightly slow"
  if (rand < 0.0008 + 0.0025 + 0.0125) {
    return { minutes: 1, label: "Slightly slow 稍慢", color: "#ea580c" };
  }
  return null;
}

function getSurcharges(start: string | null, end: string | null) {
  const items: { label: string; amount: number }[] = [];
  if (!start || !end) return { items, total: 0 };
  const endpoints = [start, end];
  const hasAirport = endpoints.some((id) => id === "AT1" || id === "AT2");
  if (hasAirport)
    items.push({ label: "機場附加費 Airport Terminal", amount: 8 });
  const hasStarreyland = endpoints.some((id) => id === "SRL");
  if (hasStarreyland)
    items.push({ label: "星利樂園附加費 Starrleyland", amount: 8 });
  return {
    items,
    total: items.reduce((sum, item) => sum + item.amount, 0),
  };
}

function getFirstClassSurcharges(start: string | null, end: string | null) {
  const items: { label: string; amount: number }[] = [];
  if (!start || !end) return { items, total: 0 };
  const endpoints = [start, end];
  const airportCount = endpoints.filter((id) => id === "AT1" || id === "AT2").length;
  const starrCount = endpoints.filter((id) => id === "SRL").length;
  if (airportCount > 0)
    items.push({
      label: `機場頭等附加費 Airport First Class${airportCount > 1 ? ` ×${airportCount}` : ""}`,
      amount: 16 * airportCount,
    });
  if (starrCount > 0)
    items.push({
      label: `星利樂園頭等附加費 Starrleyland First Class`,
      amount: 16 * starrCount,
    });
  return {
    items,
    total: items.reduce((sum, item) => sum + item.amount, 0),
  };
}

const FIRST_CLASS_FARE: Record<number, number> = {
  18: 36, 20: 38, 22: 42, 24: 46, 26: 50, 28: 56, 30: 58, 32: 62,
  36: 68, 38: 72, 40: 76, 46: 88, 50: 96, 52: 100, 54: 102, 56: 106,
  60: 116, 64: 122, 68: 130, 70: 136, 72: 138, 76: 146, 80: 152,
};


/* ───────────── Component ───────────── */

function EntryScene({ onStart }: { onStart: () => void }) {
  return (
    <button
      type="button"
      onClick={onStart}
      aria-label="Enter SkyRail.Game 進入系統"
      className="fixed inset-0 z-[60] w-screen h-screen p-0 m-0 border-0 cursor-pointer bg-[#0a0f24] overflow-hidden"
    >
      <img
        src={startAsset.url}
        alt=""
        className="absolute inset-0 w-full h-full object-contain"
      />
      <div className="absolute bottom-10 left-0 right-0 flex justify-center pointer-events-none">
        <div className="text-xs md:text-sm font-semibold tracking-[0.35em] uppercase text-white/80 bg-black/40 px-4 py-2 rounded-full">
          Tap anywhere to start · 點擊任何位置開始
        </div>
      </div>
    </button>
  );
}


function CountdownBanner() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  // 2026-09-01 00:00 GMT+8  ==  2026-08-31 16:00 UTC
  const target = Date.UTC(2026, 7, 31, 16, 0, 0);
  const diff = now ? Math.max(0, target - now.getTime()) : 0;
  const s = Math.floor(diff / 1000);
  const days = Math.floor(s / 86400);
  const hours = Math.floor((s % 86400) / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;
  const launched = now !== null && diff === 0;
  const Cell = ({ v, l }: { v: number; l: string }) => (
    <div className="flex flex-col items-center px-1.5 py-1 rounded bg-white/10 min-w-[36px]">
      <span className="text-sm font-bold tabular-nums leading-none">
        {now === null ? "--" : String(v).padStart(2, "0")}
      </span>
      <span className="text-[8px] uppercase tracking-wider opacity-80 mt-0.5">{l}</span>
    </div>
  );
  return (
    <div className="bg-gradient-to-r from-emerald-700 to-teal-700 text-white px-3 py-1.5 flex items-center gap-3 flex-wrap">
      <div className="min-w-0">
        <div className="text-[9px] uppercase tracking-widest opacity-80 leading-tight">
          Coming Soon · 即將開通
        </div>
        <div className="text-xs font-bold leading-tight truncate">
          星利線二期 2026.09.01 開通
        </div>
        <div className="text-[10px] opacity-90 leading-tight truncate">
          Starrleyland Line Phase 2 · 2026.09.01
        </div>
      </div>
      {launched ? (
        <div className="text-sm font-bold ml-auto">已開通 Now Open!</div>
      ) : (
        <div className="flex gap-1 ml-auto">
          <Cell v={days} l="D" />
          <Cell v={hours} l="H" />
          <Cell v={mins} l="M" />
          <Cell v={secs} l="S" />
        </div>
      )}
    </div>
  );
}

function DailyTrivia() {
  const [revealed, setRevealed] = useState(false);
  // Day-of-year in GMT+8, cycles through 88 jokes across the year
  const now = new Date();
  const gmt8 = new Date(now.getTime() + 8 * 3600 * 1000);
  const start = Date.UTC(gmt8.getUTCFullYear(), 0, 0);
  const dayOfYear = Math.floor((gmt8.getTime() - start) / 86400000);
  const joke = JOKES[((dayOfYear - 1) % JOKES.length + JOKES.length) % JOKES.length];
  return (
    <div className="bg-amber-50 border-y border-amber-200 px-3 py-1.5 text-[#0a2540]">
      <div className="flex items-start gap-2 text-xs">
        <span className="shrink-0 uppercase tracking-widest text-[9px] font-bold text-amber-700 mt-0.5">
          Daily Trivia · 每日趣聞
        </span>
        <div className="min-w-0 flex-1">
          <div className="font-semibold leading-snug">Q: {joke.q}</div>
          {revealed ? (
            <div className="leading-snug mt-0.5 text-amber-900">A: {joke.a}</div>
          ) : (
            <button
              type="button"
              onClick={() => setRevealed(true)}
              className="text-[10px] mt-0.5 underline text-amber-700 hover:text-amber-900"
            >
              Reveal answer 顯示答案
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function Index() {
  const [entered, setEntered] = useState(false);
  const [start, setStart] = useState<string | null>(null);
  const [end, setEnd] = useState<string | null>(null);
  const [hover, setHover] = useState<string | null>(null);
  const [mode, setMode] = useState<"fastest" | "transfers">("fastest");
  const [view, setView] = useState<"fare" | "arrivals">("fare");
  const [activeStation, setActiveStation] = useState<string>(STATIONS[0].id);
  const { session } = useSession();
  const { profile, adCount, refresh, setProfile, isAdmin } = useProfile(session);
  const [showAuth, setShowAuth] = useState(false);
  const [showPurchase, setShowPurchase] = useState(false);
  const [showAd, setShowAd] = useState(false);
  const [ticket, setTicket] = useState<TicketInfo | null>(null);
  const [alert, setAlert] = useState<{ title: string; msg: string } | null>(null);
  const [pendingTravel, setPendingTravel] = useState<TravelData | null>(null);
  const [travel, setTravel] = useState<TravelData | null>(null);
  const [journeyResult, setJourneyResult] = useState<{
    earned: number;
    minutes: number;
    missCount: number;
    isDaily: boolean;
    dailyBonus: number;
    adUsed: boolean;
  } | null>(null);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showShop, setShowShop] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [showUnlock, setShowUnlock] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [showDaily, setShowDaily] = useState(false);
  const [showTokenWallet, setShowTokenWallet] = useState(false);
  const [showGift, setShowGift] = useState(false);

  const [showTripAd, setShowTripAd] = useState<{ amount: number } | null>(null);
  const [dailyDoneToday, setDailyDoneToday] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    try {
      return localStorage.getItem("sr_daily_done_" + dailyDateKeyGmt8()) === "1";
    } catch { return false; }
  });
  const [tripCount, setTripCount] = useState(0);
  const [ban, setBan] = useState<{ banned_until: string | null; permanent: boolean } | null>(null);
  const [showTutorial, setShowTutorial] = useState(false);
  const [musicMuted, setMusicMuted] = useState<boolean>(false);
  useEffect(() => {
    try {
      if (localStorage.getItem("sr_music_muted") === "1") setMusicMuted(true);
    } catch { /* ignore */ }
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem("sr_music_muted", musicMuted ? "1" : "0");
    } catch { /* ignore */ }
  }, [musicMuted]);



  useEffect(() => {
    try {
      if (typeof window !== "undefined" && !localStorage.getItem("sr_tutorial_done")) {
        setShowTutorial(true);
      }
    } catch { /* ignore */ }
  }, []);

  const unlocked = useMemo(
    () => (isAdmin
      ? LINE_UNLOCKS.map((l) => l.key)
      : (profile?.unlocked_lines ?? ["L1"])),
    [isAdmin, profile?.unlocked_lines],
  );
  const unlockedSet = useMemo(() => new Set(unlocked), [unlocked]);

  useEffect(() => {
    if (!session) return setTripCount(0);
    if (isAdmin) return setTripCount(0);
    void countMyTickets().then(setTripCount).catch(() => {});
  }, [session, isAdmin]);

  useEffect(() => {
    if (!session || isAdmin) {
      setBan(null);
      return;
    }
    void fetchMyBan().then((b) => {
      if (!b) return setBan(null);
      if (b.permanent) return setBan(b);
      if (b.banned_until && new Date(b.banned_until).getTime() > Date.now()) return setBan(b);
      setBan(null);
    });
  }, [session, isAdmin]);

  useEffect(() => {
    if (!pendingTravel) return;
    const p = pendingTravel;
    let cancelled = false;
    void (async () => {
      try {
        await startJourney(p.from.id, p.to.id, p.travelMinutes);
      } catch { /* proceed locally */ }
      if (cancelled) return;
      setTravel(p);
      setPendingTravel(null);
    })();
    return () => {
      cancelled = true;
    };
  }, [pendingTravel]);

  function handleClick(id: string) {
    if (view === "arrivals") {
      setActiveStation(id);
      return;
    }
    // Line 2 extension stations are locked until 2026-09-01 00:00 GMT+8
    if (L2_EXTENSION_STATIONS.has(id) && Date.now() < L2_EXTENSION_UNLOCK_MS) {
      setAlert({
        title: "尚未通車 · Not yet open",
        msg: "2號線延伸段 (順利 · 星鎮 · 星榕 · 星欣 · 站得) 將於 2026-09-01 通車。\nLine 2 extension opens on 2026-09-01 00:00 GMT+8.",
      });
      return;
    }
    if (start === null) {
      setStart(id);
      return;
    }
    if (end === null) {
      setEnd(id);
      return;
    }
    // both set — start new selection
    setStart(id);
    setEnd(null);
  }

  function reset() {
    setStart(null);
    setEnd(null);
  }

  const routes = useMemo(() => {
    if (!start || !end) return null;
    if (start === end) return null;
    const ids = new Set([start, end]);
    if (ids.has("AT1") && ids.has("AT2")) return null;
    const fRes = fastestPath(start, end);
    const tRes = leastTransfersPath(start, end);
    if (!fRes || !tRes) return { ok: false as const };
    const tTime = pathTravelTime(tRes.path) + tRes.transfers * TRANSFER_MINUTES;
    const adult = getFare(STATION_MAP[start].zone, STATION_MAP[end].zone);
    return {
      fastest: fRes,
      transfers: { path: tRes.path, transfers: tRes.transfers, time: tTime },
      adult,
      ok: true as const,
    };

  }, [start, end]);

  const active =
    routes && routes.ok ? (mode === "fastest" ? routes.fastest : routes.transfers) : null;

  const pathSet = useMemo(() => new Set(active?.path ?? []), [active]);

  // Choose a line-per-edge sequence for the active path, minimising switches while
  // preferring unlocked lines when possible.
  const activeLineSeq = useMemo(() => {
    if (!active) return [] as string[];
    const path = active.path;
    if (path.length < 2) return [];
    const seq: string[] = [];
    let prev: string | null = null;
    for (let i = 0; i < path.length - 1; i++) {
      const options = linesOfEdge(path[i], path[i + 1]);
      const unlockedOpts = options.filter((l) => unlockedSet.has(l));
      const pool = unlockedOpts.length > 0 ? unlockedOpts : options;
      // Prefer keeping current line
      const pick: string = prev && pool.includes(prev) ? prev : (pool[0] ?? options[0]);
      seq.push(pick);
      prev = pick;
    }
    return seq;
  }, [active, unlockedSet]);

  const lockedLinesInRoute = useMemo(() => {
    const s = new Set<string>();
    if (!active) return s;
    for (let i = 0; i < active.path.length - 1; i++) {
      const opts = linesOfEdge(active.path[i], active.path[i + 1]);
      if (!opts.some((l) => unlockedSet.has(l))) {
        opts.forEach((l) => s.add(l));
      }
    }
    return s;
  }, [active, unlockedSet]);
  const routeLocked = lockedLinesInRoute.size > 0;

  const surcharge = useMemo(() => getSurcharges(start, end), [start, end]);
  const firstClassSurcharge = useMemo(
    () => getFirstClassSurcharges(start, end),
    [start, end],
  );

  const error: { title: string; message: string } | null = useMemo(() => {
    if (!start || !end) return null;
    if (start === end) {
      return {
        title: "同站錯誤 Same Station",
        message: "起點與終點不能相同。Start and end stations cannot be the same.",
      };
    }
    const ids = new Set([start, end]);
    if (ids.has("AT1") && ids.has("AT2")) {
      return {
        title: "禁止行程 Restricted Journey",
        message:
          "兩個機場客運大樓之間無法乘坐列車前往。Train travel between Airport Terminal 1 and Terminal 2 is not available.",
      };
    }
    return null;
  }, [start, end]);


  function stationFill(id: string) {
    if (L2_EXTENSION_STATIONS.has(id) && Date.now() < L2_EXTENSION_UNLOCK_MS) {
      return "#cbd5e1";
    }
    if (view === "arrivals") {
      if (id === activeStation) return "#f59e0b";
      return "#0f172a";
    }
    if (id === start) return "#22c55e";
    if (id === end) return "#ef4444";
    if (pathSet.has(id)) return "#f59e0b";
    return "#0f172a";
  }


  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <PaymentTestModeBanner />
      {!entered && <EntryScene onStart={() => setEntered(true)} />}

      {error && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-lg shadow-xl max-w-sm w-full p-5">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-full bg-red-100 text-red-600 flex items-center justify-center font-bold">
                !
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-bold text-slate-900">{error.title}</h2>
                <p className="text-sm text-slate-600 mt-1">{error.message}</p>
              </div>
            </div>
            <button
              onClick={reset}
              className="mt-4 w-full rounded-md bg-slate-900 text-white py-2 text-sm font-medium hover:bg-slate-700 transition"
            >
              知道了 OK
            </button>
          </div>
        </div>
      )}
      <header className="relative bg-[#0a0f24] text-white px-6 py-4 border-b border-cyan-500/20">
        <div className="relative">
          <h1
            className="text-2xl md:text-4xl font-extrabold tracking-wide"
            style={{ fontFamily: "'Press Start 2P', monospace", color: "#f0f9ff" }}
          >
            SkyRail<span style={{ color: "#f472b6" }}>.</span>Game
          </h1>
          <p className="text-xs md:text-sm opacity-70 mt-2">
            點選起點站，再點選終點站。 · Click a start station, then an end station.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
            {session ? (
              <>
                <div className="inline-flex items-center gap-1 bg-white/10 rounded px-2 py-1 border border-white/10">
                  <span className="opacity-80">結餘 Balance</span>
                  <StarrIcon size={14} />
                  <span className="font-bold tabular-nums">
                    {isAdmin ? "10,000" : (profile?.balance ?? "—")}
                  </span>
                  <span className="opacity-70">Starrs</span>
                  {isAdmin && (
                    <span className="ml-1 text-[10px] bg-amber-400 text-amber-950 rounded px-1 font-bold">
                      ADMIN ∞
                    </span>
                  )}
                </div>
                <DailyLogin
                  session={session}
                  isAdmin={isAdmin}
                  onClaimed={(bal) => {
                    setProfile((p) => (p ? { ...p, balance: bal } : p));
                    void refresh();
                  }}
                />
                <button
                  onClick={() => {
                    if (adCount >= 3) {
                      setAlert({
                        title: "每日上限 Daily limit",
                        msg: "您今日已觀看 3 段廣告。You have already watched 3 ads today.",
                      });
                      return;
                    }
                    setShowAd(true);
                  }}
                  className="rounded bg-emerald-500 hover:bg-emerald-600 px-2 py-1 font-semibold"
                >
                  ▶ 看廣告賺 Starrs · Watch ad ({adCount}/3)
                </button>
                <button
                  onClick={() => setShowTokenWallet(true)}
                  className="rounded bg-white/10 hover:bg-white/20 px-2 py-1 font-semibold"
                  title="Token Wallet"
                >
                  🎫 代幣 Tokens ({profile?.skin_tokens ?? 0})
                </button>
                <button
                  onClick={() => setShowGift(true)}
                  className="rounded bg-fuchsia-500/90 hover:bg-fuchsia-500 text-white px-2 py-1 font-semibold"
                  title="Send Gift · 送禮"
                >
                  🎁 送禮 Gift
                </button>
                <button
                  onClick={() => setShowLeaderboard(true)}
                  className="rounded bg-white/10 hover:bg-white/20 px-2 py-1 font-semibold"
                >
                  🏆 排行榜 Leaderboards
                </button>

                <button
                  onClick={() => setShowUnlock(true)}
                  className="rounded bg-white/10 hover:bg-white/20 px-2 py-1 font-semibold"
                >
                  🗺️ 解鎖 Unlock ({unlocked.length}/{LINE_UNLOCKS.length})
                </button>
                <button
                  onClick={() => setShowTutorial(true)}
                  className="rounded bg-white/10 hover:bg-white/20 px-2 py-1 font-semibold"
                  title="How to Play"
                >
                  ❓ 教學 How to Play
                </button>
                {isAdmin && (
                  <button
                    onClick={() => setShowAdmin(true)}
                    className="rounded bg-fuchsia-600 hover:bg-fuchsia-500 px-2 py-1 font-bold border border-fuchsia-300/50 shadow-[0_0_10px_rgba(217,70,239,0.6)]"
                  >
                    ⚙ ADMIN 管理員面板
                  </button>
                )}
                <button
                  onClick={async () => {
                    await supabase.auth.signOut();
                    setProfile(null);
                  }}
                  className="rounded bg-rose-500/90 hover:bg-rose-500 text-white px-3 py-1 font-bold shadow"
                >
                  🚪 登出 Sign out
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setShowTutorial(true)}
                  className="rounded bg-white/10 hover:bg-white/20 px-3 py-1.5 font-semibold"
                >
                  ❓ How to Play
                </button>
                <button
                  onClick={() => setShowAuth(true)}
                  className="relative rounded-lg bg-gradient-to-r from-emerald-400 via-cyan-400 to-emerald-400 hover:brightness-110 text-slate-900 px-5 py-2 text-base font-black shadow-[0_0_18px_rgba(34,211,238,0.55)] animate-pulse"
                >
                  ▶ 登入 · 開始旅程 Sign In & Play
                </button>
              </>
            )}
          </div>
        </div>
      </header>
      <WeekendEvent />
      <CountdownBanner />
      <DailyTrivia />

      <div className="grid lg:grid-cols-[1fr_360px] gap-4 p-4">
        {/* Map */}
        <div className="relative bg-white rounded-lg shadow overflow-auto">
          {session && !ban && (
            <button
              type="button"
              onClick={() => setShowShop(true)}
              aria-label="Open Shop"
              title="Shop · 商店"
              className="absolute top-3 left-3 z-20 w-16 h-16 md:w-20 md:h-20 rounded-full bg-gradient-to-br from-amber-400 via-orange-500 to-rose-500 text-white shadow-[0_6px_20px_rgba(251,191,36,0.55)] border-4 border-white flex flex-col items-center justify-center font-black hover:brightness-110 transition"
            >
              <span className="text-2xl md:text-3xl leading-none">🛒</span>
              <span className="text-[9px] md:text-[10px] leading-tight mt-0.5">shop 商店</span>
            </button>
          )}
          <svg viewBox="-120 -10 2100 1200" className="w-full h-auto min-w-[900px]">

            {/* Line segments */}
            {LINES.map((line) => {
              const pts = line.draw ?? line.path;
              const grp = lineGroup(line.id);
              const isLocked = !unlockedSet.has(grp);
              const strokeColor = isLocked ? "#94a3b8" : line.color;
              const strokeOpacity = isLocked ? 0.35 : 0.95;
              return (
                <g key={line.id}>
                  <path
                    d={pathToSvg(pts)}
                    stroke={strokeColor}
                    strokeWidth={12}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    fill="none"
                    opacity={strokeOpacity}
                  />
                  {line.dashDraw && (
                    <path
                      d={pathToSvg(line.dashDraw)}
                      stroke={strokeColor}
                      strokeWidth={12}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeDasharray="4 16"
                      fill="none"
                      opacity={strokeOpacity}
                    />
                  )}
                </g>
              );
            })}
            {/* Station labels */}
            {STATIONS.map((s) => {
              const lp = s.lp ?? "top";
              let dx = 0, dy = 0, anchor: "start" | "middle" | "end" = "middle";
              if (lp === "top") { dy = -36; anchor = "middle"; }
              else if (lp === "bottom") { dy = 46; anchor = "middle"; }
              else if (lp === "left") { dx = -28; dy = 6; anchor = "end"; }
              else { dx = 28; dy = 6; anchor = "start"; }
              const haloProps = {
                stroke: "white",
                strokeWidth: 6,
                strokeLinejoin: "round" as const,
                paintOrder: "stroke" as const,
              };
              return (
                <g key={`lbl-${s.id}`} pointerEvents="none">
                  <text x={s.x + dx} y={s.y + dy} fontSize={20} fontWeight={700} fill="#0f172a" textAnchor={anchor} {...haloProps}>
                    {s.zh}
                  </text>
                  <text x={s.x + dx} y={s.y + dy + (lp === "top" ? -22 : 22)} fontSize={14} fontWeight={600} fill="#334155" textAnchor={anchor} {...haloProps}>
                    {s.en}
                  </text>
                </g>
              );
            })}
            {STATIONS.map((s) => {
              const isSel =
                view === "arrivals"
                  ? s.id === activeStation
                  : s.id === start || s.id === end;
              const onPath = pathSet.has(s.id);
              return (
                <g
                  key={s.id}
                  onClick={() => handleClick(s.id)}
                  onMouseEnter={() => setHover(s.id)}
                  onMouseLeave={() => setHover(null)}
                  style={{ cursor: "pointer" }}
                >
                  {/* Big invisible hit target */}
                  <circle cx={s.x} cy={s.y} r={26} fill="transparent" />
                  <circle
                    cx={s.x}
                    cy={s.y}
                    r={isSel ? 17 : onPath ? 14 : 11}
                    fill={stationFill(s.id)}
                    stroke="white"
                    strokeWidth={isSel ? 5 : 3}
                  />
                </g>
              );
            })}
            {/* Airport Rapid dedicated station icons (parallel line at y=675) */}
            {AEX_PATH.map((sid) => {
              const s = STATION_MAP[sid];
              const isSel =
                view === "arrivals"
                  ? sid === activeStation
                  : sid === start || sid === end;
              return (
                <g
                  key={`aex-${sid}`}
                  onClick={() => handleClick(sid)}
                  onMouseEnter={() => setHover(sid)}
                  onMouseLeave={() => setHover(null)}
                  style={{ cursor: "pointer" }}
                >
                  <circle cx={s.x} cy={675} r={26} fill="transparent" />
                  <circle
                    cx={s.x}
                    cy={675}
                    r={isSel ? 20 : 17}
                    fill="#5eead4"
                    stroke="#0d9488"
                    strokeWidth={4}
                  />
                </g>
              );
            })}
            {hover &&
              (() => {
                const s = STATION_MAP[hover];
                return (
                  <g pointerEvents="none">
                    <rect x={s.x + 14} y={s.y - 44} width={150} height={38} fill="#0a2540" rx={4} />
                    <text x={s.x + 22} y={s.y - 28} fontSize={13} fill="white" fontWeight={700}>
                      {s.zh} ({s.id})
                    </text>
                    <text x={s.x + 22} y={s.y - 13} fontSize={11} fill="#cbd5e1">
                      Zone 收費區 {s.zone}
                    </text>
                  </g>
                );
              })()}
          </svg>
        </div>

        {/* Panel */}
        <aside className="bg-white rounded-lg shadow p-4 space-y-4 h-fit sticky top-4">
          <button
            onClick={() => setView((v) => (v === "fare" ? "arrivals" : "fare"))}
            className={`w-full rounded-md py-2 text-sm font-semibold transition ${
              view === "arrivals"
                ? "bg-amber-500 text-white hover:bg-amber-600"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            {view === "arrivals" ? "← 返回車費 Back to Fare" : "到站時間 Arrival times"}
          </button>

          {session && !ban && (
            <button
              onClick={() => setShowDaily(true)}
              className={`w-full relative overflow-hidden rounded-xl p-4 text-left text-white shadow-lg border-2 transition ${
                dailyDoneToday
                  ? "bg-gradient-to-br from-emerald-600 to-teal-700 border-emerald-300/60"
                  : "bg-gradient-to-br from-fuchsia-600 via-purple-700 to-indigo-700 border-fuchsia-300/60 hover:brightness-110"
              }`}
            >
              {!dailyDoneToday && (
                <span className="absolute top-2 right-2 bg-amber-300 text-amber-950 text-[9px] font-black tracking-widest px-2 py-0.5 rounded-full uppercase animate-pulse">
                  NEW · 新
                </span>
              )}
              <div className="flex items-start gap-3">
                <div className="text-4xl leading-none">🌟</div>
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] uppercase tracking-widest opacity-90 font-black">
                    Daily Challenge
                  </div>
                  <div className="text-lg font-black leading-tight">
                    每日挑戰 {dailyDoneToday ? "· ✓ 完成" : ""}
                  </div>
                  <div className="text-[11px] opacity-90 mt-1 leading-snug">
                    {dailyDoneToday
                      ? "Replay for another shot at +100 bonus."
                      : "1.5× Starrs · Locked routes FREE · +100 for 0 misses."}
                  </div>
                </div>
              </div>
            </button>
          )}



          {view === "arrivals" ? (
            <ArrivalTimes
              stationId={activeStation}
              onStationChange={setActiveStation}
            />
          ) : (
          <>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-wider text-slate-500">起點 Start</span>
              <span className="w-3 h-3 rounded-full bg-green-500" />
            </div>
            <div className="text-xl font-semibold min-h-[28px]">
              {start ? (
                <>
                  {STATION_MAP[start].zh}{" "}
                  <span className="text-base text-slate-500">{STATION_MAP[start].en}</span>
                </>
              ) : (
                <span className="text-slate-400 text-base">未選擇 Not selected</span>
              )}
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-wider text-slate-500">終點 End</span>
              <span className="w-3 h-3 rounded-full bg-red-500" />
            </div>
            <div className="text-xl font-semibold min-h-[28px]">
              {end ? (
                <>
                  {STATION_MAP[end].zh}{" "}
                  <span className="text-base text-slate-500">{STATION_MAP[end].en}</span>
                </>
              ) : (
                <span className="text-slate-400 text-base">未選擇 Not selected</span>
              )}
            </div>
          </div>

          <button
            onClick={reset}
            className="w-full rounded-md bg-slate-900 text-white py-2 text-sm font-medium hover:bg-slate-700 transition"
          >
            清除 Clear
          </button>

          {routes && (
            <div className="border-t pt-4 space-y-3">
              {!routes.ok && (
                <div className="text-red-600 text-sm font-medium">
                  未能找到路線。No route found.
                </div>
              )}
              {routes.ok && active && (
                <>
                  <div className="grid grid-cols-2 gap-1 rounded-md bg-slate-100 p-1 text-xs font-medium">
                    <button
                      onClick={() => setMode("fastest")}
                      className={`py-2 rounded ${mode === "fastest" ? "bg-white shadow text-slate-900" : "text-slate-500"}`}
                    >
                      最快
                      <br />
                      <span className="text-[10px] opacity-70">Fastest</span>
                    </button>
                    <button
                      onClick={() => setMode("transfers")}
                      className={`py-2 rounded ${mode === "transfers" ? "bg-white shadow text-slate-900" : "text-slate-500"}`}
                    >
                      最少轉乘
                      <br />
                      <span className="text-[10px] opacity-70">Least transfers</span>
                    </button>
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-slate-500">
                      行車時間 Travel time
                    </div>
                    <div className="text-2xl font-bold">
                      {active.time} <span className="text-base font-normal">分鐘 min</span>{" "}
                      <span className="text-sm font-normal text-slate-500">
                        · {active.path.length} 站 · 轉乘 {active.transfers} 次
                      </span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-md bg-[#0a2540] text-white p-3">
                      <div className="text-[10px] uppercase opacity-70">成人 Adult</div>
                      <div className="text-2xl font-bold"><Price amount={routes.adult + surcharge.total} size={18} /></div>
                      {surcharge.total > 0 && (
                        <div className="text-[10px] opacity-80">含附加費 incl. surcharge</div>
                      )}
                    </div>
                    <div className="rounded-md bg-amber-500 text-white p-3">
                      <div className="text-[10px] uppercase opacity-90">優惠 Concession</div>
                      <div className="text-2xl font-bold"><Price amount={Math.ceil((routes.adult + surcharge.total) / 2)} size={18} /></div>
                      {surcharge.total > 0 && (
                        <div className="text-[10px] opacity-90">含附加費 incl. surcharge</div>
                      )}
                    </div>
                  </div>
                  {(() => {
                    const fcBase = FIRST_CLASS_FARE[routes.adult] ?? routes.adult * 2;
                    const fcTotal = fcBase + firstClassSurcharge.total;
                    return (
                      <div className="rounded-md bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-200 text-amber-950 p-3 border border-amber-400 shadow-sm">
                        <div className="flex items-center gap-2">
                          <span className="inline-flex items-center justify-center w-5 h-5 rounded-sm bg-amber-900 text-white text-[11px] font-extrabold">
                            1
                          </span>
                          <div className="text-[10px] uppercase tracking-wider font-bold">
                            頭等車廂 First Class
                          </div>
                        </div>
                        <div className="text-2xl font-bold mt-1"><Price amount={fcTotal} size={18} /></div>
                        <div className="text-[10px] opacity-80">
                          基礎 Base <Price amount={fcBase} size={11} />
                          {firstClassSurcharge.total > 0 && (
                            <> · 附加費 +<Price amount={firstClassSurcharge.total} size={11} /></>
                          )}
                        </div>
                      </div>
                    );
                  })()}
                  {(() => {
                    const aex = aexFare(start, end);
                    if (aex === null) return null;
                    return (
                      <div
                        className="rounded-md p-3 border shadow-sm text-slate-900"
                        style={{
                          background:
                            "linear-gradient(90deg,#ccfbf1,#a7f3d0,#ccfbf1)",
                          borderColor: "#5eead4",
                        }}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="inline-block w-3 h-3 rounded-full"
                            style={{ background: "#14b8a6" }}
                          />
                          <div className="text-[10px] uppercase tracking-wider font-bold">
                            機場特急 Airport Rapid · 全頭等 All First Class
                          </div>
                        </div>
                        <div className="text-2xl font-bold mt-1"><Price amount={aex} size={18} /></div>
                        <div className="text-[10px] opacity-80">
                          固定票價 Flat fare · 獨立系統 separate service
                        </div>
                      </div>
                    );
                  })()}
                  {surcharge.total > 0 && (
                    <div className="rounded-md border border-slate-200 bg-slate-50 p-3">
                      <div className="text-xs uppercase tracking-wider text-slate-500 mb-2">
                        標準車廂附加費 Standard Surcharges
                      </div>
                      <ul className="space-y-1 text-sm">
                        {surcharge.items.map((item) => (
                          <li key={item.label} className="flex justify-between">
                            <span>{item.label}</span>
                            <span className="font-semibold">+<Price amount={item.amount} size={12} /></span>
                          </li>
                        ))}
                      </ul>
                      <div className="flex justify-between text-sm font-bold border-t border-slate-200 pt-2 mt-2">
                        <span>合計 Total</span>
                        <span>+<Price amount={surcharge.total} size={12} /></span>
                      </div>
                    </div>
                  )}
                  {firstClassSurcharge.total > 0 && (
                    <div className="rounded-md border border-amber-300 bg-amber-50 p-3">
                      <div className="text-xs uppercase tracking-wider text-amber-800 mb-2">
                        頭等車廂附加費 First Class Surcharges
                      </div>
                      <ul className="space-y-1 text-sm">
                        {firstClassSurcharge.items.map((item) => (
                          <li key={item.label} className="flex justify-between">
                            <span>{item.label}</span>
                            <span className="font-semibold">+<Price amount={item.amount} size={12} /></span>
                          </li>
                        ))}
                      </ul>
                      <div className="flex justify-between text-sm font-bold border-t border-amber-200 pt-2 mt-2">
                        <span>合計 Total</span>
                        <span>+<Price amount={firstClassSurcharge.total} size={12} /></span>
                      </div>
                    </div>
                  )}
                  {routes.ok && routeLocked && (
                    <div className="rounded-md border border-amber-400 bg-amber-50 p-3 text-xs text-amber-900">
                      <div className="font-bold uppercase tracking-widest text-[10px] mb-1">
                        🔒 路線鎖定 · Route Locked
                      </div>
                      此路線經過未解鎖之線路：
                      This route uses locked lines:{" "}
                      <b>{Array.from(lockedLinesInRoute).join(", ")}</b>
                      <button
                        onClick={() => setShowUnlock(true)}
                        className="mt-2 block w-full rounded bg-amber-500 hover:bg-amber-600 text-white py-1.5 font-bold"
                      >
                        前往解鎖 · Go to Unlock
                      </button>
                    </div>
                  )}
                  {routes.ok && !routeLocked && (
                    <button
                      onClick={() => {
                        if (!session) {
                          setShowAuth(true);
                          return;
                        }
                        setShowPurchase(true);
                      }}
                      className="w-full rounded-md bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 text-sm font-extrabold flex items-center justify-center gap-2 shadow"
                    >
                      <span>🛒</span>
                      <span>BUY TICKET 購票</span>
                    </button>
                  )}


                  <div>
                    <div className="text-xs uppercase tracking-wider text-slate-500 mb-1">
                      路線 Route
                    </div>
                    <ol className="text-base space-y-1 max-h-64 overflow-y-auto pr-2">
                      {active.path.map((id, i) => {
                        const s = STATION_MAP[id];
                        return (
                          <li key={id} className="flex gap-2">
                            <span className="text-slate-400 w-6 text-right">{i + 1}.</span>
                            <span>
                              <span className="font-medium">{s.zh}</span>{" "}
                              <span className="text-slate-500 text-sm">{s.en}</span>{" "}
                              <span className="text-xs text-slate-400">Z{s.zone}</span>
                            </span>
                          </li>
                        );
                      })}
                    </ol>
                  </div>
                </>
              )}
            </div>
          )}
          <div className="border-t pt-3">
            <div className="text-xs uppercase tracking-wider text-slate-500 mb-2">線路 Lines</div>
            <ul className="space-y-1 text-xs">
              {Object.values(LINE_META).map((l) => (
                <li key={l.n} className="flex items-center gap-2">
                  <span className="inline-block w-6 h-1.5 rounded" style={{ background: l.c }} />
                  {l.n}
                </li>
              ))}
            </ul>
          </div>
          </>
          )}
        </aside>
      </div>

      <footer className="text-center text-xs text-slate-500 py-4 space-y-1">
        <div>祝您旅途愉快 · We wish you a pleasant journey.</div>
        <div className="flex flex-wrap justify-center gap-3 text-slate-500">
          <button
            onClick={() => setShowInfo(true)}
            className="hover:text-slate-900 underline underline-offset-2"
          >
            ℹ️ Credits · Privacy · Terms · Refund
          </button>
        </div>
        <div className="text-[10px] text-slate-400">
          © {new Date().getFullYear()} VStarr Game Productions
        </div>
        {isAdmin && (
          <div>
            <button
              onClick={() => setShowAdmin(true)}
              className="text-slate-400 hover:text-slate-900 underline underline-offset-2"
            >
              Admin · 管理員面板
            </button>
          </div>
        )}
      </footer>
      <MusicPlayer inGame={!!travel} muted={musicMuted} />
      <button
        type="button"
        onClick={() => setMusicMuted((m) => !m)}
        aria-label={musicMuted ? "Unmute music" : "Mute music"}
        title={musicMuted ? "音樂關 · Music off" : "音樂開 · Music on"}
        className="fixed bottom-3 right-3 z-[70] w-11 h-11 rounded-full bg-white/90 hover:bg-white shadow-lg border border-slate-200 text-lg flex items-center justify-center"
      >
        {musicMuted ? "🔇" : "🎵"}
      </button>
      {showAuth && <AuthDialog onClose={() => setShowAuth(false)} />}
      {showTutorial && <Tutorial onClose={() => setShowTutorial(false)} />}

      {showPurchase && routes && routes.ok && start && end && (() => {
        const stdFare = routes.adult + surcharge.total;
        const fcBase = FIRST_CLASS_FARE[routes.adult] ?? routes.adult * 2;
        const fcFare = fcBase + firstClassSurcharge.total;
        const aex = aexFare(start, end);
        const options: FareOption[] = [
          { key: "std", labelZh: "標準車廂", label: "Standard Class", amount: stdFare },
          { key: "fc", labelZh: "頭等車廂", label: "First Class", amount: fcFare },
        ];
        if (aex !== null) {
          options.push({
            key: "aex",
            labelZh: "機場特急 (全頭等)",
            label: "Airport Rapid (All First)",
            amount: aex,
          });
        }
        const fromS = STATION_MAP[start];
        const toS = STATION_MAP[end];
        return (
          <PurchaseModal
            from={fromS}
            to={toS}
            options={options}
            balance={profile?.balance ?? 0}
            onCancel={() => setShowPurchase(false)}
            onConfirm={async (opt) => {
              try {
                const seat = generateSeat();
                const res = await purchaseTicket({
                  from: fromS.id,
                  to: toS.id,
                  seatClass: opt.label,
                  fare: opt.amount,
                  seat,
                });
                setProfile((p) => (p ? { ...p, balance: res.new_balance } : p));
                setShowPurchase(false);
                setTicket({
                  from: { id: fromS.id, en: fromS.en, zh: fromS.zh },
                  to: { id: toS.id, en: toS.en, zh: toS.zh },
                  seat,
                  seatClass: opt.label,
                  seatClassZh: opt.labelZh,
                  fare: opt.amount,
                  dateTime: fmtGmt8(new Date()),
                });
              } catch (e) {
                const msg = (e as Error).message;
                if (msg.includes("insufficient_starrs")) {
                  setAlert({
                    title: "星幣不足 Insufficient Starrs",
                    msg: "餘額不足以購買此車票。Your balance is not enough for this ticket.",
                  });
                } else {
                  setAlert({ title: "錯誤 Error", msg });
                }
                setShowPurchase(false);
              }
            }}
          />
        );
      })()}
      {ticket && (
        <TicketDisplay
          ticket={ticket}
          onClose={() => setTicket(null)}
          onStartJourney={() => {
            if (!routes || !routes.ok || !start || !end) return;
            const path = active?.path ?? [start, end];
            // Build stops with cumulative time, using activeLineSeq
            const stops: StationStop[] = [];
            let cum = 0;
            let prevLine: string | null = null;
            for (let i = 0; i < path.length; i++) {
              const st = STATION_MAP[path[i]];
              let lineFromPrev: string | null = null;
              let transferHere = false;
              if (i > 0) {
                lineFromPrev = activeLineSeq[i - 1] ?? null;
                cum += edgeTime(path[i - 1], path[i]);
                if (prevLine && lineFromPrev && prevLine !== lineFromPrev) {
                  transferHere = true;
                }
                prevLine = lineFromPrev;
              }
              stops.push({
                id: st.id,
                en: st.en,
                zh: st.zh,
                arriveAt: cum,
                lineFromPrev,
                transferHere,
              });
            }
            setPendingTravel({
              from: { id: start, en: STATION_MAP[start].en, zh: STATION_MAP[start].zh },
              to: { id: end, en: STATION_MAP[end].en, zh: STATION_MAP[end].zh },
              travelMinutes: active?.time ?? routes.fastest.time,
              seatClass: ticket.seatClass,
              seatClassZh: ticket.seatClassZh,
              isFirst:
                ticket.seatClass.toLowerCase().includes("first") ||
                ticket.seatClass.toLowerCase().includes("airport rapid"),
              stops,
              lineSequence: activeLineSeq,
            });
            setTicket(null);
          }}
        />
      )}
      {/* pendingTravel handled by effect below */}
      {travel && (
        <TravelView
          data={travel}
          onFinished={(earned, newBal, meta) => {
            const isDaily = !!meta.isDaily;
            const dailyBonus = isDaily && meta.missCount === 0 ? 100 : 0;
            setJourneyResult({
              earned,
              minutes: travel.travelMinutes,
              missCount: meta.missCount,
              isDaily,
              dailyBonus,
              adUsed: false,
            });
            if (newBal != null && !isAdmin) {
              setProfile((pp) => (pp ? { ...pp, balance: newBal } : pp));
            }
            // Apply +100 no-miss daily bonus server-side.
            if (dailyBonus > 0 && !isAdmin) {
              void applyTripAdBonus(dailyBonus)
                .then((bal) =>
                  setProfile((pp) => (pp ? { ...pp, balance: bal } : pp)),
                )
                .catch(() => {});
            }
            if (isDaily) {
              try {
                localStorage.setItem(
                  "sr_daily_done_" + dailyDateKeyGmt8(),
                  "1",
                );
              } catch { /* ignore */ }
              setDailyDoneToday(true);
            }
            void refresh();
            // Refresh trip count + auto unlock any newly-earned lines
            void countMyTickets().then(setTripCount).catch(() => {});
            void autoUnlockLines()
              .then((lines) => {
                setProfile((pp) => (pp ? { ...pp, unlocked_lines: lines } : pp));
              })
              .catch(() => {});
            setTravel(null);
          }}
        />
      )}
      {journeyResult && (
        <JourneyCompleteModal
          earned={journeyResult.earned}
          travelMinutes={journeyResult.minutes}
          missCount={journeyResult.missCount}
          isDaily={journeyResult.isDaily}
          dailyBonus={journeyResult.dailyBonus}
          adUsed={journeyResult.adUsed}
          onWatchDoubleAd={
            journeyResult.adUsed || journeyResult.earned <= 0
              ? undefined
              : () => setShowTripAd({ amount: journeyResult.earned })
          }
          onClose={() => setJourneyResult(null)}
        />
      )}
      {showAdmin && isAdmin && <AdminPanel onClose={() => setShowAdmin(false)} />}
      {showShop && (
        <StarrShop
          onClose={() => setShowShop(false)}
          profile={profile}
          onProfileUpdate={(patch) => {
            setProfile((p) => (p ? { ...p, ...patch } : p));
            void refresh();
          }}
        />
      )}
      {showTokenWallet && (
        <TokenWalletDialog
          onClose={() => setShowTokenWallet(false)}
          profile={profile}
          onProfileUpdate={(patch) => {
            setProfile((p) => (p ? { ...p, ...patch } : p));
            void refresh();
          }}
        />
      )}
      {showGift && (
        <SendGiftDialog
          onClose={() => setShowGift(false)}
          profile={profile}
          isAdmin={isAdmin}
          onProfileUpdate={(patch) => {
            setProfile((p) => (p ? { ...p, ...patch } : p));
            void refresh();
          }}
        />
      )}
      <GiftInbox
        session={session}
        onProfileUpdate={(patch) => {
          setProfile((p) => (p ? { ...p, ...patch } : p));
          void refresh();
        }}
      />

      {showLeaderboard && <Leaderboard onClose={() => setShowLeaderboard(false)} />}
      {showUnlock && (
        <RouteUnlockPanel
          unlocked={unlocked}
          tripCount={tripCount}
          balance={profile?.balance ?? 0}
          onClose={() => setShowUnlock(false)}
          onUnlocked={(bal, lines) => {
            setProfile((p) => (p ? { ...p, balance: bal, unlocked_lines: lines } : p));
            void refresh();
          }}
        />
      )}
      {ban && <BanScreen until={ban.banned_until} permanent={ban.permanent} />}
      {showAd && (
        <AdWatch
          onClose={() => setShowAd(false)}
          onComplete={(bal) => {
            setProfile((p) => (p ? { ...p, balance: bal } : p));
            void refresh();
            setShowAd(false);
            setAlert({
              title: "獎勵已入帳 Reward added",
              msg: "已為您加入 20 Starrs。20 Starrs have been added to your balance.",
            });
          }}
          onError={(m) => {
            setShowAd(false);
            setAlert({ title: "無法領取 Cannot claim", msg: m });
          }}
        />
      )}
      {showTripAd && journeyResult && (
        <AdWatch
          mode={{ kind: "double", amount: showTripAd.amount }}
          onClose={() => setShowTripAd(null)}
          onComplete={(bal) => {
            setProfile((p) => (p ? { ...p, balance: bal } : p));
            void refresh();
            setJourneyResult((r) =>
              r ? { ...r, adUsed: true, earned: r.earned * 2 } : r,
            );
            setShowTripAd(null);
          }}
          onError={(m) => {
            setShowTripAd(null);
            setAlert({ title: "無法領取 Cannot claim", msg: m });
          }}
        />
      )}
      {showInfo && <InfoDialog onClose={() => setShowInfo(false)} />}
      {showDaily && session && !ban && (
        <DailyChallengeDialog
          alreadyDone={dailyDoneToday}
          onClose={() => setShowDaily(false)}
          onStart={(td) => {
            setShowDaily(false);
            setPendingTravel(td);
          }}
        />
      )}
      {alert && (
        <div className="fixed inset-0 z-[95] bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-sm w-full p-5">
            <h2 className="text-lg font-bold">{alert.title}</h2>
            <p className="text-sm text-slate-600 mt-1">{alert.msg}</p>
            <button
              onClick={() => setAlert(null)}
              className="mt-4 w-full rounded-md bg-slate-900 text-white py-2 text-sm font-medium hover:bg-slate-700"
            >
              知道了 OK
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function ArrivalTimes({
  stationId,
  onStationChange,
}: {
  stationId: string;
  onStationChange: (id: string) => void;
}) {
  const [mounted, setMounted] = useState(false);
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setMounted(true);
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const pad = (n: number) => n.toString().padStart(2, "0");
  const station = STATION_MAP[stationId];

  return (
    <div className="space-y-3">
      <div>
        <label className="text-xs uppercase tracking-wider text-slate-500">
          選擇車站 Select station · 或點擊地圖 or tap the map
        </label>
        <select
          value={stationId}
          onChange={(e) => onStationChange(e.target.value)}
          className="mt-1 w-full rounded-md border border-slate-300 bg-white px-2 py-2 text-sm"
        >
          {STATIONS.map((s) => (
            <option key={s.id} value={s.id}>
              {s.zh} · {s.en}
            </option>
          ))}
        </select>
      </div>

      {/* High-contrast departure board */}
      <div className="rounded-md bg-white text-slate-900 p-3 border border-slate-200">
        <div className="flex items-baseline justify-between border-b border-slate-200 pb-2 mb-2">
          <div className="text-sm font-bold tracking-wider uppercase">
            ▶ {station.id} · {station.en}
          </div>
          <div className="text-[11px] text-slate-500 tabular-nums min-h-[14px] font-mono">
            {mounted && now
              ? (() => {
                  const t = gmt8Now(now);
                  return `GMT+8 ${pad(t.h)}:${pad(t.m)}:${pad(t.s)}`;
                })()
              : ""}
          </div>
        </div>

      {mounted && now ? (() => {
        const t = gmt8Now(now);
        const nowFrac = t.h * 60 + t.m + t.s / 60;
        const services = servicesAtStation(stationId, t.minutes);
        if (services.length === 0) {
          return (
            <div className="text-sm text-slate-500">
              此站無服務線路。No lines serve this station.
            </div>
          );
        }
        return (
          <ul className="space-y-3">
            {services.map((svc) => {
              const arrivals = nextThreeArrivals(svc, nowFrac);
              return (
                <li key={svc.key} className="rounded-sm border border-slate-200 p-2 bg-slate-50">
                  <div className="flex items-center gap-2 mb-2">
                    <span
                      className="inline-block w-3 h-3 rounded-full shrink-0"
                      style={{ background: svc.color }}
                    />
                    <span className="text-xs font-bold text-slate-900 flex-1 truncate uppercase tracking-wide">
                      {svc.label}
                    </span>
                  </div>
                  <ul className="space-y-1.5">
                    {arrivals.map((a, i) => {
                      const delay = getDelay(svc.key, a.arrAbs);
                      const arrAdj = a.arrAbs + (delay ? delay.minutes : 0);
                      const hh = Math.floor(arrAdj / 60) % 24;
                      const mm = Math.floor(arrAdj) % 60;
                      const waitSec = Math.max(0, Math.round((arrAdj - nowFrac) * 60));
                      const waitMin = Math.round(waitSec / 60);
                      const isArriving = waitSec <= 30;
                      const wait = isArriving ? "arriving 即將到站" : `${waitMin} min`;
                      const cars = carriageColors(svc.key, a.arrAbs);
                      return (
                        <li
                          key={i}
                          className="flex flex-col gap-0.5 text-xs tabular-nums font-mono text-slate-900"
                        >
                          <div className="flex items-center gap-2">
                          <span className="w-4 text-slate-400">{i + 1}.</span>
                          <span className="font-extrabold text-slate-900 w-12 text-base leading-none">
                            {pad(hh)}:{pad(mm)}
                          </span>
                          <span className={`w-32 ${isArriving ? "font-bold text-emerald-600" : "text-slate-500"}`}>
                            {isArriving ? wait : `(${wait})`}
                          </span>
                          <span
                            className="flex gap-[2px] ml-auto items-center"
                            title={
                              svc.firstClassOnly
                                ? "全列頭等 · All First Class"
                                : "8 卡列車載客量 · 1-2 為頭等車廂 · 8-carriage load (1-2 First Class)"
                            }
                          >
                            {cars.map((c, idx) => {
                              const isFirstClass = svc.firstClassOnly || idx < 2;
                              const bg =
                                isFirstClass
                                  ? "#d4af37"
                                  : c === "g"
                                    ? "#22c55e"
                                    : c === "y"
                                      ? "#eab308"
                                      : "#ef4444";
                              return (
                                <span
                                  key={idx}
                                  className="relative inline-block w-4 h-4 rounded-[3px] border"
                                  style={{
                                    background: bg,
                                    borderColor: isFirstClass ? "#b8860b" : "#1f2937",
                                    boxShadow: isFirstClass
                                      ? "inset 0 0 0 1px #fde68a"
                                      : undefined,
                                  }}
                                >
                                  {isFirstClass && (
                                    <span
                                      className="absolute inset-0 flex items-center justify-center text-white font-extrabold leading-none"
                                      style={{
                                        fontSize: 9,
                                        textShadow: "0 0 2px rgba(0,0,0,0.7)",
                                      }}
                                    >
                                      1
                                    </span>
                                  )}
                                </span>
                              );
                            })}
                          </span>
                          </div>
                          {delay && (
                            <div className="pl-6 flex flex-col gap-0.5">
                              <span className="font-bold" style={{ color: delay.color }}>
                                {delay.label} · +{delay.minutes} min
                              </span>
                              {delay.note && (
                                <span className="text-[10px]" style={{ color: delay.color }}>
                                  {delay.note}
                                </span>
                              )}
                            </div>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                </li>
              );
            })}
          </ul>
        );
      })() : null}
      </div>

      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-slate-500 pt-1">
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded-[2px] bg-[#22c55e] border border-slate-700" />寬鬆 Empty
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded-[2px] bg-[#eab308] border border-slate-700" />一般 Mod.
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded-[2px] bg-[#ef4444] border border-slate-700" />擠迫 Full
        </span>
        <span className="flex items-center gap-1">
          <span
            className="relative inline-block w-3 h-3 rounded-[2px] bg-[#22c55e] border"
            style={{ borderColor: "#b8860b", boxShadow: "inset 0 0 0 1px #fde68a" }}
          >
            <span
              className="absolute inset-0 flex items-center justify-center text-white font-extrabold"
              style={{ fontSize: 7, textShadow: "0 0 1px rgba(0,0,0,0.7)" }}
            >
              1
            </span>
          </span>
          頭等 First Class
        </span>
      </div>
    </div>
  );
}

/* ───────── Daily Challenge Dialog ───────── */
function DailyChallengeDialog({
  alreadyDone,
  onClose,
  onStart,
}: {
  alreadyDone: boolean;
  onClose: () => void;
  onStart: (td: TravelData) => void;
}) {
  const dateKey = dailyDateKeyGmt8();
  const path = useMemo(() => generateDailyChallengePath(dateKey), [dateKey]);
  const lineSeq = useMemo(() => pickLineSequenceForPath(path), [path]);
  const minutes = useMemo(() => pathTravelTime(path), [path]);
  const from = STATION_MAP[path[0]];
  const to = STATION_MAP[path[path.length - 1]];

  function start() {
    const stops: StationStop[] = [];
    let cum = 0;
    let prevLine: string | null = null;
    for (let i = 0; i < path.length; i++) {
      const st = STATION_MAP[path[i]];
      let lineFromPrev: string | null = null;
      let transferHere = false;
      if (i > 0) {
        lineFromPrev = lineSeq[i - 1] ?? null;
        cum += edgeTime(path[i - 1], path[i]);
        if (prevLine && lineFromPrev && prevLine !== lineFromPrev) transferHere = true;
        prevLine = lineFromPrev;
      }
      stops.push({
        id: st.id,
        en: st.en,
        zh: st.zh,
        arriveAt: cum,
        lineFromPrev,
        transferHere,
      });
    }
    const td: TravelData = {
      from: { id: from.id, en: from.en, zh: from.zh },
      to: { id: to.id, en: to.en, zh: to.zh },
      travelMinutes: minutes,
      seatClass: "Daily Challenge",
      seatClassZh: "每日挑戰",
      isFirst: false,
      stops,
      lineSequence: lineSeq,
      isDaily: true,
    };
    onStart(td);
  }

  const uniqueLines = Array.from(new Set(lineSeq));

  return (
    <div className="fixed inset-0 z-[96] bg-black/70 flex items-start md:items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-fuchsia-950 text-white rounded-xl border border-fuchsia-500/40 shadow-2xl w-full max-w-md my-4 p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-black">🌟 每日挑戰 · Daily Challenge</h2>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-xl font-bold"
          >
            ×
          </button>
        </div>
        <p className="text-xs opacity-70 mt-1">
          Refreshed daily · GMT+8 · {dateKey}
        </p>
        <div className="mt-4 rounded-lg bg-black/30 border border-white/10 p-3">
          <div className="text-[11px] uppercase tracking-widest opacity-70">
            Today's Route · 今日路線
          </div>
          <div className="mt-1 font-bold text-base">
            {from.zh} {from.en}
            <span className="opacity-60"> → </span>
            {to.zh} {to.en}
          </div>
          <div className="mt-2 text-xs opacity-80">
            <b>{path.length}</b> stations · <b>{minutes}</b> min · Lines:{" "}
            {uniqueLines.join(", ") || "—"}
          </div>
          <div className="mt-2 text-[11px] opacity-70 leading-snug">
            {path.map((id) => STATION_MAP[id]?.zh).join(" → ")}
          </div>
        </div>
        <ul className="mt-4 text-xs space-y-1 opacity-90">
          <li>• Locked lines are <b>FREE</b> to ride in Daily Challenges.</li>
          <li>• Earn <b>1.5×</b> Starrs on your catch total + line bonus.</li>
          <li>• Complete with <b>0 misses</b> to earn <b>+100 Starrs</b>!</li>
          <li>• No extra Starrs for a longer route — accuracy matters.</li>
        </ul>
        {alreadyDone && (
          <div className="mt-3 rounded bg-emerald-500/20 border border-emerald-400/60 text-emerald-100 text-xs px-3 py-2">
            ✓ 今日已完成 · You already completed today's challenge. You can
            replay it, but the +100 no-miss bonus can be claimed again if you
            hit zero misses.
          </div>
        )}
        <div className="mt-5 flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 rounded-md bg-white/10 hover:bg-white/20 py-2 text-sm"
          >
            稍後 Later
          </button>
          <button
            onClick={start}
            className="flex-1 rounded-md bg-gradient-to-r from-fuchsia-500 to-pink-500 hover:brightness-110 py-2 text-sm font-bold"
          >
            ▶ 開始挑戰 Start
          </button>
        </div>
      </div>
    </div>
  );
}
