import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import { verifyWebhook, EventName, type PaddleEnv } from "@/lib/paddle.server";

let _supabase: ReturnType<typeof createClient> | null = null;
function getSupabase() {
  if (!_supabase) {
    _supabase = createClient(
      process.env.SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
    );
  }
  return _supabase;
}

async function grantTransaction(data: any, env: PaddleEnv) {
  const userId = data.customData?.userId;
  if (!userId) {
    console.warn("payments/webhook: transaction.completed without userId in customData", {
      transactionId: data.id,
    });
    return;
  }
  const item = data.items?.[0];
  const priceExternalId = item?.price?.importMeta?.externalId;
  const productExternalId =
    item?.price?.product?.importMeta?.externalId ||
    item?.product?.importMeta?.externalId ||
    null;

  if (!priceExternalId) {
    console.warn("payments/webhook: skipping — missing importMeta.externalId on price", {
      transactionId: data.id,
      rawPriceId: item?.price?.id,
    });
    return;
  }

  // Total amount paid (in the currency's lowest denomination — HK cents for HKD).
  const totalStr =
    data.details?.totals?.total ??
    data.details?.totals?.grandTotal ??
    "0";
  const amountCents = Number.parseInt(totalStr, 10) || 0;

  const { error } = await (getSupabase() as any).rpc("grant_purchase", {
    p_user: userId,
    p_transaction_id: data.id,
    p_price_id: priceExternalId,
    p_product_id: productExternalId,
    p_amount_hkd_cents: amountCents,
    p_environment: env,
  });
  if (error) {
    console.error("payments/webhook: grant_purchase failed", error, {
      transactionId: data.id,
      priceExternalId,
    });
    throw error;
  }
}

async function reverseTransaction(transactionId: string) {
  const { error } = await (getSupabase() as any).rpc("reverse_purchase", {
    p_transaction_id: transactionId,
  });
  if (error) {
    console.error("payments/webhook: reverse_purchase failed", error, {
      transactionId,
    });
    throw error;
  }
}

async function handleWebhook(req: Request, env: PaddleEnv) {
  const event = await verifyWebhook(req, env);

  switch (event.eventType) {
    case EventName.TransactionCompleted:
      await grantTransaction(event.data, env);
      break;
    case "adjustment.created":
    case "adjustment.updated": {
      const adj = event.data as any;
      // Only reverse when a refund actually settles.
      const isRefund = adj.action === "refund";
      const isPaid = adj.status === "approved" || adj.status === "pending_approval" || adj.status === "paid";
      if (isRefund && isPaid && adj.transaction_id) {
        await reverseTransaction(adj.transaction_id);
      }
      break;
    }
    case EventName.TransactionPaymentFailed:
      // Nothing to grant — surface via logs.
      console.log("payments/webhook: payment failed", { transactionId: (event.data as any).id });
      break;
    default:
      console.log("payments/webhook: unhandled event", event.eventType);
  }
}

export const Route = createFileRoute("/api/public/payments/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const url = new URL(request.url);
        const env = (url.searchParams.get("env") || "sandbox") as PaddleEnv;
        try {
          await handleWebhook(request, env);
          return Response.json({ received: true });
        } catch (e) {
          console.error("payments/webhook error", e);
          return new Response("Webhook error", { status: 400 });
        }
      },
    },
  },
});
