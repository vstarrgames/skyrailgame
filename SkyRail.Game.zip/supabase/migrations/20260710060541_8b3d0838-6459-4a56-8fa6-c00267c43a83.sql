
CREATE POLICY "Block user inserts on purchases"
  ON public.purchases FOR INSERT TO authenticated, anon
  WITH CHECK (false);

CREATE POLICY "Block user updates on purchases"
  ON public.purchases FOR UPDATE TO authenticated, anon
  USING (false) WITH CHECK (false);

CREATE POLICY "Block user deletes on purchases"
  ON public.purchases FOR DELETE TO authenticated, anon
  USING (false);
