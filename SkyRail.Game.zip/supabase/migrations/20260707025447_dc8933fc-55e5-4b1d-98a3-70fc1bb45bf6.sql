
CREATE TABLE public.daily_logins (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  streak_day integer NOT NULL DEFAULT 0,
  last_claim_date date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.daily_logins TO authenticated;
GRANT ALL ON public.daily_logins TO service_role;

ALTER TABLE public.daily_logins ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own daily_logins select" ON public.daily_logins FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own daily_logins insert" ON public.daily_logins FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own daily_logins update" ON public.daily_logins FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.claim_daily_login()
RETURNS TABLE(day integer, reward integer, new_balance integer, claimed boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_today date := (now() AT TIME ZONE 'Asia/Hong_Kong')::date;
  v_row public.daily_logins%ROWTYPE;
  v_next_day integer;
  v_reward integer;
  v_bal integer;
  v_rewards integer[] := ARRAY[20,30,40,50,100];
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_row FROM public.daily_logins WHERE user_id = v_user FOR UPDATE;
  IF NOT FOUND THEN
    v_next_day := 1;
  ELSIF v_row.last_claim_date = v_today THEN
    RETURN QUERY SELECT v_row.streak_day, 0, COALESCE((SELECT balance FROM public.profiles WHERE user_id = v_user),0), false;
    RETURN;
  ELSIF v_row.last_claim_date = v_today - 1 THEN
    v_next_day := (v_row.streak_day % 5) + 1;
  ELSE
    v_next_day := 1;
  END IF;
  v_reward := v_rewards[v_next_day];
  INSERT INTO public.daily_logins(user_id, streak_day, last_claim_date, updated_at)
    VALUES (v_user, v_next_day, v_today, now())
    ON CONFLICT (user_id) DO UPDATE SET streak_day = v_next_day, last_claim_date = v_today, updated_at = now();
  UPDATE public.profiles SET balance = balance + v_reward, updated_at = now() WHERE user_id = v_user RETURNING balance INTO v_bal;
  IF v_bal IS NULL THEN
    INSERT INTO public.profiles(user_id, balance) VALUES (v_user, 80 + v_reward) RETURNING balance INTO v_bal;
  END IF;
  RETURN QUERY SELECT v_next_day, v_reward, v_bal, true;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_daily_login_status()
RETURNS TABLE(streak_day integer, last_claim_date date, can_claim boolean, next_day integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_today date := (now() AT TIME ZONE 'Asia/Hong_Kong')::date;
  v_row public.daily_logins%ROWTYPE;
  v_next integer;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_row FROM public.daily_logins WHERE user_id = v_user;
  IF NOT FOUND THEN
    RETURN QUERY SELECT 0, NULL::date, true, 1;
    RETURN;
  END IF;
  IF v_row.last_claim_date = v_today THEN
    v_next := (v_row.streak_day % 5) + 1;
    RETURN QUERY SELECT v_row.streak_day, v_row.last_claim_date, false, v_next;
  ELSIF v_row.last_claim_date = v_today - 1 THEN
    v_next := (v_row.streak_day % 5) + 1;
    RETURN QUERY SELECT v_row.streak_day, v_row.last_claim_date, true, v_next;
  ELSE
    RETURN QUERY SELECT v_row.streak_day, v_row.last_claim_date, true, 1;
  END IF;
END;
$$;
