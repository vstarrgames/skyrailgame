
-- Add lifetime total_earned + unlocked_lines to profiles
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS total_earned integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS unlocked_lines text[] NOT NULL DEFAULT ARRAY['L1']::text[];

-- Allow authenticated users to read minimal leaderboard data (username via email prefix + counts)
-- We expose leaderboards via SECURITY DEFINER RPCs; no public policy changes needed.

-- Update end_journey to also track total_earned
CREATE OR REPLACE FUNCTION public.end_journey(p_earned integer)
 RETURNS TABLE(new_balance integer)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_user uuid := auth.uid(); v_bal integer; v_admin boolean := public.is_admin();
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF p_earned IS NULL OR p_earned < 0 THEN p_earned := 0; END IF;
  IF v_admin THEN
    UPDATE public.profiles SET is_in_transit=false, transit_ends_at=null, updated_at=now() WHERE user_id=v_user;
    RETURN QUERY SELECT 10000;
    RETURN;
  END IF;
  UPDATE public.profiles SET
    balance = balance + p_earned,
    total_earned = total_earned + p_earned,
    is_in_transit = false,
    transit_ends_at = null,
    updated_at = now()
  WHERE user_id = v_user RETURNING balance INTO v_bal;
  RETURN QUERY SELECT COALESCE(v_bal, 0);
END;
$function$;

-- Ensure claim_ad_reward and daily_login also update total_earned
CREATE OR REPLACE FUNCTION public.claim_ad_reward()
 RETURNS TABLE(new_balance integer, views_today integer)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user uuid := auth.uid();
  v_count integer;
  v_bal integer;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT count(*) INTO v_count FROM public.ad_views
    WHERE user_id = v_user AND viewed_at > (now() - interval '24 hours');
  IF v_count >= 3 THEN RAISE EXCEPTION 'ad_limit_reached' USING ERRCODE = 'P0001'; END IF;
  INSERT INTO public.ad_views (user_id) VALUES (v_user);
  UPDATE public.profiles SET balance = balance + 20, total_earned = total_earned + 20, updated_at = now()
    WHERE user_id = v_user RETURNING balance INTO v_bal;
  IF v_bal IS NULL THEN
    INSERT INTO public.profiles (user_id, balance, total_earned) VALUES (v_user, 100, 20) RETURNING balance INTO v_bal;
  END IF;
  RETURN QUERY SELECT v_bal, v_count + 1;
END;
$function$;

CREATE OR REPLACE FUNCTION public.claim_daily_login()
 RETURNS TABLE(day integer, reward integer, new_balance integer, claimed boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user uuid := auth.uid();
  v_today date := (now() AT TIME ZONE 'Asia/Hong_Kong')::date;
  v_row public.daily_logins%ROWTYPE;
  v_next_day integer;
  v_reward integer;
  v_bal integer;
  v_rewards integer[] := ARRAY[20,30,40,50,100];
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_row FROM public.daily_logins WHERE user_id = v_user FOR UPDATE;
  IF NOT FOUND THEN
    v_next_day := 1;
  ELSIF v_row.last_claim_date = v_today THEN
    RETURN QUERY SELECT v_row.streak_day, 0, COALESCE((SELECT balance FROM public.profiles WHERE user_id = v_user),0), false;
    RETURN;
  ELSIF v_row.last_claim_date = v_today - 1 THEN
    v_next_day := (v_row.streak_day % 5) + 1;
  ELSE
    v_next_day := 1;
  END IF;
  v_reward := v_rewards[v_next_day];
  INSERT INTO public.daily_logins(user_id, streak_day, last_claim_date, updated_at)
    VALUES (v_user, v_next_day, v_today, now())
    ON CONFLICT (user_id) DO UPDATE SET streak_day = v_next_day, last_claim_date = v_today, updated_at = now();
  UPDATE public.profiles SET balance = balance + v_reward, total_earned = total_earned + v_reward, updated_at = now()
    WHERE user_id = v_user RETURNING balance INTO v_bal;
  IF v_bal IS NULL THEN
    INSERT INTO public.profiles(user_id, balance, total_earned) VALUES (v_user, 80 + v_reward, v_reward) RETURNING balance INTO v_bal;
  END IF;
  RETURN QUERY SELECT v_next_day, v_reward, v_bal, true;
END;
$function$;

-- Unlock a route line by spending Starrs
CREATE OR REPLACE FUNCTION public.unlock_line(p_line text, p_cost integer)
 RETURNS TABLE(new_balance integer, unlocked_lines text[])
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user uuid := auth.uid();
  v_bal integer;
  v_lines text[];
  v_admin boolean := public.is_admin();
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT balance, unlocked_lines INTO v_bal, v_lines FROM public.profiles WHERE user_id = v_user FOR UPDATE;
  IF v_lines IS NULL THEN v_lines := ARRAY['L1']::text[]; END IF;
  IF p_line = ANY(v_lines) THEN
    RETURN QUERY SELECT COALESCE(v_bal, 0), v_lines;
    RETURN;
  END IF;
  IF NOT v_admin THEN
    IF v_bal IS NULL OR v_bal < p_cost THEN RAISE EXCEPTION 'insufficient_starrs' USING ERRCODE = 'P0001'; END IF;
    UPDATE public.profiles SET balance = balance - p_cost, unlocked_lines = array_append(unlocked_lines, p_line), updated_at = now()
      WHERE user_id = v_user RETURNING balance, unlocked_lines INTO v_bal, v_lines;
  ELSE
    UPDATE public.profiles SET unlocked_lines = array_append(unlocked_lines, p_line), updated_at = now()
      WHERE user_id = v_user RETURNING balance, unlocked_lines INTO v_bal, v_lines;
  END IF;
  RETURN QUERY SELECT COALESCE(v_bal, 0), v_lines;
END;
$function$;

-- Auto-unlock a line for free once trip threshold hit (client will call after each trip)
CREATE OR REPLACE FUNCTION public.auto_unlock_lines()
 RETURNS text[]
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user uuid := auth.uid();
  v_trips integer;
  v_lines text[];
  v_thresholds jsonb := '[
    {"line":"L2","trips":3},
    {"line":"L3","trips":8},
    {"line":"L4","trips":15},
    {"line":"L5","trips":40},
    {"line":"L7","trips":80},
    {"line":"L6","trips":100},
    {"line":"AEX","trips":200}
  ]'::jsonb;
  v_item jsonb;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT count(*) INTO v_trips FROM public.tickets WHERE user_id = v_user;
  SELECT unlocked_lines INTO v_lines FROM public.profiles WHERE user_id = v_user FOR UPDATE;
  IF v_lines IS NULL THEN v_lines := ARRAY['L1']::text[]; END IF;
  FOR v_item IN SELECT * FROM jsonb_array_elements(v_thresholds) LOOP
    IF NOT ((v_item->>'line') = ANY(v_lines)) AND v_trips >= (v_item->>'trips')::int THEN
      v_lines := array_append(v_lines, v_item->>'line');
    END IF;
  END LOOP;
  UPDATE public.profiles SET unlocked_lines = v_lines, updated_at = now() WHERE user_id = v_user;
  RETURN v_lines;
END;
$function$;

-- Leaderboards
CREATE OR REPLACE FUNCTION public.leaderboard_trips()
 RETURNS TABLE(user_id uuid, display_name text, count bigint)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT t.user_id,
         split_part(u.email::text, '@', 1) AS display_name,
         count(*) AS count
    FROM public.tickets t
    JOIN auth.users u ON u.id = t.user_id
   WHERE u.email::text <> 'starradmin@skyrail.admin'
   GROUP BY t.user_id, u.email
   ORDER BY count DESC
   LIMIT 5;
$function$;

CREATE OR REPLACE FUNCTION public.leaderboard_first_class()
 RETURNS TABLE(user_id uuid, display_name text, count bigint)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT t.user_id,
         split_part(u.email::text, '@', 1) AS display_name,
         count(*) AS count
    FROM public.tickets t
    JOIN auth.users u ON u.id = t.user_id
   WHERE u.email::text <> 'starradmin@skyrail.admin'
     AND (t.seat_class ILIKE '%first%' OR t.seat_class ILIKE '%airport rapid%')
   GROUP BY t.user_id, u.email
   ORDER BY count DESC
   LIMIT 5;
$function$;

CREATE OR REPLACE FUNCTION public.leaderboard_earned()
 RETURNS TABLE(user_id uuid, display_name text, total integer)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT p.user_id,
         split_part(u.email::text, '@', 1) AS display_name,
         p.total_earned AS total
    FROM public.profiles p
    JOIN auth.users u ON u.id = p.user_id
   WHERE u.email::text <> 'starradmin@skyrail.admin'
   ORDER BY p.total_earned DESC
   LIMIT 5;
$function$;
