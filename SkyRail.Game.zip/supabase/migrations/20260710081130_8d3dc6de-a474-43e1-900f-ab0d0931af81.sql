
-- Gifts table
CREATE TABLE public.starr_gifts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  sender_name text NOT NULL,
  recipient_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount_sent integer NOT NULL CHECK (amount_sent > 0),
  amount_net integer NOT NULL CHECK (amount_net > 0),
  from_admin boolean NOT NULL DEFAULT false,
  claimed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.starr_gifts TO authenticated;
GRANT ALL ON public.starr_gifts TO service_role;
ALTER TABLE public.starr_gifts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read own gifts (sent or received)" ON public.starr_gifts
  FOR SELECT TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = recipient_id);
CREATE INDEX idx_starr_gifts_recipient_unclaimed ON public.starr_gifts(recipient_id) WHERE claimed_at IS NULL;

-- Special rushes table
CREATE TABLE public.special_rushes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  multiplier integer NOT NULL CHECK (multiplier BETWEEN 2 AND 10),
  starts_at timestamptz NOT NULL DEFAULT now(),
  ends_at timestamptz NOT NULL,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.special_rushes TO anon, authenticated;
GRANT ALL ON public.special_rushes TO service_role;
ALTER TABLE public.special_rushes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anyone can read rushes" ON public.special_rushes
  FOR SELECT TO anon, authenticated USING (true);

-- Send a gift
CREATE OR REPLACE FUNCTION public.send_starr_gift(p_recipient_email text, p_amount integer)
RETURNS TABLE(new_balance integer, net_delivered integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_sender uuid := auth.uid();
  v_sender_email text;
  v_recipient uuid;
  v_is_admin boolean := public.is_admin();
  v_net integer;
  v_bal integer;
BEGIN
  IF v_sender IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF p_amount IS NULL OR p_amount < 10 THEN RAISE EXCEPTION 'min_amount_10' USING ERRCODE='P0001'; END IF;
  IF p_recipient_email IS NULL OR length(trim(p_recipient_email)) = 0 THEN RAISE EXCEPTION 'invalid_recipient'; END IF;

  SELECT id, email::text INTO v_recipient, v_sender_email FROM auth.users WHERE id = v_sender;
  SELECT id INTO v_recipient FROM auth.users WHERE lower(email::text) = lower(trim(p_recipient_email));
  IF v_recipient IS NULL THEN RAISE EXCEPTION 'recipient_not_found' USING ERRCODE='P0001'; END IF;
  IF v_recipient = v_sender THEN RAISE EXCEPTION 'cannot_gift_self' USING ERRCODE='P0001'; END IF;

  -- Deduct from sender (admin: infinite, no deduction)
  IF v_is_admin THEN
    v_bal := 10000;
    v_net := p_amount;
  ELSE
    SELECT balance INTO v_bal FROM public.profiles WHERE user_id = v_sender FOR UPDATE;
    IF v_bal IS NULL OR v_bal < p_amount THEN RAISE EXCEPTION 'insufficient_starrs' USING ERRCODE='P0001'; END IF;
    UPDATE public.profiles SET balance = balance - p_amount, updated_at = now()
      WHERE user_id = v_sender RETURNING balance INTO v_bal;
    v_net := floor(p_amount * 0.8)::int;   -- 20% fee for user-to-user
    IF v_net < 1 THEN v_net := 1; END IF;
  END IF;

  INSERT INTO public.starr_gifts(sender_id, sender_name, recipient_id, amount_sent, amount_net, from_admin)
    VALUES (v_sender, split_part(COALESCE(v_sender_email,'unknown'),'@',1), v_recipient, p_amount, v_net, v_is_admin);

  RETURN QUERY SELECT COALESCE(v_bal,0), v_net;
END;
$$;

-- List pending gifts for current user
CREATE OR REPLACE FUNCTION public.list_pending_gifts()
RETURNS TABLE(id uuid, sender_name text, amount_net integer, from_admin boolean, created_at timestamptz)
LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT id, sender_name, amount_net, from_admin, created_at
    FROM public.starr_gifts
   WHERE recipient_id = auth.uid() AND claimed_at IS NULL
   ORDER BY created_at ASC;
$$;

-- Claim all pending gifts, credit balance
CREATE OR REPLACE FUNCTION public.claim_starr_gifts()
RETURNS TABLE(total_claimed integer, new_balance integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_user uuid := auth.uid();
  v_total integer := 0;
  v_bal integer;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT COALESCE(SUM(amount_net),0) INTO v_total FROM public.starr_gifts
    WHERE recipient_id = v_user AND claimed_at IS NULL;
  IF v_total = 0 THEN
    RETURN QUERY SELECT 0, COALESCE((SELECT balance FROM public.profiles WHERE user_id = v_user),0);
    RETURN;
  END IF;
  UPDATE public.starr_gifts SET claimed_at = now() WHERE recipient_id = v_user AND claimed_at IS NULL;
  INSERT INTO public.profiles(user_id) VALUES (v_user) ON CONFLICT DO NOTHING;
  UPDATE public.profiles SET balance = balance + v_total, total_earned = total_earned + v_total, updated_at = now()
    WHERE user_id = v_user RETURNING balance INTO v_bal;
  RETURN QUERY SELECT v_total, COALESCE(v_bal,0);
END;
$$;

-- Admin: start a special rush
CREATE OR REPLACE FUNCTION public.admin_start_rush(p_duration_minutes integer, p_multiplier integer)
RETURNS TABLE(id uuid, multiplier integer, ends_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_id uuid; v_end timestamptz;
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF p_duration_minutes IS NULL OR p_duration_minutes < 5 OR p_duration_minutes > 1440 THEN
    RAISE EXCEPTION 'invalid_duration'; END IF;
  IF p_multiplier IS NULL OR p_multiplier < 2 OR p_multiplier > 10 THEN
    RAISE EXCEPTION 'invalid_multiplier'; END IF;
  v_end := now() + make_interval(mins => p_duration_minutes);
  INSERT INTO public.special_rushes(multiplier, ends_at, created_by)
    VALUES (p_multiplier, v_end, auth.uid()) RETURNING special_rushes.id INTO v_id;
  RETURN QUERY SELECT v_id, p_multiplier, v_end;
END;
$$;

-- Read current active rush (latest)
CREATE OR REPLACE FUNCTION public.current_rush()
RETURNS TABLE(id uuid, multiplier integer, ends_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT id, multiplier, ends_at FROM public.special_rushes
   WHERE ends_at > now() ORDER BY ends_at DESC LIMIT 1;
$$;
