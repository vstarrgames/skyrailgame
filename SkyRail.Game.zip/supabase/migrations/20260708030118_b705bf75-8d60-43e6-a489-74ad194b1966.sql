
CREATE OR REPLACE FUNCTION public.claim_ad_reward()
 RETURNS TABLE(new_balance integer, views_today integer)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user uuid := auth.uid();
  v_count integer;
  v_bal integer;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT count(*) INTO v_count FROM public.ad_views
    WHERE user_id = v_user
      AND (viewed_at AT TIME ZONE 'UTC')::date = (now() AT TIME ZONE 'UTC')::date;
  IF v_count >= 3 THEN RAISE EXCEPTION 'ad_limit_reached' USING ERRCODE = 'P0001'; END IF;
  INSERT INTO public.ad_views (user_id) VALUES (v_user);
  UPDATE public.profiles SET balance = balance + 20, total_earned = total_earned + 20, updated_at = now()
    WHERE user_id = v_user RETURNING balance INTO v_bal;
  IF v_bal IS NULL THEN
    INSERT INTO public.profiles (user_id, balance, total_earned) VALUES (v_user, 100, 20) RETURNING balance INTO v_bal;
  END IF;
  RETURN QUERY SELECT v_bal, v_count + 1;
END;
$function$;
