
ALTER TABLE public.profiles 
  ADD COLUMN IF NOT EXISTS is_in_transit boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS transit_ends_at timestamptz,
  ADD COLUMN IF NOT EXISTS transit_from text,
  ADD COLUMN IF NOT EXISTS transit_to text,
  ADD COLUMN IF NOT EXISTS transit_started_at timestamptz;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT COALESCE((auth.jwt() ->> 'email') = 'starradmin@skyrail.admin', false);
$$;

CREATE TABLE IF NOT EXISTS public.user_bans (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  banned_until timestamptz,
  permanent boolean NOT NULL DEFAULT false,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_bans TO authenticated;
GRANT ALL ON public.user_bans TO service_role;
ALTER TABLE public.user_bans ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "user reads own ban" ON public.user_bans;
CREATE POLICY "user reads own ban" ON public.user_bans FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_admin());
DROP POLICY IF EXISTS "admin manages bans" ON public.user_bans;
CREATE POLICY "admin manages bans" ON public.user_bans FOR ALL TO authenticated
  USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE OR REPLACE FUNCTION public.purchase_ticket(p_from text, p_to text, p_seat_class text, p_fare integer, p_seat text)
RETURNS TABLE(ticket_id uuid, new_balance integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_user uuid := auth.uid();
  v_bal integer;
  v_id uuid;
  v_admin boolean := public.is_admin();
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF p_fare < 0 THEN RAISE EXCEPTION 'invalid fare'; END IF;
  SELECT balance INTO v_bal FROM public.profiles WHERE user_id = v_user FOR UPDATE;
  IF v_bal IS NULL THEN
    INSERT INTO public.profiles (user_id) VALUES (v_user);
    v_bal := 80;
  END IF;
  IF v_admin THEN
    v_bal := 10000;
  ELSE
    IF v_bal < p_fare THEN RAISE EXCEPTION 'insufficient_starrs' USING ERRCODE = 'P0001'; END IF;
    UPDATE public.profiles SET balance = balance - p_fare, updated_at = now() WHERE user_id = v_user RETURNING balance INTO v_bal;
  END IF;
  INSERT INTO public.tickets (user_id, from_station, to_station, seat_class, fare, seat)
    VALUES (v_user, p_from, p_to, p_seat_class, p_fare, p_seat) RETURNING id INTO v_id;
  RETURN QUERY SELECT v_id, v_bal;
END;
$$;

CREATE OR REPLACE FUNCTION public.start_journey(p_from text, p_to text, p_minutes integer)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_user uuid := auth.uid();
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  UPDATE public.profiles SET
    is_in_transit = true,
    transit_from = p_from,
    transit_to = p_to,
    transit_started_at = now(),
    transit_ends_at = now() + make_interval(secs => p_minutes * 6),
    updated_at = now()
  WHERE user_id = v_user;
END;
$$;

CREATE OR REPLACE FUNCTION public.end_journey(p_earned integer)
RETURNS TABLE(new_balance integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_user uuid := auth.uid(); v_bal integer; v_admin boolean := public.is_admin();
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF p_earned IS NULL OR p_earned < 0 THEN p_earned := 0; END IF;
  IF v_admin THEN
    UPDATE public.profiles SET is_in_transit=false, transit_ends_at=null, updated_at=now() WHERE user_id=v_user;
    RETURN QUERY SELECT 10000;
    RETURN;
  END IF;
  UPDATE public.profiles SET
    balance = balance + p_earned,
    is_in_transit = false,
    transit_ends_at = null,
    updated_at = now()
  WHERE user_id = v_user RETURNING balance INTO v_bal;
  RETURN QUERY SELECT COALESCE(v_bal, 0);
END;
$$;

CREATE OR REPLACE FUNCTION public.my_ban()
RETURNS TABLE(banned_until timestamptz, permanent boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT banned_until, permanent FROM public.user_bans WHERE user_id = auth.uid();
$$;

CREATE OR REPLACE FUNCTION public.admin_list_users()
RETURNS TABLE(user_id uuid, email text, balance integer, created_at timestamptz, is_in_transit boolean, banned_until timestamptz, banned_permanent boolean)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  RETURN QUERY 
    SELECT u.id, u.email::text, COALESCE(p.balance, 0)::integer, u.created_at, COALESCE(p.is_in_transit, false),
           b.banned_until, COALESCE(b.permanent, false)
    FROM auth.users u
    LEFT JOIN public.profiles p ON p.user_id = u.id
    LEFT JOIN public.user_bans b ON b.user_id = u.id
    ORDER BY u.created_at DESC;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_stats()
RETURNS TABLE(total_users bigint, in_transit bigint)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  RETURN QUERY SELECT (SELECT count(*) FROM auth.users), (SELECT count(*) FROM public.profiles WHERE is_in_transit = true);
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_ban_user(p_user uuid, p_until timestamptz, p_permanent boolean)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  INSERT INTO public.user_bans(user_id, banned_until, permanent)
    VALUES (p_user, p_until, p_permanent)
  ON CONFLICT (user_id) DO UPDATE SET banned_until=EXCLUDED.banned_until, permanent=EXCLUDED.permanent, created_at=now();
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_unban_user(p_user uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  DELETE FROM public.user_bans WHERE user_id=p_user;
END;
$$;
