
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS skin_tokens integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS starrboxes integer NOT NULL DEFAULT 0;

CREATE OR REPLACE FUNCTION public.open_starrbox(p_use_credit boolean)
RETURNS TABLE(
  kind text,
  starrs_awarded integer,
  tokens_awarded integer,
  new_balance integer,
  new_boost_multiplier integer,
  new_boost_remaining_ms bigint,
  new_skin_tokens integer,
  new_starrboxes integer
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_bal integer; v_credits integer; v_tokens integer;
  v_mult integer; v_ms bigint;
  v_roll numeric;
  v_kind text;
  v_add_boost_mult integer := 0; v_add_boost_ms bigint := 0;
  v_add_starrs integer := 0; v_add_tokens integer := 0;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;

  SELECT balance, starrboxes, skin_tokens, boost_multiplier, boost_remaining_ms
    INTO v_bal, v_credits, v_tokens, v_mult, v_ms
    FROM public.profiles WHERE user_id = v_user FOR UPDATE;

  IF v_bal IS NULL THEN
    INSERT INTO public.profiles(user_id) VALUES (v_user)
      RETURNING balance, starrboxes, skin_tokens, boost_multiplier, boost_remaining_ms
      INTO v_bal, v_credits, v_tokens, v_mult, v_ms;
  END IF;

  IF p_use_credit AND COALESCE(v_credits,0) > 0 THEN
    v_credits := v_credits - 1;
  ELSE
    IF COALESCE(v_bal,0) < 100 THEN RAISE EXCEPTION 'insufficient_starrs' USING ERRCODE='P0001'; END IF;
    v_bal := v_bal - 100;
  END IF;

  v_roll := random() * 100;
  IF    v_roll <  30      THEN v_kind := 'starrs_50';     v_add_starrs := 50;
  ELSIF v_roll <  55      THEN v_kind := 'boost_2x_10';   v_add_boost_mult := 2; v_add_boost_ms := 10*60*1000;
  ELSIF v_roll <  75      THEN v_kind := 'boost_2x_15';   v_add_boost_mult := 2; v_add_boost_ms := 15*60*1000;
  ELSIF v_roll <  89      THEN v_kind := 'starrs_150';    v_add_starrs := 150;
  ELSIF v_roll <  97      THEN v_kind := 'boost_3x_15';   v_add_boost_mult := 3; v_add_boost_ms := 15*60*1000;
  ELSIF v_roll <  99      THEN v_kind := 'skin_token_1';  v_add_tokens := 1;
  ELSIF v_roll <  99.9    THEN v_kind := 'skin_token_2';  v_add_tokens := 2;
  ELSIF v_roll <  99.99   THEN v_kind := 'skin_token_4';  v_add_tokens := 4;
  ELSE                         v_kind := 'skin_token_8';  v_add_tokens := 8;
  END IF;

  v_bal := v_bal + v_add_starrs;
  v_tokens := COALESCE(v_tokens,0) + v_add_tokens;
  IF v_add_boost_mult > 0 THEN
    v_mult := CASE WHEN COALESCE(v_ms,0) = 0 THEN v_add_boost_mult ELSE GREATEST(COALESCE(v_mult,1), v_add_boost_mult) END;
    v_ms := COALESCE(v_ms,0) + v_add_boost_ms;
  END IF;

  UPDATE public.profiles SET
    balance = v_bal,
    total_earned = total_earned + v_add_starrs,
    skin_tokens = v_tokens,
    starrboxes = v_credits,
    boost_multiplier = COALESCE(v_mult,1),
    boost_remaining_ms = COALESCE(v_ms,0),
    updated_at = now()
    WHERE user_id = v_user;

  kind := v_kind;
  starrs_awarded := v_add_starrs;
  tokens_awarded := v_add_tokens;
  new_balance := v_bal;
  new_boost_multiplier := COALESCE(v_mult,1);
  new_boost_remaining_ms := COALESCE(v_ms,0);
  new_skin_tokens := v_tokens;
  new_starrboxes := v_credits;
  RETURN NEXT;
END;
$$;

CREATE OR REPLACE FUNCTION public.redeem_skin_tokens(p_count integer)
RETURNS TABLE(new_balance integer, new_skin_tokens integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE v_user uuid := auth.uid(); v_bal integer; v_tokens integer;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF p_count IS NULL OR p_count < 1 THEN RAISE EXCEPTION 'invalid_count'; END IF;
  SELECT balance, skin_tokens INTO v_bal, v_tokens FROM public.profiles WHERE user_id = v_user FOR UPDATE;
  IF COALESCE(v_tokens,0) < p_count THEN RAISE EXCEPTION 'insufficient_tokens' USING ERRCODE='P0001'; END IF;
  UPDATE public.profiles SET
    balance = balance + (p_count * 200),
    total_earned = total_earned + (p_count * 200),
    skin_tokens = skin_tokens - p_count,
    updated_at = now()
  WHERE user_id = v_user RETURNING balance, skin_tokens INTO v_bal, v_tokens;
  new_balance := v_bal; new_skin_tokens := v_tokens; RETURN NEXT;
END;
$$;

CREATE OR REPLACE FUNCTION public.grant_purchase(p_user uuid, p_transaction_id text, p_price_id text, p_product_id text, p_amount_hkd_cents integer, p_environment text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_row public.purchases%ROWTYPE;
  v_starrs integer := 0;
  v_boost_mult integer := 0;
  v_boost_ms bigint := 0;
  v_grant_l2 boolean := false;
  v_starrbox integer := 0;
  v_cur_mult integer;
  v_cur_ms bigint;
BEGIN
  INSERT INTO public.purchases (user_id, paddle_transaction_id, price_id, product_id, amount_hkd_cents, environment)
    VALUES (p_user, p_transaction_id, p_price_id, p_product_id, p_amount_hkd_cents, p_environment)
    ON CONFLICT (paddle_transaction_id) DO NOTHING;

  SELECT * INTO v_row FROM public.purchases WHERE paddle_transaction_id = p_transaction_id FOR UPDATE;
  IF v_row.granted THEN RETURN; END IF;

  CASE p_price_id
    WHEN 'starter_pack_price' THEN v_starrs := 100; v_boost_mult := 2; v_boost_ms := 10*60*1000; v_grant_l2 := true;
    WHEN 'starr_pack_100_price'  THEN v_starrs := 100;
    WHEN 'starr_pack_220_price'  THEN v_starrs := 220;
    WHEN 'starr_pack_450_price'  THEN v_starrs := 450;
    WHEN 'starr_pack_1000_price' THEN v_starrs := 1000;
    WHEN 'starr_pack_2500_price' THEN v_starrs := 2500;
    WHEN 'boost_2x_10_price' THEN v_boost_mult := 2; v_boost_ms := 10*60*1000;
    WHEN 'boost_2x_30_price' THEN v_boost_mult := 2; v_boost_ms := 30*60*1000;
    WHEN 'boost_3x_30_price' THEN v_boost_mult := 3; v_boost_ms := 30*60*1000;
    WHEN 'starrbox_price'    THEN v_starrbox := 1;
    ELSE
      UPDATE public.purchases SET granted = true, updated_at = now() WHERE paddle_transaction_id = p_transaction_id;
      RETURN;
  END CASE;

  INSERT INTO public.profiles (user_id) VALUES (p_user) ON CONFLICT DO NOTHING;

  SELECT boost_multiplier, boost_remaining_ms INTO v_cur_mult, v_cur_ms
    FROM public.profiles WHERE user_id = p_user FOR UPDATE;

  UPDATE public.profiles SET
    balance = balance + v_starrs,
    hkd_spent_cents = hkd_spent_cents + COALESCE(p_amount_hkd_cents, 0),
    starrboxes = starrboxes + v_starrbox,
    boost_multiplier = CASE
      WHEN v_boost_mult = 0 THEN COALESCE(v_cur_mult, 1)
      WHEN COALESCE(v_cur_ms,0) = 0 THEN v_boost_mult
      ELSE GREATEST(COALESCE(v_cur_mult,1), v_boost_mult)
    END,
    boost_remaining_ms = COALESCE(v_cur_ms, 0) + v_boost_ms,
    unlocked_lines = CASE
      WHEN v_grant_l2 AND NOT ('L2' = ANY(COALESCE(unlocked_lines, ARRAY['L1']::text[])))
        THEN array_append(COALESCE(unlocked_lines, ARRAY['L1']::text[]), 'L2')
      ELSE unlocked_lines
    END,
    updated_at = now()
  WHERE user_id = p_user;

  UPDATE public.purchases SET granted = true, updated_at = now()
    WHERE paddle_transaction_id = p_transaction_id;
END;
$function$;

CREATE OR REPLACE FUNCTION public.reverse_purchase(p_transaction_id text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_row public.purchases%ROWTYPE;
  v_starrs integer := 0;
  v_boost_ms bigint := 0;
  v_revoke_l2 boolean := false;
  v_starrbox integer := 0;
BEGIN
  SELECT * INTO v_row FROM public.purchases WHERE paddle_transaction_id = p_transaction_id FOR UPDATE;
  IF NOT FOUND OR NOT v_row.granted OR v_row.reversed THEN RETURN; END IF;

  CASE v_row.price_id
    WHEN 'starter_pack_price' THEN v_starrs := 100; v_boost_ms := 10*60*1000; v_revoke_l2 := true;
    WHEN 'starr_pack_100_price'  THEN v_starrs := 100;
    WHEN 'starr_pack_220_price'  THEN v_starrs := 220;
    WHEN 'starr_pack_450_price'  THEN v_starrs := 450;
    WHEN 'starr_pack_1000_price' THEN v_starrs := 1000;
    WHEN 'starr_pack_2500_price' THEN v_starrs := 2500;
    WHEN 'boost_2x_10_price' THEN v_boost_ms := 10*60*1000;
    WHEN 'boost_2x_30_price' THEN v_boost_ms := 30*60*1000;
    WHEN 'boost_3x_30_price' THEN v_boost_ms := 30*60*1000;
    WHEN 'starrbox_price'    THEN v_starrbox := 1;
    ELSE NULL;
  END CASE;

  UPDATE public.profiles SET
    balance = GREATEST(0, balance - v_starrs),
    hkd_spent_cents = GREATEST(0, hkd_spent_cents - COALESCE(v_row.amount_hkd_cents, 0)),
    starrboxes = GREATEST(0, starrboxes - v_starrbox),
    boost_remaining_ms = GREATEST(0::bigint, boost_remaining_ms - v_boost_ms),
    boost_multiplier = CASE WHEN GREATEST(0::bigint, boost_remaining_ms - v_boost_ms) = 0 THEN 1 ELSE boost_multiplier END,
    unlocked_lines = CASE
      WHEN v_revoke_l2 THEN array_remove(unlocked_lines, 'L2')
      ELSE unlocked_lines
    END,
    updated_at = now()
  WHERE user_id = v_row.user_id;

  UPDATE public.purchases SET reversed = true, updated_at = now()
    WHERE paddle_transaction_id = p_transaction_id;
END;
$function$;
