CREATE OR REPLACE FUNCTION public.unlock_line(p_line text, p_cost integer)
 RETURNS TABLE(new_balance integer, unlocked_lines text[])
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user uuid := auth.uid();
  v_bal integer;
  v_lines text[];
  v_admin boolean := public.is_admin();
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT p.balance, p.unlocked_lines INTO v_bal, v_lines FROM public.profiles p WHERE p.user_id = v_user FOR UPDATE;
  IF v_lines IS NULL THEN v_lines := ARRAY['L1']::text[]; END IF;
  IF p_line = ANY(v_lines) THEN
    new_balance := COALESCE(v_bal, 0);
    unlocked_lines := v_lines;
    RETURN NEXT;
    RETURN;
  END IF;
  IF NOT v_admin THEN
    IF v_bal IS NULL OR v_bal < p_cost THEN RAISE EXCEPTION 'insufficient_starrs' USING ERRCODE = 'P0001'; END IF;
    UPDATE public.profiles p SET balance = p.balance - p_cost, unlocked_lines = array_append(p.unlocked_lines, p_line), updated_at = now()
      WHERE p.user_id = v_user RETURNING p.balance, p.unlocked_lines INTO v_bal, v_lines;
  ELSE
    UPDATE public.profiles p SET unlocked_lines = array_append(p.unlocked_lines, p_line), updated_at = now()
      WHERE p.user_id = v_user RETURNING p.balance, p.unlocked_lines INTO v_bal, v_lines;
  END IF;
  new_balance := COALESCE(v_bal, 0);
  unlocked_lines := v_lines;
  RETURN NEXT;
END;
$function$;