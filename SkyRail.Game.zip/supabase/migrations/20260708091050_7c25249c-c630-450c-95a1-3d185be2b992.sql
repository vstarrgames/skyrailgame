
-- purchases table
CREATE TABLE public.purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  paddle_transaction_id text NOT NULL UNIQUE,
  price_id text NOT NULL,
  product_id text,
  amount_hkd_cents integer NOT NULL DEFAULT 0,
  environment text NOT NULL DEFAULT 'sandbox',
  granted boolean NOT NULL DEFAULT false,
  reversed boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.purchases TO authenticated;
GRANT ALL ON public.purchases TO service_role;
ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own purchases select" ON public.purchases
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE INDEX idx_purchases_user ON public.purchases(user_id);

-- profile columns
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS hkd_spent_cents integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS boost_multiplier integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS boost_remaining_ms bigint NOT NULL DEFAULT 0;

-- grant_purchase: apply rewards for a completed transaction (idempotent)
CREATE OR REPLACE FUNCTION public.grant_purchase(
  p_user uuid,
  p_transaction_id text,
  p_price_id text,
  p_product_id text,
  p_amount_hkd_cents integer,
  p_environment text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row public.purchases%ROWTYPE;
  v_starrs integer := 0;
  v_boost_mult integer := 0;
  v_boost_ms bigint := 0;
  v_grant_l2 boolean := false;
  v_cur_mult integer;
  v_cur_ms bigint;
BEGIN
  -- Insert or fetch idempotent purchase row
  INSERT INTO public.purchases (user_id, paddle_transaction_id, price_id, product_id, amount_hkd_cents, environment)
    VALUES (p_user, p_transaction_id, p_price_id, p_product_id, p_amount_hkd_cents, p_environment)
    ON CONFLICT (paddle_transaction_id) DO NOTHING;

  SELECT * INTO v_row FROM public.purchases WHERE paddle_transaction_id = p_transaction_id FOR UPDATE;
  IF v_row.granted THEN RETURN; END IF;

  CASE p_price_id
    WHEN 'starter_pack_price' THEN v_starrs := 100; v_boost_mult := 2; v_boost_ms := 10*60*1000; v_grant_l2 := true;
    WHEN 'starr_pack_100_price'  THEN v_starrs := 100;
    WHEN 'starr_pack_220_price'  THEN v_starrs := 220;
    WHEN 'starr_pack_450_price'  THEN v_starrs := 450;
    WHEN 'starr_pack_1000_price' THEN v_starrs := 1000;
    WHEN 'starr_pack_2500_price' THEN v_starrs := 2500;
    WHEN 'boost_2x_10_price' THEN v_boost_mult := 2; v_boost_ms := 10*60*1000;
    WHEN 'boost_2x_30_price' THEN v_boost_mult := 2; v_boost_ms := 30*60*1000;
    WHEN 'boost_3x_30_price' THEN v_boost_mult := 3; v_boost_ms := 30*60*1000;
    ELSE
      -- Unknown price: mark granted so we don't retry; log via updated_at.
      UPDATE public.purchases SET granted = true, updated_at = now() WHERE paddle_transaction_id = p_transaction_id;
      RETURN;
  END CASE;

  -- Ensure profile exists
  INSERT INTO public.profiles (user_id) VALUES (p_user) ON CONFLICT DO NOTHING;

  SELECT boost_multiplier, boost_remaining_ms INTO v_cur_mult, v_cur_ms
    FROM public.profiles WHERE user_id = p_user FOR UPDATE;

  UPDATE public.profiles SET
    balance = balance + v_starrs,
    hkd_spent_cents = hkd_spent_cents + COALESCE(p_amount_hkd_cents, 0),
    boost_multiplier = CASE
      WHEN v_boost_mult = 0 THEN COALESCE(v_cur_mult, 1)
      WHEN COALESCE(v_cur_ms,0) = 0 THEN v_boost_mult
      ELSE GREATEST(COALESCE(v_cur_mult,1), v_boost_mult)
    END,
    boost_remaining_ms = COALESCE(v_cur_ms, 0) + v_boost_ms,
    unlocked_lines = CASE
      WHEN v_grant_l2 AND NOT ('L2' = ANY(COALESCE(unlocked_lines, ARRAY['L1']::text[])))
        THEN array_append(COALESCE(unlocked_lines, ARRAY['L1']::text[]), 'L2')
      ELSE unlocked_lines
    END,
    updated_at = now()
  WHERE user_id = p_user;

  UPDATE public.purchases SET granted = true, updated_at = now()
    WHERE paddle_transaction_id = p_transaction_id;
END;
$$;

-- reverse_purchase: undo the rewards on refund/chargeback
CREATE OR REPLACE FUNCTION public.reverse_purchase(p_transaction_id text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row public.purchases%ROWTYPE;
  v_starrs integer := 0;
  v_boost_ms bigint := 0;
  v_revoke_l2 boolean := false;
BEGIN
  SELECT * INTO v_row FROM public.purchases WHERE paddle_transaction_id = p_transaction_id FOR UPDATE;
  IF NOT FOUND OR NOT v_row.granted OR v_row.reversed THEN RETURN; END IF;

  CASE v_row.price_id
    WHEN 'starter_pack_price' THEN v_starrs := 100; v_boost_ms := 10*60*1000; v_revoke_l2 := true;
    WHEN 'starr_pack_100_price'  THEN v_starrs := 100;
    WHEN 'starr_pack_220_price'  THEN v_starrs := 220;
    WHEN 'starr_pack_450_price'  THEN v_starrs := 450;
    WHEN 'starr_pack_1000_price' THEN v_starrs := 1000;
    WHEN 'starr_pack_2500_price' THEN v_starrs := 2500;
    WHEN 'boost_2x_10_price' THEN v_boost_ms := 10*60*1000;
    WHEN 'boost_2x_30_price' THEN v_boost_ms := 30*60*1000;
    WHEN 'boost_3x_30_price' THEN v_boost_ms := 30*60*1000;
    ELSE NULL;
  END CASE;

  UPDATE public.profiles SET
    balance = GREATEST(0, balance - v_starrs),
    hkd_spent_cents = GREATEST(0, hkd_spent_cents - COALESCE(v_row.amount_hkd_cents, 0)),
    boost_remaining_ms = GREATEST(0::bigint, boost_remaining_ms - v_boost_ms),
    boost_multiplier = CASE WHEN GREATEST(0::bigint, boost_remaining_ms - v_boost_ms) = 0 THEN 1 ELSE boost_multiplier END,
    unlocked_lines = CASE
      WHEN v_revoke_l2 THEN array_remove(unlocked_lines, 'L2')
      ELSE unlocked_lines
    END,
    updated_at = now()
  WHERE user_id = v_row.user_id;

  UPDATE public.purchases SET reversed = true, updated_at = now()
    WHERE paddle_transaction_id = p_transaction_id;
END;
$$;

-- consume_boost: burn down the gameplay-active timer
CREATE OR REPLACE FUNCTION public.consume_boost(p_elapsed_ms integer)
RETURNS TABLE(boost_multiplier integer, boost_remaining_ms bigint)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_new bigint;
  v_mult integer;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF p_elapsed_ms IS NULL OR p_elapsed_ms < 0 THEN p_elapsed_ms := 0; END IF;

  UPDATE public.profiles SET
    boost_remaining_ms = GREATEST(0::bigint, boost_remaining_ms - p_elapsed_ms),
    boost_multiplier = CASE WHEN GREATEST(0::bigint, boost_remaining_ms - p_elapsed_ms) = 0 THEN 1 ELSE boost_multiplier END,
    updated_at = now()
  WHERE user_id = v_user
  RETURNING profiles.boost_multiplier, profiles.boost_remaining_ms INTO v_mult, v_new;

  RETURN QUERY SELECT COALESCE(v_mult, 1), COALESCE(v_new, 0::bigint);
END;
$$;

-- HKD spent leaderboard
CREATE OR REPLACE FUNCTION public.leaderboard_spent()
RETURNS TABLE(user_id uuid, display_name text, total integer)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.user_id,
         split_part(u.email::text, '@', 1) AS display_name,
         p.hkd_spent_cents AS total
    FROM public.profiles p
    JOIN auth.users u ON u.id = p.user_id
   WHERE u.email::text <> 'starradmin@skyrail.admin'
     AND p.hkd_spent_cents > 0
   ORDER BY p.hkd_spent_cents DESC
   LIMIT 5;
$$;
