
REVOKE ALL ON FUNCTION public.purchase_ticket(text,text,text,integer,text) FROM public, anon;
REVOKE ALL ON FUNCTION public.claim_ad_reward() FROM public, anon;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.purchase_ticket(text,text,text,integer,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.claim_ad_reward() TO authenticated;
