
-- profiles
CREATE TABLE public.profiles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  balance integer NOT NULL DEFAULT 80,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile select" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- tickets
CREATE TABLE public.tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  from_station text NOT NULL,
  to_station text NOT NULL,
  seat_class text NOT NULL,
  fare integer NOT NULL,
  seat text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.tickets TO authenticated;
GRANT ALL ON public.tickets TO service_role;
ALTER TABLE public.tickets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own tickets select" ON public.tickets FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- ad views
CREATE TABLE public.ad_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  viewed_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.ad_views TO authenticated;
GRANT ALL ON public.ad_views TO service_role;
ALTER TABLE public.ad_views ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own ad_views select" ON public.ad_views FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE INDEX ad_views_user_time_idx ON public.ad_views (user_id, viewed_at DESC);

-- profile auto-create trigger
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (user_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- purchase ticket atomically
CREATE OR REPLACE FUNCTION public.purchase_ticket(
  p_from text, p_to text, p_seat_class text, p_fare integer, p_seat text
) RETURNS TABLE (ticket_id uuid, new_balance integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_user uuid := auth.uid();
  v_bal integer;
  v_id uuid;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF p_fare < 0 THEN RAISE EXCEPTION 'invalid fare'; END IF;
  SELECT balance INTO v_bal FROM public.profiles WHERE user_id = v_user FOR UPDATE;
  IF v_bal IS NULL THEN
    INSERT INTO public.profiles (user_id) VALUES (v_user);
    v_bal := 80;
  END IF;
  IF v_bal < p_fare THEN RAISE EXCEPTION 'insufficient_starrs' USING ERRCODE = 'P0001'; END IF;
  UPDATE public.profiles SET balance = balance - p_fare, updated_at = now() WHERE user_id = v_user RETURNING balance INTO v_bal;
  INSERT INTO public.tickets (user_id, from_station, to_station, seat_class, fare, seat)
    VALUES (v_user, p_from, p_to, p_seat_class, p_fare, p_seat) RETURNING id INTO v_id;
  RETURN QUERY SELECT v_id, v_bal;
END;
$$;
GRANT EXECUTE ON FUNCTION public.purchase_ticket(text,text,text,integer,text) TO authenticated;

-- ad reward
CREATE OR REPLACE FUNCTION public.claim_ad_reward()
RETURNS TABLE (new_balance integer, views_today integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_user uuid := auth.uid();
  v_count integer;
  v_bal integer;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT count(*) INTO v_count FROM public.ad_views
    WHERE user_id = v_user AND viewed_at > (now() - interval '24 hours');
  IF v_count >= 3 THEN RAISE EXCEPTION 'ad_limit_reached' USING ERRCODE = 'P0001'; END IF;
  INSERT INTO public.ad_views (user_id) VALUES (v_user);
  UPDATE public.profiles SET balance = balance + 20, updated_at = now()
    WHERE user_id = v_user RETURNING balance INTO v_bal;
  IF v_bal IS NULL THEN
    INSERT INTO public.profiles (user_id, balance) VALUES (v_user, 100) RETURNING balance INTO v_bal;
  END IF;
  RETURN QUERY SELECT v_bal, v_count + 1;
END;
$$;
GRANT EXECUTE ON FUNCTION public.claim_ad_reward() TO authenticated;
