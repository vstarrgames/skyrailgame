
CREATE OR REPLACE FUNCTION public.apply_trip_ad_bonus(p_amount int)
RETURNS int
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_bal int;
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF p_amount IS NULL OR p_amount <= 0 THEN
    RETURN COALESCE((SELECT balance FROM public.profiles WHERE user_id = v_user), 0);
  END IF;
  IF p_amount > 2000 THEN p_amount := 2000; END IF;
  UPDATE public.profiles
    SET balance = balance + p_amount,
        total_earned = total_earned + p_amount,
        updated_at = now()
    WHERE user_id = v_user
    RETURNING balance INTO v_bal;
  IF v_bal IS NULL THEN
    INSERT INTO public.profiles (user_id, balance, total_earned)
      VALUES (v_user, 80 + p_amount, p_amount)
      RETURNING balance INTO v_bal;
  END IF;
  RETURN COALESCE(v_bal, 0);
END;
$$;
